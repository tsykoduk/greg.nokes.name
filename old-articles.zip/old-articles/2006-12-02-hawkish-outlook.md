---
id: 1619
title: 'Hawkish outlook....'
date: 2006-12-02T17:47:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hawkish-outlook
permalink: /2006/12/02/hawkish-outlook/
categories:
  - Computers! and Code!
---
<blockquote>Well I've been hiding a secret for the past two weeks. It's something that I've felt conflicted and unsure of, something that I've felt ashamed of and proud of at the same time. Something that I've been trying to sort out before I actually wrote about it. Most people will probably say, "yeah, big deal." But for me it kind of is a big deal. I haven't told very many people. I showed Robert Scoble last week but have been kind of hiding it otherwise.

<p>A little over two weeks ago I walked into the Apple store in Palo Alto and bought myself a new MacBook Pro. Yes, the new sexy Intel dual core MacBook Pro. And I went home and after not using a Mac for over 15 years, put my Dell PC notebook literally in the bookshelf and have been using this new Mac as my primary computer for the past 2 weeks.</blockquote></p>


<p>-<a href="http://thomashawk.com/">Thomas Hawk</a> via <a href="http://www.apple.com/hotnews/">Apple</a></p>


<p>Another story from a switcher.</p>


<p>I am forced to use a Dell laptop at work - and I must say that I hate it. I even have gotten to play around with their Dual Core d620 - and it just makes me want to use my trusty G4 Powerbook all the more. It's not just bigotry here - I actually prefer how the Powerbook works, and feels. When I hold the Dell, and it flexes it just feels like a toy - not a tool. When I hold the powerbook, it's solid and feels like it's there.</p>


<p>They keyboards are also very different. I am very aware of the tactile response that a keyboard provides. The Dell's keyboard feels - well, cheap. My fingers catch the undersides of the keys, and there is very little travel in the keys. The mac laptop is tight, back lit, and when you press a key, it travels up and down fluidly with a just about the perfect tactile feedback.</p>


<p>It's these little things that have really make the experience work for me. It makes working with the device more of a pleasure then a chore.</p>