---
id: 883
title: Corporate Speak
date: 2005-09-16T18:19:02+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/corporate-speak
permalink: /2005/09/16/corporate-speak/
categories:
  - Computers! and Code!
description: "Discover the art of corporate speak through Steve Ballmer's Vista interview - learn how executives say a lot without really saying anything at all."
---
<blockquote> <strong> You talk about Vista and the <span class="caps">CRM</span> product. One of the complaints I've heard is that if Vista is delayed, it delays products that are tied to it. Is that a concern?</strong>
No, Vista will be out next year.

<p><strong>But it had been delayed?</strong>
Vista will be out next year. Vista has never been delayed. I mean, we had earlier conceptualizations, but the thing that is Vista is on its track. </blockquote></p>


<p>-<a href="http://www.businessweek.com/magazine/content/05_39/b3952008.htm">Steve Ballmer on Business Week Online</a></p>


<p>Read on for a truely fanstic example of Corporate Speak - the art of saying a lot with out really saying anything at all.</p>