---
id: 2904
title: Inefficiency is good
date: 2007-07-25T15:00:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/inefficiency-is-good
permalink: /2007/07/25/inefficiency-is-good/
categories:
  - Philosophy! and Politics!
---
<p><img src="https://greg.nokes.name/assets/2007/7/25/160px-EugeneMcCarthy.jpg" style="float: right; padding: 5px;" /></p>


<blockquote>The only thing that saves us from the bureaucracy is inefficiency.
An efficient bureaucracy is the greatest threat to liberty.</blockquote>

<blockquote>Being in politics is like being a football coach. You have to be smart enough to understand the game, and dumb enough to think it's important.</blockquote>

<blockquote>One thing about a pig, he thinks he's warm if his nose is warm. I saw a bunch of pigs one time that had frozen together in a rosette, each one's nose tucked under the rump of the one in front. We have a lot of pigs in politics.</blockquote>

<blockquote>The two-party system has given this country the war of Lyndon Johnson, the Watergate of Nixon, and the incompetence of Carter. Saying we should keep the two-party system simply because it is working is like saying the Titanic voyage was a success because a few people survived on life-rafts.</blockquote>

<p>- <a href="http://en.wikipedia.org/wiki/Eugene_McCarthy">Eugene McCarthy</a></p>