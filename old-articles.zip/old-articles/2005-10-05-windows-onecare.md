---
id: 936
title: Windows OneCare
date: 2005-10-05T07:14:40+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/windows-onecare
permalink: /2005/10/05/windows-onecare/
categories:
  - Computers! and Code!
description: "Microsoft debuts Windows OneCare, a subscription security service to protect their OS. Is paying twice for Windows security like protection money? Explore alternatives."
---
<p>So, Microsoft just debuted Windows <a href="http://beta.windowsonecare.com/">OneCare</a> - a product to secure their OS.</p>


<blockquote>Are you tired of spending time trying to protect and maintain your computer? Are you worried that you're still not doing everything you should to keep it safe and running at optimal performance? If your answer is "Yes," then Windows OneCareâ„¢ is for you. Windows OneCare is built specifically for people who don't have the time or technical expertise necessary to secure and manage a computer on a daily basis. It is a comprehensive PC health service that goes beyond security to take an integrated approach to help protect and care for your computer.</blockquote>

<p>-Microsoft's <a href="http://www.microsoft.com/windows/onecare/default.mspx">OneCare site</a></p>


<p>Microsoft reportedly is looking at selling this as a subscription product. So - again, you pay for the OS - and you pay to keep it running? It's sort of like having to buy a car, and then pay a subscription to keep twits from slashing your tires. In some areas that would be called protection money.</p>


<p>Getting tired of this? There are <a href="http://www.apple.com/store/">ways</a> out of the mess...</p>