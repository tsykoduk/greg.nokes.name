---
id: 1383
title: Vitally important issue
date: 2006-05-14T21:59:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/vitally-important-issue
permalink: /2006/05/14/vitally-important-issue/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
description: "5-hour limit reached ∙ resets 6pm"
---
<center><object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/H69eCYcDcuQ"></param><embed src="http://www.youtube.com/v/H69eCYcDcuQ" type="application/x-shockwave-flash" width="425" height="350"></embed></object></center>

<p>Actually, this is a <b>really</b> important issue. Call your congresscritter today!</p>


<p>Another (slightly more technical) update after the jump:</p>


&lt;!<del>-more</del>-&gt;
<center><object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/l9jHOn0EW8U"></param><embed src="http://www.youtube.com/v/l9jHOn0EW8U" type="application/x-shockwave-flash" width="425" height="350"></embed></object></center>