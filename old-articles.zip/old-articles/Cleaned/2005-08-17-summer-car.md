---
id: 760
title: Summer Car?
date: 2005-08-17T08:09:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/summer-car
permalink: /2005/08/17/summer-car/
categories:
  - Fun!
---
<center><table width=350 align=center border=0 cellspacing=0 cellpadding=2><tr><td bgcolor="#CDDEFF" align=center><font face="Georgia, Times New Roman, Times, serif" style='color:black; font-size: 14pt;'><b>Your Summer Ride is a Jeep</b></font></td></tr><tr><td bgcolor="#EBF2FF"><center><img src="http://images.blogthings.com/whatsyoursummerridequiz/jeep.jpg"/></center><font color="#000000">
	For you, summer is all about having no responsibilities.
	You prefer to hang with old friends - and make some new ones.</font></td></tr></table><div align="center"><a href="http://www.blogthings.com/whatsyoursummerridequiz/">What's Your Summer Ride?</a></div></center>

	<p>Woo Hoo!</p>


	<p>(HT: <a href="http://davejustus.blogspot.com/2005/08/summer-rides.html">Justus</a> - have fun on your vacation!)</p>