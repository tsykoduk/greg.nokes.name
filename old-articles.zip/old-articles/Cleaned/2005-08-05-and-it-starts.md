---
id: 711
title: 'And it starts...'
date: 2005-08-05T08:46:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/and-it-starts
permalink: /2005/08/05/and-it-starts/
categories:
  - Computers! and Code!
---
<blockquote>Five proof-of-concept viruses that target Monad, the next version of Microsoft's command prompt, were included in a recently published virus writing magazine, according to Mikko HyppÃ¶nen, the director of antivirus research at F-Secure.
	</blockquote>

	<p>- <a href="http://zdnet.com.au/news/security/soa/Windows_Vista_tool_targeted_by_virus_writers/0,2000061744,39205746,00.htm">ZDNet Australia</a></p>


	<p>Heh - and it starts. It's not even out yet and it has more viruses then <span class="caps">OS X</span> and Linux/BSD.</p>