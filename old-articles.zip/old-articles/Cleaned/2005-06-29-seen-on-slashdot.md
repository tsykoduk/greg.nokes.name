---
id: 591
title: Seen on Slashdot
date: 2005-06-29T13:09:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/seen-on-slashdot
permalink: /2005/06/29/seen-on-slashdot/
categories:
  - Philosophy! and Politics!
---
<blockquote>In his maiden speech to the House of Commons, the Hon. Member for Copeland, Jamie Reed MP, announced that he is a Jedi: "as the first Jedi Member of this place, I look forward to the protection under the law that will be provided to me by the Bill"</blockquote>

	<p>From <a href="http://politics.slashdot.org/article.pl?sid=05/06/29/1740254&#38;from=rss">Slashdot</a></p>


	<p>And here is the comment stream that makes this so intresting:</p>


	<blockquote> The Force is <strong>retarded</strong> with this one... (Score:4, Funny)
	by TripMaster Monkey (862126) * on Wednesday June 29, @02:23PM (#12943117)
	(Last Journal: Tuesday May 17, @11:38AM)

	<p>This whole Jedi religion [scaryplace.com] dreck has now officially gone too far. To those misguided simpletons out there who insist on calling themselves 'Jedi knights', I offer you this chance to prove yourselves:</p>


		<ul>
		<li>Just build a lightsaber. A real one. That's all.</li>
		</ul>


	<p>What's that...you can't? Don't have suitable raw materials, you say?
	OK...that's fair...how about this, then:</p>


		<ul>
		<li>Force choke me. From where you are right now. Go ahead...it's OK.</li>
		</ul>


	<p>Are you doing it? I'm not feeling anything...</blockquote></p>


	<p>And ...</p>


	<blockquote> Re:The Force is <strong>retarded</strong> with this one... (Score:5, Insightful)
	by Phillup (317168) on Wednesday June 29, @03:07PM (#12943653)
	There's no such thing as the force, and there never will be

	<p>And, this is different from other religions how?</blockquote></p>


	<p>I think that a lot of religous folks should take these comments to heart. And I am not just talking about Christians here. There are a lot of other religous folks that feel that they have the exclusive ownership of some universal truth that transends all, but cannot be proven by empirical or logical reasoning.</p>


	<p>To this I say - Bull. Faith is not enough to validate a universal truth.</p>


	<p>Let's look at what the Truth about Truth is:</p>


	<blockquote>truth (trÅ«th) pronunciation
	n., pl. truths (trÅ«THz, trÅ«ths).

	   1. Conformity to fact or actuality.
	   2. A statement proven to be or accepted as true.
	   3. Sincerity; integrity.
	   4. Fidelity to an original or standard.
	   5.
	         1. Reality; actuality.
	         2. often Truth That which is considered to be the supreme reality and to have the ultimate meaning and value of existence.</blockquote>

	<p>(From <a href="http://www.answers.com/truth&#38;r=67">Answers.com</a>). We can throw out meaning #2 right now, as it is <a href="http://www.answers.com/recursive">recursive.</a> Truth, by definition, is based in fact. Not faith. When some one decides to blow themselves up, I would hope that they have truth on their side, and not faith. Did Jesus want people to declare Crusades in his name? Burn witches in his name? Or, did he want people to just get along and love one and another?</p>


	<p>I do not discount people's right to choose what they believe. However, this belief should be held with the understanding that it might not be consistent with fact or reality. This should temper their understanding of other's choices to believe as they see fit. When you understand that you, in point of fact, do not really understand how the universe works, it makes you more humble. We are like worms living in an apple. We think that is the entire world, not seeing the tree, roots, seeds and other apples.</p>