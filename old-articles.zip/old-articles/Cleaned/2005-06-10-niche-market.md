---
id: 522
title: Niche Market
date: 2005-06-10T12:06:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/niche-market
permalink: /2005/06/10/niche-market/
categories:
  - Fun!
---
<blockquote>AbysS (11:20 PM) : I accIdentally took my dice home from gaming last week :<del>) they were in my pocket :</del>)
	Kaedenesque (11:20 PM) : Why were your dice in your pocket?</blockquote>

	<p>Thus starts an interesting discussion <a href="http://www.livejournal.com/users/morpheus0013/163337.html">over on the Rubber Becca's</a> site..</p>


	<p>Warning! This is not for the prudish!</p>