---
id: 195
title: Feds Hack Wireless Network in 3 Minutes
date: 2005-04-05T10:14:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/feds-hack-wireless-network-in-3-minutes
permalink: /2005/04/05/feds-hack-wireless-network-in-3-minutes/
categories:
  - Computers! and Code!
---
<p><a href="http://hardware.slashdot.org/article.pl?sid=05/04/05/1428250&#038;from=rss">From Slashdot..</a></p>


<blockquote>from the still-can't-balance-budget dept.
xs3 writes At a recent <span class="caps">ISSA</span> (Information Systems Security Association) meeting in Los Angeles, a team of <span class="caps">FBI</span> agents demonstrated current <span class="caps">WEP</span>-cracking techniques and broke a 128 bit <span class="caps">WEP</span> key in about three minutes. Special Agent Geoff Bickers ran the Powerpoint presentation and explained the attack, while the other agents (who did not want to be named or photographed) did the dirty work of sniffing wireless traffic and breaking the <span class="caps">WEP</span> keys. <a href="http://www.tomsnetworking.com/Sections-article111.php">This article</a> will be a general overview of the procedures used by the <span class="caps">FBI</span> team.</blockquote>

<p>And people think that I am paranoid for running a firewall between my Wireless and Wired LANs.</p>


<p>Next step for me is <span class="caps">IPSEC</span>/VPN thru the firewall for access from my laptop. I will have it set up so that I can access my files and printers from anywhere with an internet connection. But first I have to re-wire the house.. :)</p>