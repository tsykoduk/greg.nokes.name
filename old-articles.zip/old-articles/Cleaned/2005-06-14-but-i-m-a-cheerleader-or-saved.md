---
id: 534
title: 'But I'm a Cheerleader, or Saved!'
date: 2005-06-14T15:15:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/but-i-m-a-cheerleader-or-saved
permalink: /2005/06/14/but-i-m-a-cheerleader-or-saved/
categories:
  - Philosophy! and Politics!
---
<p>I saw parts of <a href="http://www.imdb.com/title/tt0179116/">But I'm a Cheerleader</a> - and honestly, could not get past the horrid acting. <a href="http://www.imdb.com/title/tt0332375/">Saved</a> was funny as heck, and probably had a better ending. However, I did not think that <a href="http://www.loveinaction.org/">things</a> like that actually existed!</p>


	<p>Imagine my horror when I read the following on <a href="http://hereticalideas.com/index.php?p=3020">Heretical Ideas</a>.</p>


	<blockquote>Well today, my mother, father, and I had a very long "talk" in my room where they let me know I am to apply for a fundamentalist christian program for gays. They tell me that there is something psychologically wrong with me, and they "raised me wrong." I'm a big screw up to them, who isn't on the path God wants me to be on. So I'm sitting here in tears, joing the rest of those kids who complain about their parents on blogs - and I can't help it.</blockquote>

	<p>Not really beliving, I <a href="http://www.dailykos.com/story/2005/6/10/20406/0177">followed</a> a <a href="http://blog.myspace.com/index.cfm?fuseaction=blog.view&#38;friendID=7428306&#38;blogID=29364299&#38;Mytoken=20050614144332">few</a> <a href="http://www.gbconline.net/templates/cusgermantown/details.asp?id=20898&#38;PID=39132">links</a>.  All that I can say is 'wow'.</p>


	<p>Justus has a <a href="http://davejustus.blogspot.com/2005/06/parental-notification.html">post</a> today that is somewhat related about parential notification in cases of abortion. He says</p>


	<blockquote>I will back up anyone on having as a part of parental control laws a strong system of counseling and child protective services to deal with this sort of problem. The idea though that a 13 yo girl, when having these sort of problems and facing the need for an abortion should just have minimal tools to try and be self reliant is repellent however.</blockquote>

	<p>This same topic applies here - however it is a fine line. When do we allow the goverment to step in and stop what could amount to toture? When is the freedom of the child eclipsed by the freedoms of the parents to raise their child as they see fit?</p>