---
id: 735
title: The Inventor of the @?
date: 2005-08-12T10:05:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-inventor-of-the
permalink: /2005/08/12/the-inventor-of-the/
categories:
  - Computers! and Code!
---
<p><a href="http://openmap.bbn.com/~tomlinso/ray/home.html">Ray</a>  is the 'father' of Email - and no he did not invent the 'at sign'. But he did make email address like the ones we use today, well, like the ones that we use today.</p>