---
id: 755
title: Mentioned in last months Network World
date: 2005-08-16T20:23:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mentioned-in-last-months-network-world
permalink: /2005/08/16/mentioned-in-last-months-network-world/
categories:
  - Mundane
---
<p>Yep - little old me!</p>


	<blockquote>Graphically beautiful, greg.nokes.name is the home of the online ramblings of Greg Nokes, who offers a decidedly political bent that focuses on ending poverty around the world.</blockquote>

	<p>Graphically Beautiful - I'm swooning!</p>


	<p>Read the entire story <a href="http://www.networkworld.com/you/2005/072505-blogs.html">here</a></p>