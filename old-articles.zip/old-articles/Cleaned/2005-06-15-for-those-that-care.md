---
id: 548
title: For those that care
date: 2005-06-15T16:16:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/for-those-that-care
permalink: /2005/06/15/for-those-that-care/
categories:
  - Philosophy! and Politics!
---
<p>Terri Schiavo's Autopsy <a href="http://news.google.com/news?hl=en&#38;gl=us&#38;ie=UTF-8&#38;q=Schiavo+autopsy&#38;btnG=Search+News">findings</a> are in.</p>