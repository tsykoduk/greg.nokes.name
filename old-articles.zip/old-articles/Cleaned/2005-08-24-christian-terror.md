---
id: 790
title: Christian Terror?
date: 2005-08-24T07:45:55+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/christian-terror
permalink: /2005/08/24/christian-terror/
categories:
  - Philosophy! and Politics!
---
<p>I was just going to ignore this, but...</p>


	<blockquote>As you probably know, Pat Roberston called for the assassination of Hugo Chavez, the semi-democratically elected leader of Venezuala, and he is getting pilloried by both the right and the left on this...

	<p>Many are calling his remarks 'un-Christian.' I don't know that that criticism is appropriate. Certainly it is not clear to me that assassination would be precluded by the Christian faith.</blockquote></p>


	<p>-<a href="http://davejustus.blogspot.com/2005/08/robertson-and-chavez-assassination.html">Justus</a></p>


	<p>This was my response:</p>


	<p>That is a really scary comment. What is more scary, is that it can be true - depending on your interpretation of the Bible. If you follow J.C.'s version of Christianity - then no. Killing is simply not condoned at all.</p>


	<p>If you read the Old Testament - then heck yeah - kill all of the folks that you do not like, that live in your land, that look askance at your goats. This is what Abortion bombers and radical Irish Christians use to justify their deadly practices.</p>


	<p>I applaud the Christians that have actually come out and said that Robertsons comment was way out of line. To have a Religious leader from the US talking about an act of Terror like assassinating someone? That is what we are supposedly fighting against.</p>


	<p>Now, I do not advocate any legal action against Mr Robertson. He is well within his 1st Amendment rights to say such a thing. However, I feel that it is on our shoulders as fellow Americans to show the world that we do not agree with an extremist view such as that.</p>


	<p>If the people of Venezuela disagree with what their leader is espousing, then it is their job to make this thing right. America does not have the resources, nor the right to topple every government that we disagree with, and replace it with one of our liking.</p>


	<p>I do feel that democracy is probably one of the better forms of government that is out there, however it is not our place to force the rest of the world to follow our lead. When they are ready, They will do it. We have seen it in the former <span class="caps">USSR</span> and other places. People are generally smart creatures. They can usually see what is up, and make choices to take action.</p>


	<p>Dave went further in a comment:</p>


	<blockquote>Particularly that no dictorship has a right to exist, and any free nation wishing to topple a dictorship has the moral right to do so. Protecting another people from aggression, even agression from their own government, is allowable under just war theory.</blockquote>

	<p>I follow the 'Do not start it, but finish it' theory. There is no such thing as a '<em>just</em>' aggressive act. The only time that violence can be justified in any way is in self defense. That includes Governments - the only time that we can justify war is when we are attacked.</p>


	<p>The 'war on terror' is justifiable. <span class="caps">WW II</span> was justified. Iraq was not. Toppling Governments because we disagree with them is certainly not justifiable.</p>


	<p>However, since we are in Iraq, we need to make sure that the job is 100 percent done before we leave. If we just leave now, the Iraqi people will be left in quite a lurch.  No stable government, no stable anything. Many would die, and more then likely, the country would be worse off then when we started over there.</p>


	<p>That is unacceptable. We created this mess - we need to fix it. I fully support the troops, and Bush in saying that we have to stay the course.</p>