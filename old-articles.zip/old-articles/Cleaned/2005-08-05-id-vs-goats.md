---
id: 714
title: ID vs Goats
date: 2005-08-05T12:29:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/id-vs-goats
permalink: /2005/08/05/id-vs-goats/
categories:
  - Philosophy! and Politics!
  - Science!
---
<blockquote>Joe said: I see a building, and I can recognize that it was created by some intelligence, for some purpose. I may not know how it was built, or for what purpose, but the form and symmetry and structure (the sides are plumb and level, etc.) tell me it was created by intelligent design, and not a random occurance of stone and glass.

	<p>I answered: Setting aside the strawman nature of this analogy, imagine two men confronted with this building. One devotes his life to methodically studying what it's made of and how it was built. The other guy sacrifices a goat in front of it once a month.</p>


	<p>If you went to these men and asked them what they knew about the building, the first guy would show you his notes, explain his methods, and present the evidence for his claims. The second guy would ask if you had any spare goats.</p>


	<p>Intelligent Design is what you get when the second guy pretends to adopt the methods and terminology of the first in order to talk you out of your goats.</blockquote></p>


	<p>- <a href="http://dotclue.org/archives/002366.html">dotclue: "Intelligent Design" vs. science</a></p>