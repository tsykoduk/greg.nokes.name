---
id: 193
title: Good Taste
date: 2005-04-04T14:12:03+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/good-taste
permalink: /2005/04/04/good-taste/
categories:
  - Computers! and Code!
---
It seems that the theme that I have chosen for this site, won an award!
<blockquote>
<a href="http://www.alexking.org/software/wordpress/themes/blog/">WordPress 1.5 Themes</a>
Pixel Perfect Design Prize Winner

    * rdc* Theme
    * <strong>FastTrack</strong></blockquote>

<p><a href="http://wpthemes.info/posts/2005/03/21/fasttrack-the-most-wanted/">Congrats<a />!</p>


<p></a></p>