---
id: 486
title: Memey Goodness
date: 2005-05-27T15:25:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/memey-goodness
permalink: /2005/05/27/memey-goodness/
categories:
  - Fun!
---
<p>Gee - thanks <a href="http://poorrolemodel.blogspot.com/2005/05/meme.html">Jesster</a>.</p>


	<p>3 names I go by: Duk, Fred, Greg</p>


	<p>3 physical things I like about myself: Brain, Arms, Hair.</p>


	<p>3 physical things I dislike about myself: Buddha Belly, Scars, Lack of Endurance.</p>


	<p>3 parts of my heritage: Welsh, Scottish, Irish</p>


	<p>3 things I am wearing right now:  Clothes, Glasses and Shoes.</p>


	<p>3 favorite bands / musical artists: Pink Floyd, <span class="caps">KMFDM</span>, Paul Okenfold</p>


	<p>3 (of many) favorite songs: Genius of Love, Several Small Species of Animals in a Cave grooming with a pick, Starry Eyed Suprise</p>


	<p>3 things I want in a relationship: My Wife. :)</p>


	<p>3 physical things about the preferred sex that appeal to me: Personality, Hot Bod, Sense of Humor</p>


	<p>3 of my favorite hobbies: Gaming, Computers, Reading.</p>


	<p>3 things I want to do really badly right now: Sleep, Go to Starbucks, Eat a Cookie.</p>


	<p>3 things that scare me: Pain, Running so fast that I fall on my face, Running out of cookies.</p>


	<p>3 of my everyday essentials: Coffee, Computer, Book.</p>


	<p>3 careers you have considered or are considering: Spaceman, Computer Geek, Grownup.</p>


	<p>3 places you want to go on vacation: The Homeland (Scotland, Ireland, Wales), Asia, Under my bed.</p>


	<p>3 kids' names you like:  Justin Case (vetoed) Jaxon Kail (chosen) Mythic Starwalker (um. yeah. nothing to see here, citizen).</p>


	<p>3 things you want to do before you die: Not grow up. Go into space, retire.</p>


	<p>3 ways I am stereotypically a boy: Um. Gassy. Let's just leave it at that. Eat fast, Enjoy Girls.</p>


	<p>3 ways I am stereotypically a girl: Hmm.. Puts hands on head - trying to get in touch with Feminine Side... No luck, sorry.</p>


	<p>3 celeb crushes: Cujo, Mr Bean, King Arthur (from Monty Python's the Holy Grail.)</p>


	<p>3 people who are up next:  <a href="http://lifeinahandbasket.blogspot.com/">Mystic,</a> <a href="http://davejustus.blogspot.com">Dave,</a> <a href="http://emilyscraziness.blogspot.com">Emily</a> (when she gets back to the Internet)</p>