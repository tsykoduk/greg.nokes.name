---
id: 491
title: Freindly URLs
date: 2005-05-31T16:52:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/freindly-urls
permalink: /2005/05/31/freindly-urls/
categories:
  - Mundane
---
<p>Welp, I went and did it. Installed some more tweakage to the site that allows us to use freindly URLs to access pages. Not really that important, but pretty cool none-the-less.</p>