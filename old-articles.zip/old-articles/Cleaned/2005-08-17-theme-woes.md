---
id: 762
title: Theme woes
date: 2005-08-17T08:43:51+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/theme-woes
permalink: /2005/08/17/theme-woes/
categories:
  - Mundane
---
<p>Ok. so I blew my theme up. Still works fine under FireFox and Safari, but IE displays total uglyness.</p>


	<p>Switched to a 'temp' theme for the time being.</p>