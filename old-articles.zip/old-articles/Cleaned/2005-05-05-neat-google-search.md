---
id: 402
title: Neat Google Search
date: 2005-05-05T14:44:29+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/neat-google-search
permalink: /2005/05/05/neat-google-search/
categories:
  - Fun!
---
<p><a href="http://www.google.com/search?q=What%27s+the+answer+to+life%2C+the+universe%2C+and+everything%3F&#38;sourceid=mozilla-search&#38;start=0&#38;start=0&#38;ie=utf-8&#38;oe=utf-8&#38;client=firefox&#38;rls=org.mozilla:en-US:unofficial">here</a>.</p>