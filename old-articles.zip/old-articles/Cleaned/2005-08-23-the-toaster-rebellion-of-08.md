---
id: 777
title: 'The Toaster Rebellion of &#8217;08'
date: 2005-08-23T07:05:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-toaster-rebellion-of-08
permalink: /2005/08/23/the-toaster-rebellion-of-08/
categories:
  - Fun!
---
<blockquote>The appliance fanatics will no doubt tell you it was a lot worse than it really was. For the rest of us, though, it will go down as a humorous lesson for mankind. An historic footnote not quite on a par with the launching of Sputnik , but closer to when the Air Force shot down Larry Ellison's<sup><a href="#fn1">1</a></sup> <span class="caps">MIG</span>-23 because he just wouldn't stop buzz-strafing Bill Gates' bigger and better home.</blockquote>

	<p>-<a href="http://informationwarfare.blogspot.com/2005/08/toaster-rebellion-of-08.html">Information Warfare: The Toaster Rebellion of '08</a></p>


	<p>Ok.. you really need to check this story out. It is just cool!</p>