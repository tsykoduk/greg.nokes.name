---
id: 351
title: Call It A Hunch
date: 2005-04-26T11:29:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/call-it-a-hunch
permalink: /2005/04/26/call-it-a-hunch/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><a href="http://www.evilwhiteguy.com/blog/archive/2005/04/25/2311.aspx">Call It A Hunch</a>, but this guy is toast.</p>


	<p>Via <a href="http://sharpmarbles.stufftoread.com/">SaaM</a></p>