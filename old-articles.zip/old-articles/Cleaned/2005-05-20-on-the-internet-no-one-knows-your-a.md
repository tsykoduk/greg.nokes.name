---
id: 443
title: '&quot;On the internet no one knows your a ...&quot;'
date: 2005-05-20T08:12:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/on-the-internet-no-one-knows-your-a
permalink: /2005/05/20/on-the-internet-no-one-knows-your-a/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://www.spokane7.com/editions/story.asp?ID=70520">7 </a> has a good story about the power of Blogs and the new media.</p>


	<blockquote>The young author is identified in a tagline as "the chair of <a href="http://www.nwprogressive.org/">Permanent Defense</a>." That's the group he formed way back in junior high.</blockquote>

	<p>One of the really positive things about this New Media is that everyone can make a diffrence. It's the great equalizer.</p>


	<blockquote>What drives a teen to pour his energies into politics like that? "I was worried about the direction this nation was taking and I wanted to do something about it," he says.</blockquote>

	<p>While I might not agree with his politics, I applaud him for letting his voice be heard. It's only through discourse that we can advance.</p>