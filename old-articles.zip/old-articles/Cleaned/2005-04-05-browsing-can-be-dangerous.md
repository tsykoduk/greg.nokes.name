---
id: 197
title: 'Browsing can be dangerous...'
date: 2005-04-05T12:57:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/browsing-can-be-dangerous
permalink: /2005/04/05/browsing-can-be-dangerous/
categories:
  - Fun!
---
<p>Especially when you find <a href="http://www.elvistrooper.com/menu.htm">The Elvis Trooper</a>.</p>


<p>Oh my.</p>


<p>Hat tip <a href="http://blog.ziffdavis.com/katt/archive/2005/04/05/6521.aspx"> The Katt</a></p>