---
id: 88
title: Saw this, and just had to share
date: 2005-02-16T13:44:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/saw-this-and-just-had-to-share
permalink: /2005/02/16/saw-this-and-just-had-to-share/
categories:
  - Fun!
---
<center><img src="http://mortal-seraphim.com/images/blog/fukitol.jpg"/></center><br /><br />Hat Tip, <a href=http://mortal-seraphim.com>Mortal Seraphim</a>