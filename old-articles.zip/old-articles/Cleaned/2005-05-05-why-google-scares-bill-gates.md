---
id: 404
title: Why Google Scares Bill Gates
date: 2005-05-05T15:13:47+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/why-google-scares-bill-gates
permalink: /2005/05/05/why-google-scares-bill-gates/
categories:
  - Computers! and Code!
---
<blockquote>What does Google make of Microsoft's growing animosity and paranoia? Although neither the co-founders nor <span class="caps">CEO</span> Schmidt would comment for this story, Schmidt told an audience of Internet pioneers at <span class="caps">UCLA</span> last fall, "One of the criticisms that the media makes is to compare Google to previous-generation companies. Google is trying to solve the next problem, not the last problem."</blockquote>

	<p>Very good <a href="http://www.fortune.com/fortune/technology/articles/0,15114,1050065-5,00.html">article</a> - I highly recommend reading it.</p>


	<p>Hat tip <a href="http://davejustus.blogspot.com/2005/05/google-vs-microsoft.html">Justus</a> and <a href="http://reasonsedge.blogspot.com/2005/05/underdog.html">Reason's Edge</a></p>