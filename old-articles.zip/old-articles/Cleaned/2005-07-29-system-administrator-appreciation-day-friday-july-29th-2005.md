---
id: 697
title: System Administrator Appreciation Day Friday July 29th 2005
date: 2005-07-29T09:04:29+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/system-administrator-appreciation-day-friday-july-29th-2005
permalink: /2005/07/29/system-administrator-appreciation-day-friday-july-29th-2005/
categories:
  - Computers! and Code!
  - Fun!
---
<p><a href="http://www.sysadminday.com/">System Administrator Appreciation Day</a> is Friday July 29th 2005.</p>


	<blockquote>Let's face it, System Administrators get no respect 364 days a year. This is the day that all fellow System Administrators across the globe, will be showered with expensive sports cars and large piles of cash in appreciation of their diligent work</blockquote>

	<p>So, I am awaiting my piles of cash.</p>