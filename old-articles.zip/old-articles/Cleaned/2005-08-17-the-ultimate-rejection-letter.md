---
id: 773
title: The Ultimate Rejection Letter
date: 2005-08-17T21:21:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-ultimate-rejection-letter
permalink: /2005/08/17/the-ultimate-rejection-letter/
categories:
  - Fun!
---
<p>Herbert A. Millington
	Chair - Search Committee
	412A Clarkson Hall, Whitson University
	College Hill, <span class="caps">MA  34109</span></p>


	<p>Dear Professor Millington,</p>


	<p>Thank you for your letter of March 16.  After careful consideration, I
	regret to inform you that I am unable to accept your refusal to offer me
	an assistant professor position in your department.</p>


	<p>This year I have been particularly fortunate in receiving an unusually
	large number of rejection letters.  With such a varied and promising field
	of candidates, it is impossible for me to accept all refusals.</p>


	<p>Despite Whitson's outstanding qualifications and previous experience in
	rejecting applicants, I find that your rejection does not meet my needs at
	this time.  Therefore, I will assume the position of assistant professor
	in your department this August.  I look forward to seeing you then.</p>


	<p>Best of luck in rejecting future applicants.</p>


	<p>Sincerely,
	Chris L. Jensen</p>


	<p>(HT: <a href="http://www.chaosmatrix.org/library/humor/reject.html">Chaos Matrix</a>)</p>