---
id: 506
title: Freecycle
date: 2005-06-06T11:33:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/freecycle
permalink: /2005/06/06/freecycle/
categories:
  - Philosophy! and Politics!
---
<p>Nope - not a biking thing - a way to find people who want your old stuff (or find old stuff that you need)</p>


	<p>Spokane has a <a href="http://http://groups.yahoo.com/group/freecyclespokane">group</a> with almost 1300 members right now - so you might want to check it out.</p>


	<p>(Hat Tip, <a href="http://wabimysabi.blogdrive.com/archive/110.html">Wabi my Sabi</a>)</p>