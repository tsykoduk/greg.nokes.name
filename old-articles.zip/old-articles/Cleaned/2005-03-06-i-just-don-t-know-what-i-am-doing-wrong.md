---
id: 182
title: 'I just don't know what I am doing wrong..'
date: 2005-03-06T14:44:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-just-don-t-know-what-i-am-doing-wrong
permalink: /2005/03/06/i-just-don-t-know-what-i-am-doing-wrong/
categories:
  - Fun!
---
<center><a href="http://homokaasu.org/gematriculator/?referer" target="_blank"><img src="http://homokaasu.org/pics/g/e52.jpg" width="175" height="80" alt="This site is certified 52% EVIL by the Gematriculator" /></a></center>