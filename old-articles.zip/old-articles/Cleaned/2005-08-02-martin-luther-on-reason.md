---
id: 703
title: Martin Luther on Reason
date: 2005-08-02T05:45:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/martin-luther-on-reason
permalink: /2005/08/02/martin-luther-on-reason/
categories:
  - Philosophy! and Politics!
---
<blockquote>'Whoever wants to be a Christian should tear the eyes out of his Reason.â€</blockquote>

	<p>, <a href="Whoever wants to be a Christian should tear the eyes out of his Reason">Martin Luther</a>, HT: <a href="http://hereticalideas.com/index.php?p=3113">Heretical Ideas</a></p>


	<p>Also found:</p>


	<blockquote>Reason must be deluded, blinded, and destroyed. Faith must trample underfoot all reason, sense, and understanding, and whatever it sees must be put out of sight and ... know nothing but the word of God</blockquote>

	<p>and</p>


	<blockquote>Reason is the greatest enemy that faith has: it never comes to the aid of spritual things, but-more frequently than not-struggles against the Divine Word</blockquote>