---
id: 648
title: Costco Trumps Walmart!
date: 2005-07-12T21:19:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/costco-trumps-walmart
permalink: /2005/07/12/costco-trumps-walmart/
categories:
  - Mundane
---
<blockquote>But there's another company that is breaking the Wal-Mart mold: Costco Wholesale Corp., now the fifth-largest retailer in the U.S. While Wal-Mart pays an average of $9.68 an hour, the average hourly wage of employees of the Issaquah, Wash.-based warehouse club operator is $16. After three years a typical full-time Costco worker makes about $42,000, and the company foots 92% of its workers? health insurance tab.

	<p>How does Costco pull it off? How can a discount retail chain pay middle-class wages and still bring in over $880 million in net revenues? And, a cynic may ask, with Wal-Mart wages becoming the norm, why does it bother?</blockquote></p>


		<pre><code>- <a href="http://www.laborresearch.org/print.php?id=391">The Costco Challenge: An Alternative to Wal-Martization?</a></code></pre>


	<p>Interesting read and well worth the time. I personally only shop at Wally-World when I know that I cannot get the item elsewhere, or when the price delta is large. We normally shop at Costco, so it's nice to see that they try and treat their employees so well. It really shows, the checkers at Costco seem to be somewhat happy to be there. Wally-world ones usually exude tiredness.</p>