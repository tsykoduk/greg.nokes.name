---
id: 746
title: Gun Safety
date: 2005-08-14T19:29:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/gun-safety
permalink: /2005/08/14/gun-safety/
categories:
  - Fun!
---
<p>Yeah. <a href="http://www.putfile.com/media.php?n=03084899">This guy</a> needs to be sent back to a basic safety class.</p>