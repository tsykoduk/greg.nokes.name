---
id: 645
title: Site updates
date: 2005-07-11T16:27:48+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/site-updates-2
permalink: /2005/07/11/site-updates-2/
categories:
  - Mundane
---
<p>I removed the Make Poverty History banner - the G-8 summit is over, and they accomplished many of their laudable goals.</p>


	<p>I also put a rotating header picture up - hit refresh a few times. I do not have that many photos up yet - let me know what you think!</p>


	<p>-Tsyko</p>