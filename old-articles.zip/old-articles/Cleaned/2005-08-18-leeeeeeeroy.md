---
id: 775
title: Leeeeeeeroy!
date: 2005-08-18T06:44:52+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/leeeeeeeroy
permalink: /2005/08/18/leeeeeeeroy/
categories:
  - Fun!
---
<p>The whole <a href="http://www.google.com/search?client=safari&#38;rls=en&#38;q=leeroy+jenkins&#38;ie=UTF-8&#38;oe=UTF-8">Leeroy Jenkins</a> thing has spawned some interesting stuff. For example, <a href="https://greg.nokes.name/LJRemix.mp3">this</a>, <a href="https://greg.nokes.name/leeroy_techomix.MP3">this</a> and <a href="https://greg.nokes.name/LJmix.mp3">this</a>. There is a bunch more stuff like this out there, but these three are, <span class="caps">IMHO</span>, the best that I have come across.</p>