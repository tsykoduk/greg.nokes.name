---
id: 475
title: Top 10 Ways to Destroy the Earth
date: 2005-05-26T15:16:14+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/top-10-ways-to-destroy-the-earth
permalink: /2005/05/26/top-10-ways-to-destroy-the-earth/
categories:
  - Science!
---
<p><a href="http://www.livescience.com/technology/10ways_destroyearth.html">Top 10 Ways to Destroy the Earth</a></p>

<p>Yup - that says it all.
	<em>
	Edit: Sam has a better '10 ways' article <a href="http://ned.ucam.org/~sdh31/misc/destroy.html">here</a></em></p>