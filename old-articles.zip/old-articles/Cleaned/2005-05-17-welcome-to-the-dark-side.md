---
id: 424
title: 'Welcome to the Dark Side...'
date: 2005-05-17T12:05:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/welcome-to-the-dark-side
permalink: /2005/05/17/welcome-to-the-dark-side/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://chrenkoff.blogspot.com/2005/05/open-letter-to-george-lucas.html">Chrenkoff</a> explains 'the Dark Side' to Lucas...</p>