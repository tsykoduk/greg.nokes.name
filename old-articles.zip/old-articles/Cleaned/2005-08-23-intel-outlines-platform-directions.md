---
id: 778
title: Intel outlines platform directions
date: 2005-08-23T16:56:59+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/intel-outlines-platform-directions
permalink: /2005/08/23/intel-outlines-platform-directions/
categories:
  - Computers! and Code!
---
<blockquote>In the second half of 2006, Otellini said Intel will introduce the micro-architecture, which combines the strength of the company's current Intel NetBurst and Pentium M micro-architectures and adds new features.

	<p>The multicore foundation will help enable unique computer designs that will power the industry's most sophisticated and user-friendly digital home and office PCs, according to the company. It will also help IT managers increase responsiveness and productivity while at the same time reducing real-estate and electricity burdens company's face as server data centers grow.</blockquote></p>


	<p>-<a href="http://www.appleinsider.com/article.php?id=1244">AppleInsider</a></p>


	<p>Also check out the story (with Pictures!) at <a href="http://www.anandtech.com/tradeshows/showdoc.aspx?i=2503">AnandTech</a></p>


	<p>No unexpected news here. Sounds like Intel is jumping on to the <span class="caps">PPC</span> bandwagon - it's not raw clockspeed that matters, rather it's real preformance, power consumption and heat that really matters.</p>


	<p>I mean - who cares if you have a 6 gigahertz chip that melts down in 65 seconds? Really!</p>