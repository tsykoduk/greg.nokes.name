---
id: 301
title: 'I pledge allegiance to the moral majority...'
date: 2005-04-23T16:59:14+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-pledge-allegiance-to-the-moral-majority
permalink: /2005/04/23/i-pledge-allegiance-to-the-moral-majority/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://brain.mu.nu/#077597">Brain Fertilizer</a> says:</p>


<blockquote>Don't you think this anti-religious movement is getting out of hand?

<p>So was this open season on religious belief brought on by libertarians who feel uncomfortable finding themselves under the same big tent as conservative Christians in voting for Bush, or liberals who feel they lost the 2004 election on the basis of religious values?</blockquote></p>


<p>about this on <a href="http://michellemalkin.com/archives/002186.htm">Michelle Malkin</a>'s blog</p>


<blockquote>The Washington Times's Valerie Richardson has a story out today that wins my p.c.- hell-in-a-handbasket award:

    <span class="caps">DENVER</span>-The students in Vincent Pulciani's seventh-grade class were reciting the Pledge of Allegiance this week when they heard the voice over the intercom say something they'd never heard before, at least not during the Pledge.

<p>Instead of "one nation, under God," the voice said, "one nation, under your belief system."</blockquote></p>


<p>I ask this simple question:</p>


<p>Should our children be forced to mouth phrases which could mean nothing to them? If a Wiccan child is forced to pledge allegiance to a God that they do not believe in, does that do that child any good?</p>


<p>Would not God appreciate it more if it's heartfelt? Or, does he like to have people forced to love him?</p>


<p>I think that some Christians are seeing that their faith is on the decline. And this scares them.</p>


<blockquote>Wicca projected to be <a href="http://www.emediawire.com/releases/2005/4/emw231351.htm">3rd largest U.S. religion</a> by 2012</blockquote>

<blockquote>"Witchcraft is growing so fast on high school and college campuses that Wiccan visionaires are rushing to establish their own schools." This is meant as a warning to Christian parents. Chas Cliftion, editor of Pomegranate: The International Journal Of Pagan Studies has a collaborating statement: "We (Pagans) are like a third world country that can't put up enough elementary schools fast enough."</blockquote>

<p><a href="http://www.wordoftruthradio.com/articles/wohlberg.html">Steve Wohlberg</a>, <a href="http://www.endtimeinsights.com/site/v2_3/content/view/88/1/">Hour of the Witch</a></p>


<p>People have to realize that intolerance is no longer an option. People have started to look beyond their parents faith. Faith based on guilt, and forgiveness of our personal shortcomings by some larger then life man behind the curtain falls short logically, and spiritually.</p>


<p>Many people that I know prefer a belief structure based on personal responsibility, kindness, compassion and logic.</p>


<p>This belief might or might not include a belief in a God or Godhead. It's not relevant. What is important is that these people are kind, compassionate people.</p>


<p>And some would force them and their children to mouth allegance to a God that they do not believe in.</p>


<p>America - land of the free as long as you agree with the majority?</p>