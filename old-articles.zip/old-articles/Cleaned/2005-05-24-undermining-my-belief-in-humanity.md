---
id: 462
title: Undermining my belief in humanity
date: 2005-05-24T15:19:23+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/undermining-my-belief-in-humanity
permalink: /2005/05/24/undermining-my-belief-in-humanity/
categories:
  - Mundane
---
<blockquote><a href="http://www.mirror.co.uk/news/showbiz/tm_objectid=15552841&#038;method=full&#038;siteid=94762&#038;headline=light-sabre-duel-puts-two-in-hospital-name_page.html%5B/url%5D">Mirror.co.uk - News - Showbiz News - <span class="caps">LIGHT</span>-SABRE <span class="caps">DUEL PUTS TWO IN HOSPITAL</span></a>

<p><span class="caps">TWO</span> Star Wars fans are in a critical condition in hospital after duelling with lightsabres made by filling fluorescent light tubes with petrol.</p>


<p>The pair - a man aged 20 and a girl of 17 - are believed to have been filming a mock fight when one of the devices exploded in woodland on Sunday.</blockquote></p>


<p>Oh my.</p>


<p>And I often tell people that I really belive in the intellegence of humanity.</p>


<p>And then they go and do this.</p>