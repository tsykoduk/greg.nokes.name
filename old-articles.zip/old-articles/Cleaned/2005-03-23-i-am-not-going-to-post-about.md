---
id: 140
title: 'I am not going to post about...'
date: 2005-03-23T21:32:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-am-not-going-to-post-about
permalink: /2005/03/23/i-am-not-going-to-post-about/
categories:
  - Philosophy! and Politics!
---
<p>I am not going to <a href=http://www.danray.net/2005/03/19/terry-schiavo-case-gets-even-more-surreal>post</a> about certain <a href=http://civilliberty.about.com/cs/humaneuthinasia/a/bgTerry.htm>news</a> items <a href=http://pastordan.dailykos.com/story/2005/3/22/194615/400>from Florida</a>. And I will not point to to <a href=http://abstractappeal.com/schiavo/infopage.html>this site</a> that has a <a href=http://abstractappeal.com/schiavo/WolfsonReport.pdf>very good</a> unbiased look at the action. Really.<br /><br /><br />Nothing to see here blogizen. Move along.</p>