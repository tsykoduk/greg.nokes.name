---
id: 820
title: Five reasons NOT to use Linux
date: 2005-08-29T15:46:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/five-reasons-not-to-use-linux
permalink: /2005/08/29/five-reasons-not-to-use-linux/
categories:
  - Computers! and Code!
---
<blockquote> But, Linux isn't for everyone. Seriously. Here are my top five reasons why you shouldn't move to Linux . . .
</blockquote>

<p>Thus starts a really good <a href="http://www.linux-watch.com/news/NS8124627492.html">article</a> about Linux, Windows and Why to stay on Windows. I have ranted about a lot of these very issues lately - here is another persons take.</p>