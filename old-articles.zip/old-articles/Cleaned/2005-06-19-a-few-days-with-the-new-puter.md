---
id: 552
title: 'A few days with the new 'puter'
date: 2005-06-19T01:08:44+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-few-days-with-the-new-puter
permalink: /2005/06/19/a-few-days-with-the-new-puter/
categories:
  - Computers! and Code!
---
<p>And I am in love with my Mac Mini. <span class="caps">OS X</span> is slick, quick and very user friendly. The dashboard has quickly become a favorite application. I have a very cluttered dashboard. :)</p>


	<p>From automatically displaying some of my favorite comics to a slick word of the day applet this thing has a lot of cool features.</p>


	<p>My favorite is called 'Buzztracker'. They even have a <a href="http://www.buzztracker.org">website</a>. Ok, so the website came before the widget, but what ever. It displays a map of the world, with little red specks for news items, and ranks the areas of the world by how much news is generated. Today I have watched Gaza, which started with the lead at about 16%, end up 4th (even under Madrid) with only 6%. Cool stuff.</p>


	<p>Other then that, there is a ton of great software out there (yes, great software). I downloaded and installed NeoOffice/J, a port of Open Office for the Mac, and have had all the convenience of Open Office 1.x at my fingertips.</p>


	<p>Still posting from the widget for Wordpress. Oh - you have got to see the <span class="caps">RSS</span> reader in Safari. Wow. makes keeping up with my <span class="caps">RSS</span> feeds a snap.</p>


	<p>I feel sad, but I actually enjoy using this computer more then my Linux boxes. When Gnome or <span class="caps">KDE</span> gets to this level of sophistication, which I am sure that it will, I will be overjoyed.</p>


	<p>The only thing that I miss from Linux is the ability to skin Gnome or <span class="caps">KDE</span> so much. Especially Gnome. Apple has done a fantastic job of making the look and feel of <span class="caps">OS X</span> really polished, but I like to play with the icons and window borders a wee bit.</p>


	<p>Not a lot to complain about. The machine is really well built, silent, stylish, and seems to be crash proof. I have a firewall on my router, but I have not configured the one on this computer yet.</p>


	<p>Anyways, time for bed. Nite all!</p>