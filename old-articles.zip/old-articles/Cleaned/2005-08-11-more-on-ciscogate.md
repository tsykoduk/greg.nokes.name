---
id: 733
title: More on Ciscogate
date: 2005-08-11T21:48:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-on-ciscogate
permalink: /2005/08/11/more-on-ciscogate/
categories:
  - Computers! and Code!
---
<p>Wired has a really good reposting from the blog of the attorney that represented Mike Lynn during Ciscogate</p>


	<p>The two part story is <a href ="http://www.wired.com/news/technology/0,1282,68435,00.html">here</a> and <a href="http://www.wired.com/news/technology/0,1282,68466,00.html">here</a>.</p>


	<p>A must read!</p>