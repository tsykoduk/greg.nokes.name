---
id: 356
title: Dangerous Hacker!
date: 2005-04-27T13:34:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/dangerous-hacker
permalink: /2005/04/27/dangerous-hacker/
categories:
  - Computers! and Code!
  - Fun!
---
<blockquote>The story starts (I'm shortcutting here) with an [Please control your cussing] insulting everyone on the <span class="caps">IRC</span> channel. Most people there believed it was rather funny, but it got even more funny. For information: The dangerous hacker is called bitchchecker and the one being hacked and original author of the comments, who is talking here, is known as Elch...</blockquote>

	<p>You can read the entire story about this <a href="http://www.jellyslab.com/~bteo/hacker.htm">Dangerous Hacker!</a> at Total Illusions. Thanks <a href="http://www.slashdot.com">Slashdot</a> for the original story</p>