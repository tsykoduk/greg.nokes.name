---
id: 710
title: Cisco Movie
date: 2005-08-05T06:40:13+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cisco-movie
permalink: /2005/08/05/cisco-movie/
categories:
  - Computers! and Code!
---
<p>There is a really cool movie traveling the net <a href="http://downloads.oreilly.com/make/cisco.mov">highlighting</a> <a href="http://www.google.com/search?hl=en&#38;lr=&#38;client=safari&#38;rls=en&#38;q=ciscogate&#38;btnG=Search">Ciscogate</a> at Defcon. It's very funny....</p>


	<p>(HT: <a href="http://securityawareness.blogspot.com/2005/08/ciscogate-caught-on-video.html">Security Awareness for Ma, Pa and the Corporate Clueless</a>)</p>