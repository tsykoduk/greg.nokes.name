---
id: 456
title: Trial tribulations
date: 2005-05-23T10:46:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/trial-tribulations
permalink: /2005/05/23/trial-tribulations/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://www.spokane7.com/blogs/hard7/archive.asp?postID=1581">Frank</a> of Hard 7 reports this:</p>


	<blockquote>Democratic honcho Paul Berendt delivered the funniest, but most impolitic, line. Dismissing the <span class="caps">GOP</span>'s attempt to cite alleged felon votes to undermine Christine Gregoire's election as governor, Berendt said, "The Republican base has always been nonunion, white, blue-collar males, and that's who the felons are in the state of Washington." After months of pummeling from the right, the gloves are off on the Democratic side as well-and someone just slipped on a pair of brass knuckles.</blockquote>

	<p>The full story is <a href="http://www.nytimes.com/2005/05/23/national/23governor.html">here</a>.</p>


	<p>It's these kind of attacks that are making people sick of this whole process. With as many questions about the elections in Washington State, there should have been something done by the 'winner' a long time ago. If she was so sure of her victory it would have gone a long ways towards brining this fractured voters together if she had been able to assume power with out the great black cloud that hangs over her head now.</p>


	<p>I for one, think that we should bring <a href="http://www.un.org/Depts/dpa/ead/eadhome.htm">UN Election monitors</a> in for the next gubernatorial election.</p>