---
id: 527
title: First post from my Mac Mini
date: 2005-06-14T14:00:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/first-post-from-my-mac-mini
permalink: /2005/06/14/first-post-from-my-mac-mini/
categories:
  - Computers! and Code!
---
<p>Yup - I got a mac Mini for Fathers Day. Well, kind of for fathers day - it was a few days early. So this is my first post from the new box. I found a widget for Dashboard that posts to wordpress sites, and ho-boy it's slick.</p>