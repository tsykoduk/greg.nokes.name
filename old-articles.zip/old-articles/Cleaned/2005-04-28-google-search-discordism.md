---
id: 361
title: 'Google Search: discordism'
date: 2005-04-28T11:08:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-search-discordism
permalink: /2005/04/28/google-search-discordism/
categories:
  - Fun!
---
<p>Woot! Page one on a <a href="http://www.google.com/search?client=firefox-a&#038;rls=org.mozilla%3Aen-US%3Aofficial_s&#038;hl=en&#038;q=discordism&#038;btnG=Google%20Search">Google Search</a></p>


	<p>Heh,</p>