---
id: 558
title: Computer-generated webpage design
date: 2005-06-20T14:03:30+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/computer-generated-webpage-design
permalink: /2005/06/20/computer-generated-webpage-design/
categories:
  - Computers! and Code!
---
<p><a href="http://www.strangebanana.com/default.aspx">StrangeBanana</a> is the odd name of a cool tool for Website Design. What is does, is randomly crops together a stylesheet for a website layout. Pretty cool stuff!</p>