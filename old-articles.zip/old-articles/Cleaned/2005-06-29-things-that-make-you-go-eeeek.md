---
id: 590
title: Things that make you go eeeek
date: 2005-06-29T09:55:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/things-that-make-you-go-eeeek
permalink: /2005/06/29/things-that-make-you-go-eeeek/
categories:
  - Fun!
---
<p>Read the following (from <a href="http://sprg.ssl.berkeley.edu/~wcoburn/hpl/fungi.html">Fungi from Yuggoth</a>)</p>


	<blockquote>It is a certain hour of twilight glooms,
	Mostly in autumn, when the star-wind pours
	Down hilltop streets, deserted out-of-doors,
	But shewing early lamplight from snug rooms.
	The dead leaves rush in strange, fantastic twists,
	And chimney-smoke whirls round with alien grace,
	Heeding geometries of outer space,
	<em>While Fomalhaut peers in through southward mists.</em>

	<p>This is the hour when moonstruck poets know
	What fungi sprout in Yuggoth, and what scents
	And tints of flowers fill Nithon's continents,
	Such as in no poor earthly garden blow.
	Yet for each dream these winds to us convey,
	A dozen more of ours they sweep away!</blockquote></p>


	<p>Now, go look at <a href="http://www.newscientistspace.com/data/images/ns/9999/99997564F1.JPG">this</a> and realize that it's the star <em><a href="http://www.solstation.com/stars/fomalhau.htm">Fomalhaut</a></em>. No, <a href="http://www.newscientistspace.com/article/dn7564">Really</a>!</p>


	<p>Wonder what ol' Lovecraft really knew?</p>