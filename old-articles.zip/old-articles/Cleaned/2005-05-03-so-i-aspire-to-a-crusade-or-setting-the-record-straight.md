---
id: 386
title: So I aspire to a Crusade, or Setting the Record Straight
date: 2005-05-03T15:11:27+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/so-i-aspire-to-a-crusade-or-setting-the-record-straight
permalink: /2005/05/03/so-i-aspire-to-a-crusade-or-setting-the-record-straight/
categories:
  - Philosophy! and Politics!
---
<p>Cool! I am a crusader now!</p>


	<p>This just in from <a href="http://brain.mu.nu/">Brain Fertilizer</a>:</p>


	<blockquote>Yes, I do think there is a <a href="https://greg.nokes.name/?p=356">recently-undertaken campaign</a> against religion in America. <a href="http://www.mcgeheezone.com/weblog/index.php/weblog/categories/C12/">Here are some more indications</a> of that campaign.

	<p>As I said in the comments on the first linked post:</p>


	<p>...no one is going to convince me that after 200 years of having references to God in all sorts of government literature, that saying 'Under Godâ€ in the pledge is somehow suddenly an assault on religious freedom.</blockquote></p>


	<p>and</p>


	<blockquote> I'll say it plainly: It is retribution/revenge for the failure of the homosexual movement to win same-sex marriage rights across the entire nation. They blame religion for being the motive force behind the rejection, and so are trying to eliminate the free expression of religion nationwide.</blockquote>

	<p>The second one wins the <strong><span class="caps">WTF</span></strong> of the month award. Nuff' said on that.</p>


	<p>About the first - I have been totally mis-represented.</p>


	<p>1) I am not trying to stop anyone from any religious expression - with in the law.</p>


	<p>2) I do not feel that Christianity has some 'dark agenda'. In fact, far from it. I was married in a Christian Church, and plan on sending my children to Christian schools.</p>


	<p>What I do have, is a personal belief that is not Christian. Yes, I am a non-devout Buddhist. And I have a desire to discuss Buddhism, Christianity and other  ideologies. Why? I benefit from these discussions, as they force me to learn more about me, what I belive and point out flaws in my paradigm. I do not fear discorse. I fear small minded people taking away my freedom of Religion.</p>


	<p>I do, however feel that the Goverment is not a place for Religion. I feel that the Goverment should not lift any one religion above any other. That is a personal choice - like abortion, and people should be given the rights to make those choices on their own.</p>


	<p>I think that we all should have the right to practice what ever faith that we want. That means, I do not want me or my children to be forced to mouth platitudes to a God that I might nor might not belive in. I want them to have the <strong>choice</strong> to worship as they wish.</p>


	<p>The Framers of this noble country were very specific in their thoughts and writings on this subject - and it does not support this country as a "Christian only" Country. This country is a place where freedom is the law of the land. When people impinge on that freedom - for everyone, Christians, Buddhists, Muslems, Wiccans, etc - I think that is a bad thing.</p>


	<p>How can my defending <em>your</em> freedom to worship as you want be constituted as a "<i>campaign against religion in America.</i>" and "<i> trying to eliminate the free expression of religion nationwide</i>"?</p>