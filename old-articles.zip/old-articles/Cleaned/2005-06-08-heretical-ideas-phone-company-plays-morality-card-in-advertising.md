---
id: 514
title: Heretical Ideas Â» PHONE COMPANY PLAYS MORALITY CARD IN ADVERTISING
date: 2005-06-08T12:34:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/heretical-ideas-phone-company-plays-morality-card-in-advertising
permalink: /2005/06/08/heretical-ideas-phone-company-plays-morality-card-in-advertising/
categories:
  - Philosophy! and Politics!
---
<p>Did you know that:</p>


	<p><span class="caps">MCI</span> distributes child pornography?</p>


	<p>Verizon makes its employees 'accept homosexualityâ€ (as opposed to just asking them not to aggravate gay co-workers and customers)?</p>


	<p>God hates the major telecommunications carriers?</p>


	<p>Read the rest of this startling revelation <a href="http://hereticalideas.com/index.php?p=3011">here</a></p>