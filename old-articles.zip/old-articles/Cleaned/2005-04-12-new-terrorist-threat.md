---
id: 262
title: New Terrorist Threat!
date: 2005-04-12T22:18:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-terrorist-threat
permalink: /2005/04/12/new-terrorist-threat/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<blockquote>People of the United States! We are Unitarian Jihad! We can strike without warning. Pockets of reasonableness and harmony will appear as if from nowhere!
</blockquote>

<p>Jon Carroll, in the <a href="http://sfgate.com/cgi-bin/article.cgi?file=/chronicle/archive/2005/04/08/DDG27BCFLG1.DTL">San Francisco Examiner</a>, has the whole story.</p>


<p>Hat Tip <a href="http://www.sjgames.com/ill/archives.html?y=2005&#38;m=April&#38;d=13">SJ</a></p>