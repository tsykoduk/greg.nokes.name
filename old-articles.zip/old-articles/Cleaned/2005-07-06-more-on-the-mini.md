---
id: 627
title: More on the Mini
date: 2005-07-06T23:34:56+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-on-the-mini
permalink: /2005/07/06/more-on-the-mini/
categories:
  - Computers! and Code!
---
<p>So, I have been using the 'mini for several weeks. I am impressed. It's not a speed deamon, but it really 'gets r done!'.</p>


	<p>For example, I just got done putting together a short movie in iMovieHD - the file size is 9.5 gigs. It's about 40 min of video, pictures and music. It never slowed down. To be able to edit a 9.5 gig file with out a pause was really nice.</p>


	<p>Sheila was even able to jump in and play with the music transitions. So, here's the score.</p>


	<p>Plug in and get movies off camcorder - check.
	Import movies into and out of iMovieHD - check.
	Add pictures, music, titles and transitions - check.</p>


	<p>And all with out hitting help or google once.</p>


	<p>Pretty good!</p>