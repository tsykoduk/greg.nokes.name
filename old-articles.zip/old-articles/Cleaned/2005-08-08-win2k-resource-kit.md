---
id: 721
title: Win2k Resource Kit
date: 2005-08-08T09:16:16+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/win2k-resource-kit
permalink: /2005/08/08/win2k-resource-kit/
categories:
  - Computers! and Code!
---
<p>If you are like me, you often need a tool, like shutgui.exe. Now, you can pay some bucks to Microsoft to get their Resource Kit (a big book and a cd) - or you can go here: <a href="http://www.petri.co.il/download_free_reskit_tools.htm">Download Free Windows 2000 Resource Kit Tools</a> to get them. It's a life saver.</p>


	<p><em>use these tools at your own risk. most can really wonk up your computer if used incorrectly. It can be hard to figure out how to use these correctly, so buyer beware! In other words, if you wonk your computer up by playing with these, expect only laughter from me</em> :)</p>