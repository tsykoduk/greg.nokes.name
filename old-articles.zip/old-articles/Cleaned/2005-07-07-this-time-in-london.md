---
id: 628
title: This time in London.
date: 2005-07-07T05:27:06+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-time-in-london
permalink: /2005/07/07/this-time-in-london/
categories:
  - Philosophy! and Politics!
---
<blockquote>British Prime Minister Tony Blair condemned on Thursday a "barbaric" series of attacks in London and said it was "reasonably clear" that terrorists were behind the wave of explosions.

	<p>Blair said he planned to leave a G8 summit of world leaders in Scotland in "the next couple of hours" and return to London, but he added that he would fly back to Gleneagles later in the day to re-join the talks.</p>


	<p>"It's reasonably clear there have been a series of terrorist attacks," a somber-looking Blair said in his first comment on a series of blasts that rocked London earlier on Thursday.</blockquote></p>


	<p>-<a href="http://wireservice.wired.com/wired/story.asp?section=Breaking&#38;storyId=1060229&#38;tw=wn_wire_story">Wired News</a></p>


	<blockquote>Three explosions rocked the London subway and one tore open a packed double-decker bus during the morning rush hour Thursday. The blasts killed at least two people and reportedly injured more than 90 in what a shaken Prime Minister Tony Blair (video) said was a series of "barbaric" terrorist attacks.

	<p>Police reported "a number of fatalities" at one London subway station. "Things are still relatively confused," Superintendent John Morgan told reporters. </blockquote></p>


	<p>-<a href="http://www.cbsnews.com/stories/2005/07/07/world/main707053.shtml"><span class="caps">CBS</span> News</a></p>


	<p>My heart goes out to the brave people in England. No one deserves this kind of thing, and it simply goes to show that we have a lot of work ahead.</p>


	<p>Hat tip <a href="http://www.ofthemind.com/archives/2005/07/resolute_1.html">Of The Mind</a></p>