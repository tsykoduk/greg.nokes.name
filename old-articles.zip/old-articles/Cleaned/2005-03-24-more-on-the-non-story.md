---
id: 136
title: More on the non-story
date: 2005-03-24T15:27:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-on-the-non-story
permalink: /2005/03/24/more-on-the-non-story/
categories:
  - Philosophy! and Politics!
---
<p>So, I found <a href=http://www.kuro5hin.org/story/2005/3/20/0359/57987>this</a>. Warning - it has bad words and stuff.<br /><br />Many of the media stories sound just as silly and juvenile. When are people going to realize that we live in a free country? The 'Moral Majority' has no right dictating to us what to do and believe.<br /><br /><shakes head in disgust><br /><br />-Tsyko</shakes></p>