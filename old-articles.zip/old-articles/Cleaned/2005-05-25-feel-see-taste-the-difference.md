---
id: 467
title: Feel, see taste the difference
date: 2005-05-25T19:49:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/feel-see-taste-the-difference
permalink: /2005/05/25/feel-see-taste-the-difference/
categories:
  - Fun!
---
<blockquote><a href="http://www.funnyfox.org/theoffice.htm">Feel, taste, see the difference.
	</a>
	Guerilla marketing at its best</blockquote>

	<p>From <a href="http://integralpractice.blogharbor.com/blog">Integral Practice</a></p>