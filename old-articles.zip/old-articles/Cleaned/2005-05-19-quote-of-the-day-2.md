---
id: 435
title: Quote of the Day
date: 2005-05-19T09:50:44+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/quote-of-the-day-2
permalink: /2005/05/19/quote-of-the-day-2/
categories:
  - Mundane
---
<blockquote>Holden: <em>Ahh, Come on. That's a bunch of horse shit! Lando Calrissian was a black guy, you know, he got to fly the Millenium Falcon, what's the matter with you?</em>

	<p>Hooper: <em>Who said that?</em></p>


	<p>Holden: <em>I did. Lando Calrissian is a positive role model in the realm of Science Fiction and Fantasy.</em></p>


	<p>Hooper: <em>Fuck Lando Calrissian, Uncle Tom nigger! Always some white boy has got to invoke the Holy Trilogy. Bust this. Those movies are about how the white man keeps the brother man down, even in a galaxy far, far away. Check this shit, you got cracker farm boy Luke Skywalker, Nazi poster boy, blonde hair blue eyes. And then, you got Darth Vader, blackest brother in the galaxy, Nubian god.</em></p>


	<p>Bankie: <em>What's a Nubian?</em></p>


	<p>Hooper: <em>Shut the fuck upâ€¦Now, Vader's a spiritual brother, down with the Force and all that good shit. Then this cracker, Skywalker, gets his hands on a lightsaber and decides he's going to run the fuckin' universe, gets a whole <span class="caps">KLAN</span> of whites together. And they are goina' bust up Vaders hood, the Death Star. Now what the fuck do you call that?</em></p>


	<p>Bankie: <em>Intergalactic civil war?</em></p>


	<p>Hooper: <em>Gentrification! They goina' drive out the black element to make the galaxy quote/unquote safe for white folks. And Jedi's the most insulting installment. Because Vader's beautiful black visage is sullied when he pulls off his mask to reveal a feeble, crusty, old white man. They trying to tell us that deep inside, we all want to be white!</em></p>


	<p>Bankie: <em>Well, isn't that true?</em></p>


	<p>,<a href="http://www.viewaskew.com/chasingamy/">Chasing Amy</a></blockquote></p>


	<p>From <a href="http://hereticalideas.com/index.php?p=2976">Heretical Ideas</a></p>


	<p><span class="caps">IMHO</span> <a href="http://www.viewaskew.com/chasingamy/">Chasing Amy</a> was one of <a href="http://www.viewaskew.com/main.html">Smith's</a> best.</p>