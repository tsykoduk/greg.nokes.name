---
id: 180
title: 'My kung-foo is strong...'
date: 2005-03-07T18:45:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/my-kung-foo-is-strong
permalink: /2005/03/07/my-kung-foo-is-strong/
categories:
  - Fun!
---
<center><br /><a HREF="http://quiz.ravenblack.net/videogame.pl"><img BORDER=0 ALIGN="LEFT" WIDTH=150 HEIGHT=80 SRC="http://quiz.ravenblack.net/videogame/15.png" ALT="What Video Game Character Are You? I am Kung Fu Master." /></a>I am <b>Kung Fu Master</b>.<br /><br /><br />I like to be in control of myself. I dislike crowds, especially crowds containing people trying to kill me. Even though I always win, I prefer to avoid fights if possible. <a HREF="http://quiz.ravenblack.net/videogame.pl">What Video Game Character Are You?</a></center><br /><br />Thanks Again - <a href=http://emilyscraziness.blogspot.com/>Craziness...