---
id: 183
title: Green Tea out the Nose
date: 2005-03-04T14:45:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/green-tea-out-the-nose
permalink: /2005/03/04/green-tea-out-the-nose/
categories:
  - Fun!
---
<p>Green tea shot out of one's nose really hurts. Especially when it's hot. I can blame <a href=http://emilyscraziness.blogspot.com/2005/03/lotr-fun.html>Craziness</a> for this one! Go <a href=http://www.coalitionoftheswilling.net/archives/2005/03/some_people_hav.html>here</a> but keep the liquids away until you are done!</p>