---
id: 634
title: From Dork Tower
date: 2005-07-08T09:17:28+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/from-dork-tower
permalink: /2005/07/08/from-dork-tower/
categories:
  - Philosophy! and Politics!
---
<center><img src="http://archive.gamespy.com/comics/dorktower/images/ads/unionjack.gif" alt="" /></center>

	<p>(Hat Tip - <a href="http://archive.gamespy.com/comics/dorktower/">John</a>)</p>