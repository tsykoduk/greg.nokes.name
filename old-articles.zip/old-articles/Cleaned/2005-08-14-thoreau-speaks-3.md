---
id: 748
title: Thoreau Speaks
date: 2005-08-14T21:04:18+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/thoreau-speaks-3
permalink: /2005/08/14/thoreau-speaks-3/
categories:
  - Philosophy! and Politics!
---
<blockquote>May I love and revere myself above all the gods that men have ever invented. May I never let the vestal fire go out in my recesses.</blockquote>

	<p>-<a href="http://blogthoreau.blogspot.com/">Henry David Thoreau</a></p>