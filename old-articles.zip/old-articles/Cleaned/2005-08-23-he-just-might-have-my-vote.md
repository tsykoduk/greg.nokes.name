---
id: 784
title: He just might have my vote
date: 2005-08-23T17:18:06+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/he-just-might-have-my-vote
permalink: /2005/08/23/he-just-might-have-my-vote/
categories:
  - Philosophy! and Politics!
---
<p>It really depends on the politics. But <a href="http://www.walken2008.com/politics.html">he</a> gets major points for style!</p>