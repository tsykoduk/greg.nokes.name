---
id: 192
title: History of the Universe in 200 words or less
date: 2005-04-02T10:36:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/history-of-the-universe-in-200-words-or-less
permalink: /2005/04/02/history-of-the-universe-in-200-words-or-less/
categories:
  - Science!
---
<p>Yes, you too can read the History of the universe in 200 words or less <a href="http://members.bellatlantic.net/%7Evze3fs8i/hist/hist.html">Here</a>.</p>


<p>Hat Tip <a href="http://improbable.typepad.com/">Improbable Research</a></p>