---
id: 295
title: Playground Politics
date: 2005-04-30T11:42:05+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/playground-politics
permalink: /2005/04/30/playground-politics/
categories:
  - Philosophy! and Politics!
---
<p>A lot of world politics are just as inane and silly as the old days (well, old days for me) when I was in elementry school. It's a story of gangs of freinds, outsiders and the feelings that engenders. In my opionion we are too free to enter into treaties and keep them to long.</p>


	<p>Why? It's like this. Suppose that you are country A. You and Country B have a disagreement. B, C and D enter into a treaty orginization to 'defend themselves' in case you attack.</p>


	<p>This is all well and good so far.</p>


	<p>So, the disagreement ends. How would you feel if B, C, and D all stayed in the treaty? Would you feel safer, or less safe?</p>


	<p>Gangs tend to make people feel less safe. The normal response to a gang is to form a group of your own for "<em>self defense</em>".</p>


	<p>To bring this into foreign policy and the real world - orginizations such as <span class="caps">NATO</span> (which was formed to combat Soviet expansion) have lived their usefullness. Short term alliances are a good idea, long term freindships are a good idea. When we start collecting into groups for the express purpose of military defense or expansionism, well, that's just a bad idea.</p>