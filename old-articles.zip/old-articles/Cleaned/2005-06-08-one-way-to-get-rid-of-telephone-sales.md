---
id: 513
title: One way to get rid of telephone sales
date: 2005-06-08T09:49:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/one-way-to-get-rid-of-telephone-sales
permalink: /2005/06/08/one-way-to-get-rid-of-telephone-sales/
categories:
  - Fun!
---
<blockquote>"Ya? Hedlo"? (OK, maybe it's more Swedish than German but give me a break, it was 8:12am).
	"Hey Scarlett! How's it goin? Are you diggin' the new neighborhood"?</blockquote>

	<p>Read the rest on <a href="http://whyareweinthishandbasket.blogspot.com/">WhyAreWeInThisHandbasket</a></p>