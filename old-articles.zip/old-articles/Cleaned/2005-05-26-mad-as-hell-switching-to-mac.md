---
id: 474
title: Mad as hell, switching to Mac
date: 2005-05-26T13:42:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mad-as-hell-switching-to-mac
permalink: /2005/05/26/mad-as-hell-switching-to-mac/
categories:
  - Computers! and Code!
---
<p>Winn Schwartau says:</p>


<blockquote>In the coming weeks I'm going to keep a diary of an experiment my company began at 6 p.m. April 29, 2005 - an experiment predicated on the hypothesis that the WinTel platform represents the greatest violation of the basic tenets of information security and has become a national economic security risk. I do not say this lightly, and I have never been a Microsoft basher, either. I never criticize a company without a fair bit of explanation, justification and supportive evidence.

<p>I have come to the belief that there is a much easier, more secure way to use computers. After having spent several years focusing my security work on Ma, Pa and the Corporate Clueless, I also have come to the conclusion that if I'm having such security problems, heaven help the 98% of humanity who merely want a computer for e-mail and multimedia.</blockquote></p>


<p>Thus starts a really good <a href="http://www.networkworld.com/columnists/2005/052305schwartau.html">Story</a>  over at <a href="http://www.networkworld.com">Network World</a></p>


<p>For me, this is not just another switcher article. I have read Winn's security column for a while, and to see him lay out why the Wintel platform is so full of holes is intresting. He also has a blog called    <a href="http://securityawareness.blogspot.com/">Ma, Pa and the Corporate Clueless</a>. Good reading</p>


<p>So, go, read.</p>