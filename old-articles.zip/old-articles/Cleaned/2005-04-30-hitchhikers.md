---
id: 370
title: Hitchhikers
date: 2005-04-30T11:27:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hitchhikers
permalink: /2005/04/30/hitchhikers/
categories:
  - Mundane
---
<p>Saw <a href="http://hitchhikers.movies.go.com/">Hitchhikers</a> last night. I have been a fan of the series for years and years now - even having gone so far as to listen to the Radio <span class="caps">BBC</span> series a few (ok more then a few) years back. I must say - It was not worse then I thought it was going to be. I actually enjoyed it!</p>


<p>Not a must see, but if you like British Humor - this might be a good flick to watch.</p>