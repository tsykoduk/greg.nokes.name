---
id: 399
title: Why are we here?
date: 2005-05-05T13:51:57+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/why-are-we-here
permalink: /2005/05/05/why-are-we-here/
categories:
  - Philosophy! and Politics!
---
<blockquote>We no longer fear the biological events that once demanded an explanation, yet society still cannot accept the fact that human beings are in control of their own lives and nothing more.

	<p>It seems to me that the next logical step is for people to realize that there is no supreme being guiding their lives and determining their destiny. This is already starting to happen.</blockquote></p>


	<p>Mystic goes on in his <a href="http://blog.handbasket.info/?p=153">writing</a>, but I think that this point really has it down. <strong>We</strong> are responsible for who we are, what we do, and what mark we leave on the world.</p>