---
id: 232
title: Rebuild the Twin Towers?
date: 2005-04-08T16:08:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/rebuild-the-twin-towers
permalink: /2005/04/08/rebuild-the-twin-towers/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://vodkapundit.com/archives/007746.php">Vodkapundit - Rebuild Them</a></p>


<blockquote>We visited the <span class="caps">WTC</span> site after the attacks. On the plywood barrier next to the site people wrote personal messages. One of them struck a chord with me: it defiantly said, "It's still New York."

<p>I like the idea to rebuild the towers. Yes, almost 3000 people died that day: more than the number that died at Pearl Harbor. Rebuilding the towers says, "You can't beat us. You can't even slow us down." The enemy attacked building that were symbols. Fine. Rebuild the symbols they hate.</p>


<p><strong>I wouldn't put anti-aircraft guns on the top floor.</p>


<p>I would move the UN into one of the buildings.</strong></blockquote></p>


<p>Hat tip <a href="http://sandcastlesandcubicles.blogspot.com/">Cube</a></p>