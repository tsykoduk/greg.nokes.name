---
id: 59
title: Buddhist resources in Spokane
date: 2005-01-10T13:01:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/buddhist-resources-in-spokane
permalink: /2005/01/10/buddhist-resources-in-spokane/
categories:
  - Philosophy! and Politics!
---
* Benefaction Sangha of Spokane - UPDATE 2017, sadly site is gone
* [Spokane Buddhist Temple](http://www.spokanebuddhisttemple.org)
* [Sravasti Abbey](http://www.thubtenchodron.org)
* [Zen Center of Spokane](http://www.zencenterspokane.org)