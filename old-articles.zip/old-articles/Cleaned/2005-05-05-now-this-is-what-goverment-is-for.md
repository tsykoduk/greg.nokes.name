---
id: 401
title: Now, this is what goverment is for!
date: 2005-05-05T14:30:29+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/now-this-is-what-goverment-is-for
permalink: /2005/05/05/now-this-is-what-goverment-is-for/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<blockquote>  ]]]]              <span class="caps">LEGISLATURE OF THE STATE OF IDAHO</span>             ]]]]
	 Fifty-eighth Legislature                   First Regular Session - 2005

	                              <span class="caps">IN THE HOUSE OF REPRESENTATIVES</span>

	                             <span class="caps">HOUSE CONCURRENT RESOLUTION NO</span>. 29

	                                <span class="caps">BY WAYS AND MEANS COMMITTEE</span>

	  1                               <span class="caps">A CONCURRENT RESOLUTION</span>
	  2    <span class="caps">STATING LEGISLATIVE FINDINGS AND COMMENDING JARED AND  JERUSHA  HESS  AND  THE</span>
	  3        <span class="caps">CITY OF PRESTON FOR THE PRODUCTION OF THE MOVIE</span> "NAPOLEON <span class="caps">DYNAMITE</span><a href="http://www3.state.id.us/oasis/HCR029.html">...</a>"</blockquote>

	<p>I always liked <a href="http://maps.google.com/maps?ll=47.727539,-116.802343&#38;spn=0.464172,0.467606&#38;t=k&#38;hl=en">Idaho!</a></p>