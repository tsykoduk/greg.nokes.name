---
id: 549
title: Firefly back!
date: 2005-06-16T19:29:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/firefly-back
permalink: /2005/06/16/firefly-back/
categories:
  - Fun!
---
<p><strong>It's <span class="caps">BACK</span>!</strong></p>


	<p>TV.com <a href="http://www.tv.com/story/story.html&#038;story_id=335">reports:</a></p>


	<blockquote>Firefly, a science fiction series that was canceled midway through its first season on Fox, has found a new home on the Sci Fi Channel. All existing episodes will air this summer, though there is no word on a second season</blockquote>

	<p>And SciFi <a href="http://www.scifi.com/scifiwire2005/index.php?category=0&#38;id=31260">says</a>:</p>


	<blockquote>
	<span class="caps">SCI FI</span> Channel announced that it will air reruns of Fox's canceled SF series Firefly, including three episodes that never aired on Fox. <span class="caps">SCI FI</span> will air all 14 hours of the show, from creator Joss Whedon (Buffy the Vampire Slayer), starting July 22, in the 7 p.m. ET/PT Friday timeslot. It will be followed by new episodes of Stargate SG-1 at 8, Stargate Atlantis at 9 and Battlestar Galactica at 10.</blockquote>

	<p>Fantasic news. I hope, if the <a href="http://www.serenitymovie.com/">movie</a> does well, and the series does well, that SciFi will start in on new episodes. What a Friday lineup! Get your <span class="caps">DVR</span>'s primed for July 22!</p>


	<p>If you have not seen the trailer for the FireFly move - run, don't walk <a href="http://www.serenitymovie.com/">here</a> and watch it. Several times.</p>