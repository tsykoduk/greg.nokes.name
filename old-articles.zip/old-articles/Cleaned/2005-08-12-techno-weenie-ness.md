---
id: 738
title: Techno-weenie-ness
date: 2005-08-12T22:23:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/techno-weenie-ness
permalink: /2005/08/12/techno-weenie-ness/
categories:
  - Computers! and Code!
---
<p>So.. just added a new feature to this site. If you look down the sidebar, you will see a new iTunes section. This shows - realtime - what is currently playing on my 'puter and what the last ten songs were.</p>