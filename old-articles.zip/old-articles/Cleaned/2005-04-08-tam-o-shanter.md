---
id: 226
title: 'Tam O' Shanter'
date: 2005-04-08T10:13:05+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/tam-o-shanter
permalink: /2005/04/08/tam-o-shanter/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://www.robertburns.org/works/308.shtml">Robert Burns: </a></p>


<p><em><center>When chapman billies leave the street,
And drouthy neibors, neibors, meet;
As market days are wearing late,
And folk begin to tak the gate,
While we sit bousing at the nappy,
An' getting fou and unco happy,
We think na on the lang Scots miles,
The mosses, waters, slaps and stiles,
That lie between us and our hame,
Where sits our sulky, sullen dame,
Gathering her brows like gathering storm,
Nursing her wrath to keep it warm. </center></em></p>