---
id: 792
title: Google Talk
date: 2005-08-24T16:37:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-talk
permalink: /2005/08/24/google-talk/
categories:
  - Computers! and Code!
---
<p><a href="http://www.google.com/talk/">Google Talk</a> came out last nite - it's a jabber based IM system with some cool features right now. I have it spun up on my Mac at home. Check it out!</p>


	<p>I give it 3 out of 4 dukks.</p>