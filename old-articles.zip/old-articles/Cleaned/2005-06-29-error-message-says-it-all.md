---
id: 589
title: Error message says it all
date: 2005-06-29T09:45:51+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/error-message-says-it-all
permalink: /2005/06/29/error-message-says-it-all/
categories:
  - Computers! and Code!
  - Fun!
---
<center><a href="http://atom.smasher.org/error/gallery/"><img src="http://pic.smasher.org/default13.png" alt="" /></a></center>