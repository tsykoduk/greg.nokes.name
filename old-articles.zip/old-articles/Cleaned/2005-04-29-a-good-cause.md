---
id: 368
title: A good Cause!
date: 2005-04-29T16:22:35+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-good-cause
permalink: /2005/04/29/a-good-cause/
categories:
  - Mundane
---
<p>My <a href="http://noctrine.blogspot.com">brother</a>, Nelson, is 'Riding for Aids'. This explains what this is all about:</p>


<blockquote>Last June I participated in the <span class="caps">AIDS</span> LifeCycle 3 as a volunteer. Over 1200 riders pedaled the 585 mile route from San Francisco to Los Angeles, raising $4.9 million dollars. I am registered as a rider for <span class="caps">AIDS</span> LifeCycle 4, and am committed to raising $2500 to participate in the ride. This money goes directly to the San Francisco <span class="caps">AIDS</span> Foundation to support people living with <span class="caps">HIV</span> and <span class="caps">AIDS</span> in the Bay Area. This foundation provides counseling, free or reduced-cost medications to individuals, public policy and advocacy, and much more.

<p>You can find out more information about the <span class="caps">AIDS</span> LifeCycle and affiliated organizations on my fundraising website:</p>


<p><a href="http://www.sonic.net/<sub>olofin"&gt;<em>http://www.sonic.net/</sub>olofin</em></a></p>


<p>The site has answers to common questions, a training log, photos, and information on how to sponsor me in my ride to end <span class="caps">AIDS</span>.</p>


<p>Donations of any size are greatly appreciated.</p>


<p>Thank you for your support,</p>


<p>Nelson</blockquote></p>


<p>Lil Bro is on his way to his goal , let's all pitch in a few dollars and see if we can hit the mark!</p>


<center><a href="https://www.aidslifecycle.org/donate/5270">Make a Donation</a></center>

<p>(This is reposted from my old site. He is on the way - he has $1,087 out of the $2,500 that he needs. If everyone tosses in a buck or two, that will put him a long way towards his goal. This is a great thing that he is doing, and Sheila and I are <strong>very</strong> proud of him.)</p>