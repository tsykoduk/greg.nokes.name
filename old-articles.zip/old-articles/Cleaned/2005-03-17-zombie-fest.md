---
id: 143
title: Zombie-Fest
date: 2005-03-17T15:25:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/zombie-fest
permalink: /2005/03/17/zombie-fest/
categories:
  - Fun!
---
<table align="center" cellpadding="20"> <tbody><tr> <td align="center"> <font size="5"><b>Official Survivor</b></font><br /> Congratulations! You scored 69%! </td> </tr> <tr> <td><br />Whether through ferocity or quickness, you made it out. You made the right choice most of the time, but you probably screwed up somewhere. Nobody's perfect, at least you're alive. </td> </tr> <tr> <img src="http://is1.okcupid.com/mt_pics/773/773812361575599080/5349989821747660792-3.jpg" hight="400" width="400"/>  </tr> </tbody></table> <br /><br /><br /> <table cellpadding="20"> <tbody><tr> <td> <span id="comparisonarea">My test tracked 1 variable How you compared to other people <i>your age and gender</i>:<blockquote><table border="0" cellpadding="0" cellspacing="4"><tbody><tr><td valign="middle"><table bgcolor="black" border="0" cellpadding="0" cellspacing="1"><tbody><tr><td bgcolor="#b2cfff" height="20" width="141"><img src="http://is1.okcupid.com/graphics/0.gif"/></td><td bgcolor="white" width="9"><img src="http://is1.okcupid.com/graphics/0.gif"/></td></tr></tbody></table></td><td valign="middle">You scored higher than <b>94%</b> on <b>survivalpoints</b></td></tr></tbody></table></blockquote></span> </td> </tr> </tbody></table> <table cellpadding=20><tr><td>Link: <a href='http://www.okcupid.com/tests/take?testid=5349989821747660792'>The Zombie Scenario Survivor Test</a> written by <a href='http://www.okcupid.com/profile?tuid=773812361575599080'>ci8db4uok</a> on <a href='http://www.okcupid.com'>Ok Cupid</a></td></tr></table><br /><br />Gee thanks for another waste of time <a href=http://davejustus.blogspot.com/>Dave