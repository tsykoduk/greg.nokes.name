---
id: 429
title: Can the Kingdom of Heaven be fought for?
date: 2005-08-04T19:13:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/can-the-kingdom-of-heaven-be-fought-for
permalink: /2005/08/04/can-the-kingdom-of-heaven-be-fought-for/
categories:
  - Philosophy! and Politics!
---
<p>Our history is chock full of some gut-wrenching atrocities that have been committed in the name of various gods. Does this bring us closer to the Kingdom of Heaven? Nirvana? WallyWorld?</p>


	<p>I would say no. In fact, I would say that violence should never be used aggressively. Self Defense is one thing, but going out and killing others for no good reason? Or, even for a good reason?</p>


	<p>If we assume that a stepping stone on the path to WallyWorld is a world where peace reigns, then we can look at every aggressive act as moving us further away from WallyWorld. When you are aggressively violent, and even when you are defensively violent, you do more then just hurt some one's body, you damage the psyche of the community. Looking at 9/11, the people that did that were horrid people. They scarred the Americans collective psyche for generations to come. We are still dealing with the ramification of this. The Patriot Act, the War Hawks, the extreme split between the Right and Left.</p>


	<p>A small percentage of us shouted for revenge! We wanted the people responsible dead. A larger percentage of us shouted for Justice! We wanted to see the perpetrators brought to justice. Another group of us shouted for, well, nothing. To hide and hope that it would not happen again.</p>


	<p>My feelings at the time ranged from Revenge to Justice. But, the point is that there is an equal and opposite reaction for every action. That is what the Terrorists see, and count on. Look at the shooting today in <a href="http://www.sciencedaily.com/upi/?feed=TopNews&#38;article=UPI-1-20050804-18415500-bc-israel-bus-1stld.xml">Gaza</a>. They count on the fact that the targets will become enraged, and topple the peace process.</p>


	<blockquote>With the notion that "to kill an infidel is not murder - it's the path to heaven", there was the prevalent concept that heaven can be won through putting non-believers through "hell", which they are deemed to deserve. But how can anyone be rewarded karmically through acts of hateful violence? "God wills it!" is uttered as a war cry throughout the film, but it is obvious in many instances that it was the deluded men themselves, who willed what they did, while the gods themselves remain ominously silent. It forces the audience to question how much were they fighting for God and how much for themselves, to covet land and wealth. Grave ungodliness in the name of God?</blockquote>

	<p>- <a href="http://www.buddhistchannel.tv/index.php?id=12,1178,0,0,1,0">Can the Elusive "Kingdom of Heaven" be Fought For?</a> about the movie <a href="http://www.kingdomofheavenmovie.com">Kingdom of Heaven</a></p>


	<p>If God is in fact a God of Love, then how can people even think that he would have us make war on each other, and maim, torture and kill each other <em>in his name</em>? I believe very strongly that acts of war, torture and what have you are in fact not divine in origin, rather are man made, and God is simply used as convenient rationalization. I believe that if God is still watching over us, if there is a God, he/she/it is disgusted.</p>


	<p>More then that: Entrance into WallyWorld is predicated on a certain behavioral standard. It is rare to see such a standard which includes mass murder. In the Buddhist philosophy, each negative act garners you bad karma. Any bad karma that you have, must be worked off before you can reach the level of calm that enlightenment requires. So, the mass murderers probably will not attain WallyWorld any time soon.</p>


	<p>The question of self defense has often bothered me. As a Buddhist, if I am attacked, am I simply to stand and die? If my Family is attacked, am I just to watch in horror? That is where I draw the line. I am a pacifist. I do not think that killing or violence is a good answer to any question. However, when force is brought to the table, I will respond in a fashion that will assure the safety of me and mine.</p>


	<p>I have a very high level of respect for the Police Officers and Solders in this world. Most do an outstanding job of taking the community on as 'family' and protecting them all. The eventual answer to violence will be two pronged. First we have to assure that the misguided people who think that they can initiate violence to get what they want are stopped cold. We also need to be able to teach a lifestyle of tolerance, and peaceful response to stress.</p>


	<p>This War on Terror will not be won with bullets and bombs - if you consider winning to be a more peaceful world. However, those bullets and bombs just might buy us the time to engage in the discussion and diplomacy that <em>will</em> win the war.</p>