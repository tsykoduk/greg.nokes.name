---
id: 753
title: 'Canada&#8217;s Secret Mission to Take Over the US'
date: 2005-08-16T15:43:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/canada-s-secret-mission-to-take-over-the-us
permalink: /2005/08/16/canada-s-secret-mission-to-take-over-the-us/
categories:
  - Fun!
---
<blockquote>Whistler Blower: Canada's Secret Mission to Take Over the US

	<p>While you Americans are distracting yourselves overseas, Canada has been secretly preparing for final battle plans to take over the US.</blockquote></p>


	<p><a href="http://www.samanthaburns.com/archives/2005/08/whistler_blower.html">Samantha Burns</a> goes on to outline this dasterdy plot. Yes, I will say it - this is a plot of the likes the world has not seen since Snidley Whiplash was on the scene.</p>


	<p>Oh my! Thank <span class="caps">GOD</span> for people like Ms. Burns - she is truly an American Hero!</p>