---
id: 823
title: 'Katrina - Favorite Photo'
date: 2005-08-30T10:31:55+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/katrina-favorite-photo
permalink: /2005/08/30/katrina-favorite-photo/
categories:
  - Mundane
---
<div style="float: right; margin-left: 10px; margin-bottom: 10px;">
 <a href="http://www.flickr.com/photos/tsykoduk/38628026/" title="photo sharing"><img src="http://static.flickr.com/29/39360130_7c738c1a95_m.jpg" alt="" style="border: solid 2px #000000;" /></a>
 <br />
 <span style="font-size: 0.9em; margin-top: 0px;">
  <a href="http://www.flickr.com/photos/tsykoduk/38628026/">Built Ford Tough: Rain</a>
  <br />
  Originally uploaded by <a href="http://www.flickr.com/people/tsykoduk/">tsykoduk</a>.
 </span>
</div>
Here is an edited version of my Favorite photo so far from Katrina. My hat's off to all of the brave men and women that risked themselves to help out when they were called.<br />
<br />
<br clear="all" />