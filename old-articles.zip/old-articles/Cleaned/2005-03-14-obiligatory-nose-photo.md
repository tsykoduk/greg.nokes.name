---
id: 149
title: Obiligatory Nose Photo
date: 2005-03-14T19:02:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/obiligatory-nose-photo
permalink: /2005/03/14/obiligatory-nose-photo/
categories:
  - Philosophy! and Politics!
---
<center><img src=http://nokes.name/photos/albums/userpics/10001/normal_img_1136.jpg width="400" height="400"/></center>