---
id: 813
title: Used cars anyone?
date: 2005-08-26T22:48:07+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/used-cars-anyone
permalink: /2005/08/26/used-cars-anyone/
categories:
  - Fun!
---
<p>No?</p>


<p>Then how about a supersonic fighter, only slightly used, for <a href="http://times.hankooki.com/lpage/200508/kt2005081519485168040.htm">$100</a> US?</p>