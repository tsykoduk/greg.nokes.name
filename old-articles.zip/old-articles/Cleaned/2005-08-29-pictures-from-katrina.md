---
id: 821
title: Pictures from Katrina
date: 2005-08-29T15:58:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/pictures-from-katrina
permalink: /2005/08/29/pictures-from-katrina/
categories:
  - Mundane
---
<p>A lot of pictures are starting to come in from Katrina on <a href="http://www.flickr.com/photos/tags/hurricanekatrina">Flickr</a>. Some good stuff in there. Our thoughts are with those that were in the path, and we hope that they have come through safely.</p>


<p><i>Update 10:43 pm <span class="caps">PST</span></i>
More flickr pictures are <a href="http://www.flickr.com/photos/tags/katrina/clusters/">here</a> - over a sixteen hundred at this time. Long live the new media!</p>