---
id: 188
title: Google Gulp!
date: 2005-04-01T09:47:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-gulp
permalink: /2005/04/01/google-gulp/
categories:
  - Fun!
---
<p>Google is announcing a new product... <a href="http://www.google.com/googlegulp/">Google Gulp!</a> Sounds yummy..</p>