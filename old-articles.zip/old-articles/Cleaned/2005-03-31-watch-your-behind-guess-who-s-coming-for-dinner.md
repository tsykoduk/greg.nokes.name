---
id: 124
title: 'Watch your behind.. guess who's coming for dinner..'
date: 2005-03-31T13:10:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/watch-your-behind-guess-who-s-coming-for-dinner
permalink: /2005/03/31/watch-your-behind-guess-who-s-coming-for-dinner/
categories:
  - Fun!
---
<center><img src="http://www.gaijindesign.com/lawriemalen/jedi/jedimaster.jpg" width="285" height="123" border="0" /><br /><a href="http://www.gaijindesign.com/lawriemalen/jedi" target="_blank">:: how jedi are you? ::</a></center><br /><br />Thanks for another waste of time goes to Spokane's <a href=http://emilyscraziness.blogspot.com/2005/03/i-rock.html>Quiz Queen</a>