---
id: 139
title: New screenshot
date: 2005-03-24T15:03:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-screenshot
permalink: /2005/03/24/new-screenshot/
categories:
  - Philosophy! and Politics!
---
<p>Ya know, I just love showing these things off. I am sure that none of you actually care about this but..<br /><br /><center><a href="http://nokes.name/photos/albums/userpics/10001/Screenshot%7E0.png"><img src="http://nokes.name/photos/albums/userpics/10001/normal_Screenshot%7E0.png" width="350" height="300"/></a></center><br /><br /><br />-Tsyko</p>