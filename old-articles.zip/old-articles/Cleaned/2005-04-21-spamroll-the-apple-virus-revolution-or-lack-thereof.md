---
id: 294
title: 'Spamroll: The Apple virus revolution, or lack thereof'
date: 2005-04-21T11:07:15+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spamroll-the-apple-virus-revolution-or-lack-thereof
permalink: /2005/04/21/spamroll-the-apple-virus-revolution-or-lack-thereof/
categories:
  - Computers! and Code!
---
<p>Spamroll has a good <a href="http://www.spamroll.com/blogarch/2005/04/the_apple_virus.php">article,</a> that I am going to repost here for my readers..</p>


	<blockquote>The <a href="http://www.theregister.co.uk/2005/04/21/apples_big_virus/">Register</a> just posted this piece on Apple <span class="caps">OS X</span>, and attempts to find a correlation between the recent proliferation of computer security issues, and Apple's exploding <span class="caps">OS X</span> platform sales.

	<p>I have touted Apple as a solution for the malware that binds us, <a href="http://www.spamroll.com/blogarch/2005/04/spyware_purveyo.php">over</a> and <a href="http://www.spamroll.com/blogarch/2005/03/how_to_really_h.php">over</a> and <a href="http://www.spamroll.com/blogarch/2005/03/spyware_legisla_1.php">over,</a> not because I am a "Mac-head," but because I bought one out of curiousity, and found it just plain works (and without all the nasties I became accustomed to with Windows).</p>


	<p>I have to agree with The Register - there is a correlation.</p>


	<p>If you are fed up, and are ready to make the jump, just click here: <a href="http://click.linksynergy.com/fs-bin/click?id=rWSLPQplAy0&#38;offerid=77305.10000493&#38;type=3&#38;subid=0">Apple Store</a>.</blockquote></p>


	<p>I have posted about this as well. Apples are great machines, and just about any alternate OS is going to be more secure then Windows.</p>