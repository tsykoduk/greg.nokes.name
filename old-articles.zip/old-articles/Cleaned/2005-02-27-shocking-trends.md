---
id: 74
title: Shocking Trends
date: 2005-02-27T15:58:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/shocking-trends
permalink: /2005/02/27/shocking-trends/
categories:
  - Philosophy! and Politics!
---
<p>In my browsing, I stumbled on <a href=http://www.lex18.com/Global/story.asp?S=2989614>Scary Story</a>. Seems this kid in Highschool wrote a short story about a generic highschool being overrun by Zombies.<br /><br />So, he is being charged, and held for $5,000 bail. For writing a short story. For his English class. Wow.<br /><br />So, I started to do some research, and I found <a href="http://zerointelligence.net/">This Site</a>. Some good stuff there about the fear culture that we currently live in...<br /><br />-Tsyko</p>