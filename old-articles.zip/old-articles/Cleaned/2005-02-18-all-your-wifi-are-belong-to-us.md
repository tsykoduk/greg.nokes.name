---
id: 85
title: All your wifi are belong to us!
date: 2005-02-18T15:51:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/all-your-wifi-are-belong-to-us
permalink: /2005/02/18/all-your-wifi-are-belong-to-us/
categories:
  - Computers! and Code!
  - Fun!
---
<p>Woot! The hotel has 'B' wifi access at no charge. I will probably try and keep a running log of the events. So far, a crowd hounding the Gaming Chair to get the sign in sheet for the <span class="caps">WWII</span> game that I run up. Makes a guy just tear up.<br /><br />sniff.</p>