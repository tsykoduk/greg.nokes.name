---
id: 364
title: Let Go the Status Quo
date: 2005-04-29T09:48:02+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/let-go-the-status-quo
permalink: /2005/04/29/let-go-the-status-quo/
categories:
  - Philosophy! and Politics!
---
<blockquote>In defending the Social Security status quo, many liberal commentators take inconsistent position</blockquote>

	<p>Thus starts a good article over at the <a href="http://www.cato.org/pub_display.php?pub_id=3748"> Cato Institute</a> about the need for Personal Accounts in Social Security.</p>


	<p>I agree that people need to be given ownership of their monies. The goverment has proven that it cannot be trusted with that money, so let's allow folks to keep it, build it, and then spend it when they are older.</p>


	<p>Combine this with a <a href="http://www.fairtax.org">Fairtax</a> based on sales rather them income, and we have a win win situation</p>