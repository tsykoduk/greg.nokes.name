---
id: 503
title: Guerilla Minds Eye Theater
date: 2005-06-04T13:25:48+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/guerilla-minds-eye-theater
permalink: /2005/06/04/guerilla-minds-eye-theater/
categories:
  - Philosophy! and Politics!
---
<p>Wabi my Sabi has a link to <a href="http://www.billboardliberation.com/ronald.html">this</a>. It is one of the most brilliant Guerilla Minds Eye Theater events that I have seen in a long time.</p>


<p>As a Discordian, I feel that the event should not have had meaning at all.</p>


<p>I do not agree with the agressive tone that some of these things have, for example I would not have invaded a restaurant. It is enough to teach. Any time a person tries to block anyone else's choices - that is not freedom. People should be allowed to make stupid choices - but should be educated about the those choices.</p>


<p>Really just rambling - did I make any sense?</p>