---
id: 112
title: Have I worked here before?
date: 2005-02-09T16:38:36+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/have-i-worked-here-before
permalink: /2005/02/09/have-i-worked-here-before/
categories:
  - Fun!
  - Mundane
---
Mike Sarakinsky, University of South Africa:

>"I have never ordered red tape, but have been tied up by it here at the university. About 12 years ago, I needed 20 sheets of blank white A4 paper for an article I was typing. The only place to get 20 such sheets was the photocopy room. I duly requested the 20 sheets of blank paper from a photocopy assistant. He said he could not give me the sheets, but if I filled in the requisition form, he could give me 20 copies of a blank sheet of paper. Astonished, I filled in the form. Then he proceeded to actually make 20 copies of a blank sheet on the photocopier. He explained that at the end of the day, his supervisor counted the sheets of paper, read the counter on the copier machine, checked that these corresponded with the requisition forms and compared the information with the previous day's numbers. If there was any discrepancy, the fellow had to pay the difference."

From this <a href=http://education.guardian.co.uk/egweekly/story/0,,1402413,00.html>article</a> posted about <a href=http://improbable.typepad.com/improbable_research_whats/2005/02/guardian_column.html>here</a>.

Sounds like some places that I have worked..