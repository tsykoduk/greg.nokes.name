---
id: 494
title: Danger, Will Robinson!
date: 2005-06-01T11:00:25+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/danger-will-robinson
permalink: /2005/06/01/danger-will-robinson/
categories:
  - Philosophy! and Politics!
---
<blockquote>A conservative news outlet just released a list of the most dangerous books of the last 200 years. While some of the books (Hitler, Keynes, Marx to a lesser extent) might actually deserve the descriptor 'dangerous", some of these are ridiculous picks. Nietzsche? Kinsey? John Stuart Mill? Freud? Darwin?!? These are considered dangerous?</blockquote>

	<p>Read the full article at <a href="http://hereticalideas.com/">Heretical Ideas</a>.</p>