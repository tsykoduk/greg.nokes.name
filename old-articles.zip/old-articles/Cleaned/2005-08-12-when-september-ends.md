---
id: 734
title: When September Ends
date: 2005-08-12T06:02:04+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/when-september-ends
permalink: /2005/08/12/when-september-ends/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://www.greenday.com/">Green day</a> has a new <a href="http://www.warnerreprise.com/qt-ref/greenday_wakemeupwhenseptemberends-video_ref.mov">video</a> posted. Pretty darn good stuff.</p>


	<p>(HT: <a href="http://integralpractice.blogharbor.com/blog/_trackback/113039">ebuddha</a>)</p>