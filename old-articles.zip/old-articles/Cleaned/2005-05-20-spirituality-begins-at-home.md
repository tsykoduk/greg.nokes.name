---
id: 446
title: Spirituality begins at home
date: 2005-05-20T08:30:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spirituality-begins-at-home
permalink: /2005/05/20/spirituality-begins-at-home/
categories:
  - Philosophy! and Politics!
---
<p>The <a href="http://www.buddhistchannel.tv/index.php?id=7,1194,0,0,1,0">Buddhist Channel</a> has a good cross-religion article about creating sacred space in our homes.</p>


<blockquote>Creating sacred space in the everyday world is part of honoring the fact that the spiritual is part of life and that all our life is sacred.</blockquote>

<p>I have felt this for a long time, and usally have items around the house that remind me of sacred. Ones home should be sacred space - there is no safer and more comfy place to relax.</p>