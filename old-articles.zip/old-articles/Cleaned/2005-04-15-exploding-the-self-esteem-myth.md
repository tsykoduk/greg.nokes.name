---
id: 277
title: Exploding the Self-Esteem Myth
date: 2005-04-15T22:55:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/exploding-the-self-esteem-myth
permalink: /2005/04/15/exploding-the-self-esteem-myth/
categories:
  - Philosophy! and Politics!
---
<blockquote>Boosting people's sense of self-worth has become a national preoccupation. Yet surprisingly, research shows that such efforts are of little value in fostering academic progress or preventing undesirable behavior</blockquote>

	<p>From <a href="http://www.sciam.com/article.cfm?chanID=sa006&#38;articleID=000CB565-F330-11BE-AD0683414B7F0000&#38;pageNumber=1&#38;catID=2">Scientific American</a></p>


	<p>The article is a good read. Our socity of pandering to everyone, even if they do not succeed is doing more harm the good. If everyone is given an award, then no one has anything to strive for. Competition is a heathly part of life. Conflict is also healthy. To remove these things from life does not teach anything, rather it removes the ablity to learn. When the children that are never challenged are presented with a real life challenge - what will they do? They will have no experince dealing with losing, or stress.</p>


	<p>We need to equip them with the tools that they need to have. They will not always win in real life. When they fail, they need to already know what that feels like. Also, if they are never challenged to suceed - they will always fail.</p>


	<p>-Tsyko</p>