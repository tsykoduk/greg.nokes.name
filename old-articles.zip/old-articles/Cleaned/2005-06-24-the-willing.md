---
id: 574
title: The Willing
date: 2005-06-24T14:06:43+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-willing
permalink: /2005/06/24/the-willing/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://chrenkoff.blogspot.com/2005/06/willing.html">Chrenkoff</a> has a bunch of pictures of the countries that are lending a hand in Iraq.</p>


	<p>(Hat Tip <a href="http://davejustus.blogspot.com/2005/06/pictures-of-unilateralism.html">Justus</a>)</p>