---
id: 170
title: 'Shelia took the test...'
date: 2005-03-08T18:44:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/shelia-took-the-test
permalink: /2005/03/08/shelia-took-the-test/
categories:
  - Fun!
---
<p><a href="http://dicepool.com/catalog/quiz.php"><br /><br /><img src="http://dicepool.com/catalog/images/splats/friendly.jpg" height="200px" width="400px" alt="I am a d20"/></a><br /><br /><p><a href="http://dicepool.com/catalog/quiz.php">Take the quiz at dicepool.com</a></p></p>