---
id: 825
title: "From  Security Awareness for Ma, Pa and the Corporate Clueless"
date: 2005-08-30T12:31:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/from-security-awareness-for-ma-pa-and-the-corporate-clueless
permalink: /2005/08/30/from-security-awareness-for-ma-pa-and-the-corporate-clueless/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---

<blockquote>Therefore, I had to come up with my own (hopefully rational) reasons as to why WinTel will fail , and has to fail. [1] Worse yet, we have built a society and our national defense upon systems that we know are going to religiously fail for countless reasons; nonetheless I will try.</blockquote>

<p>-Winn's latest <a href="http://www.securityawareness.blogspot.com/">Rant</a></p>

<p>This is a must read, if you are Ma, Pa or in the Industry. What scares me the most is the line "<i>we have built a society and our national defense upon systems that we know are going to religiously fail for countless reasons</i>".</p>

<p>We are building a house of cards on quicksand. Time for a rude awakening!</p>
