---
id: 428
title: New vacation site
date: 2005-05-18T16:36:29+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-vacation-site
permalink: /2005/05/18/new-vacation-site/
categories:
  - Mundane
---
<p>I think that I want to go <a href="http://maps.google.com/maps?ll=37.666926,-116.027856&#38;spn=0.015557,0.016501&#38;z=1&#38;t=k&#38;hl=en">Here</a></p>