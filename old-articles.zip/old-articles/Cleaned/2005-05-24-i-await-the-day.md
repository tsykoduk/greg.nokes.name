---
id: 466
title: I Await the Day
date: 2005-05-24T15:18:59+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-await-the-day
permalink: /2005/05/24/i-await-the-day/
categories:
  - Fun!
---
<blockquote>I Await the Day

	<p>I await the day when the only war you will find is in history books. I will cherish the moment that Muslims can sit down with Jews and share a laugh over coffee. I relish the time when there are no guns because there is no need for guns, when people realize that it is better to live in peace and harmony and help those who need it.</blockquote></p>


	<p>Thus starts a really good <a href="http://sharpmarbles.stufftoread.com/archive/2005/05/24/3206.aspx">article</a> over on SaaM. I implore you to go and read it. You will reach enlightment sooner if you do.</p>