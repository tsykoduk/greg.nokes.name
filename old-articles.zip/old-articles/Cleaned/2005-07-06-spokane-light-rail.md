---
id: 632
title: Spokane Light Rail
date: 2005-07-06T21:10:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spokane-light-rail
permalink: /2005/07/06/spokane-light-rail/
categories:
  - Philosophy! and Politics!
---
<p>Did you ever want to know about the Light Rail Project in Spokane? Well, the <a href="http://spokanelightrail.blogspot.com/">Spokane Light Rail Blog</a> will sure fill you in!</p>