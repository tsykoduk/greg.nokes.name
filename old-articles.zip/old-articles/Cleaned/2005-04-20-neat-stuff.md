---
id: 292
title: Neat stuff
date: 2005-04-20T16:03:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/neat-stuff
permalink: /2005/04/20/neat-stuff/
categories:
  - Science!
---
From <a href="http://science.slashdot.org/science/05/04/20/0040220.shtml?tid=160&#38;tid=14">Slashdot</a>:
	<blockquote>Experiments at the worlds largest nuclear collider, <span class="caps">RHIC</span>, at Brookhaven National Laboratory reveal striking new features of the state of the early Universe. With RHICs enormous collision energy, the researchers can create matter that is composed of the fundamental building blocks of nature, quarks and gluons, in a state with temperatures of more than 1000 billion degrees. The Universe is believed to have been in this state in the first microsecond after the Big Bang. Later the quarks and gluons were trapped in the nuclear particles that the visible universe is composed of today. Until recently, researchers have thought that the quarks and gluons formed a gas. The latest results from <span class="caps">RHIC</span>, however, indicate that under the extreme conditions just around the phase transition from quarks and gluons to ordinary matter, the quarks and gluons behaved as a liquid - in fact an almost perfect liquid.</blockquote>