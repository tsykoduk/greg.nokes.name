---
id: 668
title: Juxtiposition
date: 2005-07-19T21:24:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/juxtiposition
permalink: /2005/07/19/juxtiposition/
categories:
  - Philosophy! and Politics!
  - Science!
---
<p>Would there be a universe with out a consciousness to measure it? In physics we see that the act of observing something changes that something. For example, we can measure a particle for it's speed, or it's location - not both. The more exactly we discern it's location, the less we can tell about it's speed. If we know that Right Now, it's Right Here, we cannot determine it's velocity nor direction of travel.</p>


	<blockquote>Cosmology, is the study of the universe in its totality and by extension man's place in it. Though the word cosmology is itself of fairly modern origin, first penned in Wolff's Cosmologia Generalis (1730), the study of the universe has a long history involving science, philosophy, and religion</blockquote>

	<p>-<a href="http://en.wikipedia.org/wiki/Cosmology">Wikipedia</a></p>


	<p>I think that life is like that. We either know where we are, or where we are going. And, this is not a bad thing. We need to really concentrate on what is important to us now. Where we are.  It's like this - if we get all frazzled and worried about the endgame before we get the ball - how do you think that we will do when we get the ball?</p>


	<p>Not well. We need to keep our eyes and thoughts on what we are doing right now. For example, when one is 'looking' one rarely finds a mate. When one is comfortable in our own skins, and do not need some one to complete us, that is when we are ready to settle down.</p>


	<blockquote>Mindfulness is the practice whereby a person is intentionally aware of his or her thoughts and actions in the present moment, non-judgmentally. Largely associated with Buddhism, in which it is called sati, the practice of mindfulness is also advocated by such people as medical researcher and author Dr. Jon Kabat-Zinn, psychologist Nathaniel Branden and philosopher Ayn Rand. </blockquote>

	<p>-<a href="http://en.wikipedia.org/wiki/Mindfulness">Wikipedia</a></p>


	<p>Moving to a slower beat, watching each step that we make, being mindful, that is what will get us to the endgame.</p>