---
id: 562
title: 'It's all over'
date: 2005-06-21T13:29:56+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-all-over
permalink: /2005/06/21/it-s-all-over/
categories:
  - Fun!
---
<p><a href="http://sharpmarbles.stufftoread.com/archive/2005/06/21/3441.aspx">SaaM</a> brings us this scary and chilling statistic:</p>


	<blockquote>Did you know that the worldwide death rate is 100%? Scary!</blockquote>

	<p>It's over folks. This blog is shutting down, as we are all really dead.</p>