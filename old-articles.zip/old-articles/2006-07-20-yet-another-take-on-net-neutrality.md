---
id: 1437
title: Yet another take on Net Neutrality
date: 2006-07-20T18:53:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/yet-another-take-on-net-neutrality
permalink: /2006/07/20/yet-another-take-on-net-neutrality/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
Yet another take on Net Neutrality...
&lt;!<del>-more</del>-&gt;
<embed src="http://www.veoh.com/flvplayer.swf?autoStart=false&#38;videoId=97206&#38;permalinkId=e97206szs4npk9&#38;file=022837a24ae97e77cf4febf05c0135aaf41c9cde&#38;id=1" width="425" height="340" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer"></embed>