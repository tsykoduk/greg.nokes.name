---
id: 7164
title: Happy Tax Freedom Day
date: 2008-04-23T17:09:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/happy-tax-freedom-day
permalink: /2008/04/23/happy-tax-freedom-day/
categories:
  - Philosophy! and Politics!
---
<p>So - from January 1st till yesterday, you were working for the government. Today on, according to the <a href="http://www.taxfoundation.org/">Tax Foundation's</a> <a href="http://www.taxfoundation.org/publications/show/93.html">report</a>, you get to keep what you make. As a comparison, you had to work 114 days to pay for the Government, and only 108 for Housing, Clothes and Food.</p>


<p>Seem excessive?</p>


<blockquote>If we run into such debts, as that we must be taxed in our meat and in our drink, in our necessaries and our comforts, in our labors and our amusements, for our callings and our creeds, as the people of England are, our people, like them, must come to labor sixteen hours in the twenty-four, give the earnings of fifteen of these to the government for their debts and daily expenses; and the sixteenth being insufficient to afford us bread, we must live, as they now do, on oatmeal and potatoes; have no time to think, no means of calling the mismanagers to account; but be glad to obtain subsistence by hiring ourselves to rivet their chains on the necks of our fellow-sufferers.</blockquote>

<p>-<a href="http://etext.virginia.edu/jefferson/quotations/jeff1340.htm">Thomas Jefferson</a></p>