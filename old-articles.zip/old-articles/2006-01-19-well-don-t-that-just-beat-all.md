---
id: 1234
title: 'Well, don't that just beat all'
date: 2006-01-19T17:34:56+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/well-don-t-that-just-beat-all
permalink: /2006/01/19/well-don-t-that-just-beat-all/
categories:
  - Philosophy! and Politics!
  - Science!
description: "Vatican newspaper declares intelligent design is not science, shouldn't be taught alongside evolution in schools, settling the debate with papal backing."
---
<blockquote><strong>(AP) </strong>The Vatican newspaper has published an article saying "intelligent design" is not science and that teaching it alongside evolutionary theory in school classrooms only creates confusion.

<p>The article in Tuesday's editions of L'Osservatore Romano was the latest in a series of interventions by Vatican officials <strong>including the pope</strong> on the issue that has dominated headlines in the United States.</blockquote>
-<a href="http://www.cbsnews.com/stories/2006/01/18/ap/world/mainD8F7BDS03.shtml"><span class="caps">CBS</span> News</a></p>


<p>I think that this issue is layed to rest.</p>