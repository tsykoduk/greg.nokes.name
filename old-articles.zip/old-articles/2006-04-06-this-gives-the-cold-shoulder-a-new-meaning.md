---
id: 1324
title: This gives the Cold Shoulder a new meaning!
date: 2006-04-06T14:23:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-gives-the-cold-shoulder-a-new-meaning
permalink: /2006/04/06/this-gives-the-cold-shoulder-a-new-meaning/
categories:
  - Fun!
description: "5-hour limit reached ∙ resets 6pm"
---
<blockquote>Even accounting for the incomprehensible bogosity and difficulty of the act-they have to bring in the pole marker because it gets stolen.

<p>As reported in the January 5th, 2003 edition of the <a title="the antarctic sun and other news stories" href="http://everything2.com/index.pl?node=the%20antarctic%20sun%20and%20other%20news%20stories">Antarctic Sun</a>, the <a title="National Science Foundation" href="http://everything2.com/index.pl?node=National%20Science%20Foundation">National Science Foundation</a>'s newspaper written and published on the <a title="Antarctica" href="http://everything2.com/index.pl?node=Antarctica">seventh continent</a>:</p>


<p><em>Larry Hothem, project leader for <a title="geodetic science" href="http://everything2.com/index.pl?node=geodetic%20science">geodetic science</a> for the <a title="United States Antarctic Program" href="http://everything2.com/index.pl?node=United%20States%20Antarctic%20Program">United States Antarctic Program</a> at the <a title="South Pole Station" href="http://everything2.com/index.pl?node=South%20Pole%20Station">South Pole Station</a> said: "There's been a couple <a title="stolen" href="http://everything2.com/index.pl?node=stolen">stolen</a>. I know the 1994 marker is missing." </em></p>


<p>The pole marker is a stainless steel rod about 10' long with a large brass head four to six inches in diameter, machined by craftsmen each year to commemorate another year of human habitation. Each year a new one is made and placed in the spot that is exactly geographically 90 degrees south, where all the longitude lines merge. The old ones, barring theft, are left in place. There would be a long line of them. Each is unique, having been designed by the winter-over team from the prior year. (There are about 200 inhabitants of south pole station in the summer, and only 50 support staff and scientist "winter overs" to keep things going during the dark season.)</blockquote>
Heh. <a href="http://everything2.com/index.pl?node_id=1411653">Steal the South Pole</a>? Sounds like a mission for...</p>


<p>Never mind. To much hard work. And, it's cold there. Really cold</p>