---
id: 1120
title: Your computer, My Music!
date: 2005-11-15T10:15:07+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/your-computer-my-music
permalink: /2005/11/15/your-computer-my-music/
categories:
  - Computers! and Code!
description: "Sony's controversial rootkit DRM scandal exposed: how music CDs secretly installed malicious software on computers, compromising security with Microsoft's knowledge."
---
<p>For the three people on the moon who have not heard about <a href="http://www.sonybmg.com/">Sony</a>'s <a href="http://en.wikipedia.org/wiki/Rootkit">RootKit</a> <a href="http://en.wikipedia.org/wiki/Digital_rights_management"><span class="caps">DRM</span></a> program, here is the scoop.</p>


<p>Sony/BMG has put some software on their music CD's which modify how Windows (and attempt to modify how Mac <span class="caps">OSX</span>) works at the <a href="http://en.wikipedia.org/wiki/Kernel_%28computer_science%29">kernel</a> or core level. This is a '<a href="http://en.wikipedia.org/wiki/Bad_thing">Bad Thingâ„¢</a>'.</p>


<p>A rootkit is a program that takes over your computer, hides it's self and does what ever it wants to. In this case, it stops you from copying the music off of the CD. The problem is that it basically makes it's self 'root' or supreme commander of your computer. All rights to do anything that it wants.</p>


<p>Shame on you Sony.</p>


<blockquote>Microsoft, Symatec, McAffee and some others were aware of the Sony rootkit months ago. They either turned a blind eye or actively helped Sony 'hideâ€ their little present deep into your Windows system</blockquote>
-<a href="http://lobby4linux.com/WordPress/?p=58">helios</a>

<p>Hey, That's Great. So the people that some of us trust to write our OS's and the security software to protect that OS are implicated in creating a custom rootkit for a third party. That's like Ford helping out car theives.</p>


<p>I certainly hope that people everywhere take notice of this. Your computer running Windows is not yours - according to Microsoft, Sony and the other fat cats. You should have no control over it, they say. I say - <a href="http://www.transbuddha.com/mediaHolder.php?id=174">switch</a>. <a href="http://www.apple.com/switch/">Switch</a> quick.</p>


<p>(Cross posted on the <a href="http://geek.nokes.name">Geeks Grotto</a>)</p>