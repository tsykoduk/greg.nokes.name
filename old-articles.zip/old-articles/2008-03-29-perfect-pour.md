---
id: 7127
title: Perfect Pour
date: 2008-03-29T01:00:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/perfect-pour
permalink: /2008/03/29/perfect-pour/
categories:
  - Mundane
---
<p><img src="https://greg.nokes.name/assets/2008/3/28/guinnessbottle1.jpg" style="float:left;">One of the things that I have started to enjoy over the past year or so, is a pint of Guinness every once in a while. I just got set straight on how to pour a perfect pint, and thought that I would share the lesson...</p>

<!--more-->

<center><object width="425" height="355"><param name="movie" value="http://www.youtube.com/v/d15lJn1r0Mk"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/d15lJn1r0Mk" type="application/x-shockwave-flash" wmode="transparent" width="425" height="355"></embed></object></center>

<p>(HT: <a href="http://blog.guykawasaki.com/2008/03/the-art-of-the.html">Guy Kawasaki</a>)</p>