---
id: 891
title: 'It's Justus's BirthDay'
date: 2005-09-23T09:53:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-justus-s-birthday
permalink: /2005/09/23/it-s-justus-s-birthday/
categories:
  - Mundane
description: "Celebrating another year with humor and reverse aging methodology - join the birthday fun and discover why turning 25 (again) is the perfect age to stay forever young."
---
<blockquote> Happy Birthday to Me!

<p>Today is my birthday, which gives all of my readers a wonderful chance to link to me and say nice things about me!</p>


<p>You all are so lucky to have this opportunity!</p>


<p>In keeping with my reverse aging methodology, today I am 25.</p>


<p>Yesterday was Gib's birthday, so you probably should say nice things about him to. Less nice than about me of course.</blockquote></p>


<p><a href="http://davejustus.blogspot.com/">He</a> is confused, but a nice guy. :)</p>