---
id: 847
title: 'And Lo, the FSM found it good, and unto us he said 'Arrrrggh''
date: 2005-09-06T20:24:01+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/and-lo-the-fsm-found-it-good-and-unto-us-he-said-arrrrggh
permalink: /2005/09/06/and-lo-the-fsm-found-it-good-and-unto-us-he-said-arrrrggh/
categories:
  - Fun!
  - Philosophy! and Politics!
  - Science!
description: "Discover the Flying Spaghetti Monster (FSM) and learn how to spread FSMism to the masses with this humorous take on alternative religious movements."
---
<p><a href="http://www.gophergas.com/funstuff/flyingspaghettimonster.htm">You</a> too can now convert masses to FSMism.</p>


<p>(HT: <a href="http://drogidy.blogspot.com/2005/09/fsm-fun-religion.html">Drogidy Blogidy</a>)</p>


<p><em>Update - Links now fixed! Do'h!</em></p>