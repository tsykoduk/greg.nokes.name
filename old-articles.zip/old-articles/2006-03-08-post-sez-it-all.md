---
id: 1270
title: Post sez it all
date: 2006-03-08T14:32:51+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/post-sez-it-all
permalink: /2006/03/08/post-sez-it-all/
categories:
  - Fun!
description: "Looking at this content, I can see it's a very brief post with just a centered image link to fireflyseason2.com and an image about Firefly. Based on the minimal content available, here's an SEO-optimized meta description:"
---
<center><a href="http://www.fireflyseason2.com/"><img src="http://www.nwgamers.org/Firefly2A.jpg" /></a></center>