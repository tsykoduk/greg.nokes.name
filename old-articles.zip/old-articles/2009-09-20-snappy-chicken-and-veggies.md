---
id: 15148
title: Snappy Chicken and Veggies
date: 2009-09-20T20:06:18+00:00
author: tsykoduk
layout: post
guid: https://greg.nokes.name/?p=15148
permalink: /2009/09/20/snappy-chicken-and-veggies/
categories:
  - Mundane
tags:
  - chicken
  - rice
  - stir fry
---
One of the things that I really like to do is to cook. I'm going to start to post new recipes as I come up with them. So this should be the first of many articles in this category.

<!--more-->
<div class="mceTemp"><dl id="attachment_15149" class="wp-caption alignleft" style="width: 310px;"> <dt class="wp-caption-dt" style="text-align: auto;"> </dt> <dd class="wp-caption-dd">Snappy Chicken and Veggies</dd><img class="size-medium wp-image-15149" title="photo" src="https://greg.nokes.name/binaries/2009/09/photo-300x225.jpg" alt="Snappy Chicken and Veggies" width="300" height="225" />

</dl></div>
<strong>Snappy Chicken</strong>
<table border="0">
<tbody>
<tr>
<td>2</td>
<td style="padding:2px;"></td>
<td>pounds Chicken</td>
</tr>
<tr>
<td>2</td>
<td style="padding:2px;"></td>
<td>cups Veggies (broccoli, cauliflower, carrots)</td>
</tr>
<tr>
<td>2</td>
<td style="padding:2px;"></td>
<td>cups uncooked Rice</td>
</tr>
<tr>
<td>1</td>
<td style="padding:2px;"></td>
<td>tbsp. Chinese 5 spice</td>
</tr>
<tr>
<td>1</td>
<td style="padding:2px;"></td>
<td>tsp. Garlic</td>
</tr>
<tr>
<td>2</td>
<td style="padding:2px;"></td>
<td>tsp. Cayenne</td>
</tr>
<tr>
<td>1/4</td>
<td style="padding:2px;"></td>
<td>cup Soy Sauce</td>
</tr>
<tr>
<td>1/2</td>
<td style="padding:2px;"></td>
<td>cup Olive Oil</td>
</tr>
</tbody></table>
Prepare the rice according to it's directions.

Cut the chicken into medallions about 1/4 to 1/3rd inch thick.

In a large wok, heat the oil. While the oil is heating, mix the spices and Soy Sauce and set aside.

Drop the chicken into the heated oil (being careful that the hot oil does not splash or spit on you). Stir fry until the chicken is white all over, and there is a touch of pink in the middle. Drop the veggies in, splash the spices on the top, cover and lower to a simmer. Let simmer until the veggies are hot, but still crisp. (yes, that is a good time to eat some and make sure they are still yummy).

Spoon the chicken and broth onto the rice, and enjoy.