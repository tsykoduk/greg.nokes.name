---
id: 1171
title: Reading Liturgy as Literature
date: 2005-12-12T20:27:06+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/reading-liturgy-as-literature
permalink: /2005/12/12/reading-liturgy-as-literature/
categories:
  - Philosophy! and Politics!
description: "Explore how religious liturgy can be appreciated as powerful literature beyond its spiritual context. Discover the artistic and literary value hidden in sacred texts and rituals."
---
<p><a href="http://www.npr.org/templates/story/story.php?storyId=5048309">This</a> story was pretty though provoking for me. It's an <span class="caps">NPR</span> story, and it's audio - but give it a listen.</p>