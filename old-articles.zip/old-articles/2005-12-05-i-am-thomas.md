---
id: 1143
title: I am Thomas!
date: 2005-12-05T10:32:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-am-thomas
permalink: /2005/12/05/i-am-thomas/
categories:
  - Philosophy! and Politics!
description: "Personal reflections on Buddhism's realistic approach to life, the importance of healthy doubt over blind faith, and why questioning beliefs leads to stronger minds and spiritual growth."
---
<p>Ok, so the whole weekly thing is on hold for the holidays. Discipline is not one of my strong suites. :) Expect a missive on the importance of discipline in the next few weeks.</p>


<p>Anyways...</p>


<blockquote>Those old religious manuals were written for a time before stock markets and viral epidemics and robotics and biomedicine and capitalism and the internet, and even if they'd known about these things, their underlying message would have still been the same.. chill, love each other, do your work... They are preparation, no more.

<p>The good ones don't tempt humans to contemplate God, but to perfect themselves on Earth. Being "at one with God" or "a part of the creator" is your birthright, sure, but you were born on planet Earth.</blockquote></p>


<p>-<a href="http://corz.org/blog/index.php#%0A%09%09one%20word%2C%20maybe%20two..%0A">Corzblog</a></p>


<p>I like the article - read it all.</p>


<p>One of the things that I like about Buddhism, is it's realistic approach to life. It does not expect blind faith. It expects us to try, learn, and come to our own conclusions. I have talked at length about this before, but I saw a sign that really drove the point home for me.</p>


<blockquote>Feeding your faith,
starves your doubt
</blockquote>

<p>I would posit that a liberal dose of doubt is healthy. When the church leader asks me to drink the KoolAid, I should be able to think on my own and and say 'No'. Reliance on faith leads to weak minds. Doubting, discussing, and dissension leads to strong minds.</p>


<p>I once called faith a crutch. I do believe that it can be. It is very unhealthy when used to the extreme. Just because some one wrote it in a book does not make it true! You need to examine those words and beliefs, process them, and make sure that they have constancy and truth.</p>


<p>Blind faith leads us to the Jonestowns and Wacos.</p>


<p>We need to teach critical though, self examination and healthy doubt. We will not survive with out it.</p>