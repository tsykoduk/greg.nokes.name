---
id: 1124
title: 'Here we go again...'
date: 2005-11-22T08:46:01+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/here-we-go-again
permalink: /2005/11/22/here-we-go-again/
categories:
  - Computers! and Code!
description: "Zero-day Internet Explorer exploit puts millions at risk of computer hijacking attacks. Learn about the critical security flaw and safer browsing alternatives."
---
<blockquote>Exploit code for a critical flaw in fully patched versions of Microsoft Corp.'s Internet Explorer browser has been released on the Internet, putting millions of Web surfers at risk of computer hijack attacks.

<p>The zero-day exploit, posted by a U.K.-based group called "Computer Terrorism," could allow a remote hacker to take complete control of a Windows system if the victim simply browses to a malicious Web site.</p>


<p>Ziff Davis Internet News have verified that the exploit works on fully patched Windows XP systems with default IE installations...</p>


<p>...The group that published the exploit said Microsoft has been aware of the Javascript Window() vulnerability for several months but was mistakenly treating it as a low-priority denial-of-service flaw.</p>


<p>Benjamin Tobias Franz, a German security researcher, originally published an advisory in May this year to warn of the denial-of-service bug.</blockquote></p>


<p>-<a href="http://www.eweek.com/article2/0,1759,1891749,00.asp?kc=EWRSS03119TX1K0000594">EWeek</a></p>


<p>You know the mantra.</p>


<p>Switch to another <a href="http://www.browsehappy.com">browser</a>. Practice safe computing. Keep the scanners and firewalls on high alert. Or, switch to <a href="http://www.ubuntulinux.org">Linux</a> or <a href="http://www.apple.com">Mac.</a></p>