---
id: 1126
title: Things that make you go Hmmm
date: 2005-11-29T20:24:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/things-that-make-you-go-hmmm
permalink: /2005/11/29/things-that-make-you-go-hmmm/
categories:
  - Philosophy! and Politics!
  - Science!
description: "Exploring alternative energy solutions and market forces in our transition away from oil dependency. Critical insights on timing and economic impact of energy policy decisions."
---
<p>I don't know the veracity of the claims that these folks make, however, they raise some really good points.</p>


<p>...Switching to alternative energy now is a win win situation.</p>


<p>...Market forces will not be able to fix the problem with out great pain.</p>


<p>...The longer we wait, the worse it'g going to be.</p>


<p>Check out their little <a href="http://www.powerswitch.org.uk/portal/images/stories/animoil.swf">ditty</a>.</p>