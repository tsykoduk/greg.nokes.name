---
id: 2947
title: New version of spam filtering
date: 2007-10-10T19:51:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-version-of-spam-filtering
permalink: /2007/10/10/new-version-of-spam-filtering/
categories:
  - Computers! and Code!
  - Fun!
---
<p>I actually think that this <a href="http://stupidfilter.org">project</a> is going to have some really good uses. I will have to look at porting it to Ruby and Mephisto when they release code.</p>