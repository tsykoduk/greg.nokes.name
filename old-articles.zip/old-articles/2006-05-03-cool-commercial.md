---
id: 1368
title: Cool Commercial
date: 2006-05-03T07:42:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cool-commercial
permalink: /2006/05/03/cool-commercial/
categories:
  - Fun!
description: "5-hour limit reached ∙ resets 6pm"
---
<p>Yeah - Water has never been so <a href="http://www.epica-awards.org/assets/epica/2004/winners/film/flv/06037.htm">Cool</a>!</p>