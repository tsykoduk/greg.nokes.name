---
id: 1322
title: Who brought the marshmellows?
date: 2006-03-31T10:07:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/who-brought-the-marshmellows
permalink: /2006/03/31/who-brought-the-marshmellows/
categories:
  - Fun!
description: "5-hour limit reached ∙ resets 6pm"
---
<div style="text-align: center"><a title="Photo Sharing" href="http://www.flickr.com/photos/tsykoduk/121549615/"><img width="234" height="183" alt="centralia3" src="http://static.flickr.com/39/121549615_aeea77f91a_o.jpg" /></a></div>
<blockquote><a href="http://www.damninteresting.com/?p=479">Centralia, Pennsylvania</a> was never a particularly large community, but it was once a lively and industrial place. At its peak the coal mining town was home to 2,761 souls, but today the population of its cemeteries far outnumbers that of its living residents. The series of events which led to the community's demise, slowly diminishing its numbers to less than a dozen, began about forty-four years ago.

<p>In 1962, workers set a heap of trash ablaze in an abandoned mine pit which was used as the borough's landfill. The burning of excess trash was a common practice, yet at that particular time and place there existed a dangerous condition: an exposed vein of anthracite coal. The highly flammable mineral was unexpectedly ignited by the trash fire, prompting a quick effort to put it out. The flames on the surface were successfully extinguished, but unbeknownst to the fire fighters, the coal continued to burn underground.</blockquote></p>