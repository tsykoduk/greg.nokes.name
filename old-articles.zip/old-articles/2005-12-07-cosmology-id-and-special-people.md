---
id: 1150
title: Cosmology, ID and Special People
date: 2005-12-07T08:45:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cosmology-id-and-special-people
permalink: /2005/12/07/cosmology-id-and-special-people/
categories:
  - Philosophy! and Politics!
  - Science!
description: "Exploring why humans aren't cosmologically special: we evolved to fit universal constants, not the reverse. A critique of Intelligent Design's anthropocentric assumptions."
---
<p>One of my problems with ID and it's attendant philosophies is that it assumes that we are special somehow. What folks fail to realize is that there are billions of earth like planets out there - and possibly billions of universes. We think that the universe was specially created for us because the cosmological constants are pretty much tailored for us. However, that's simply not the case.</p>


<p>The constants are 'tailored' for us simply because we evolved under their rules. So we are in fact tailored to the environment that we evolved in, not the other way around.</p>


<p>I think that some folks are bent on Humanity being 'special' somehow. Here is a news flash: We are not special. We are not the center of the universe. The universe was not designed for us, rather we were designed by the universe. If some of the constants had been different, we would have evolved differently - or not at all. To claim humanities specialness because the universe is so suited for us is to have it backwards. We are suited for the universe.</p>