---
id: 843
title: Stuff on Cats
date: 2005-09-05T08:11:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/stuff-on-cats
permalink: /2005/09/05/stuff-on-cats/
categories:
  - Fun!
description: "Discover amusing photos of cats with random objects placed on them at Stuff on Cats - a humorous collection of feline photography that will make you smile."
---
<p><a href="http://www.stuffonmycat.com/">Stuff on cats</a> - the title really says it all.</p>