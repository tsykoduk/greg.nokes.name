---
id: 1364
title: 'My future's so bright, I gotta wear shades...'
date: 2006-05-01T09:15:35+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/my-future-s-so-bright-i-gotta-wear-shades
permalink: /2006/05/01/my-future-s-so-bright-i-gotta-wear-shades/
categories:
  - Philosophy! and Politics!
  - Science!
description: "5-hour limit reached ∙ resets 6pm"
---
<center><a href="http://solarsystem.nasa.gov/multimedia/gallery/PIA03149.jpg"><img src="https://greg.nokes.name/PIA03149_thumb.jpg" /></a></center>Just saw this rather bright image... Click through for the <em>large</em> full size image. Rather impressive!