---
id: 1448
title: Massive Changes
date: 2006-09-12T18:41:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/massive-changes
permalink: /2006/09/12/massive-changes/
categories:
  - Computers! and Code!
---
<p>So, in my quest to find the perfect combination of blogging software and learning a new language, I have decided to migrate this site - again - to yet another platform.</p>

<p>This migration was not as clean as the last few - no fault of the software that I was or am running. It was totally my mess up, and I freely admit that.</p>

<p>Anyways, poke around and see what you think.</p>