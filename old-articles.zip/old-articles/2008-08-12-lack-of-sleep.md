---
id: 7269
title: Lack of Sleep
date: 2008-08-12T08:36:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/lack-of-sleep
permalink: /2008/08/12/lack-of-sleep/
categories:
  - Mundane
---
<img id="thumber" class="alignleft" src="https://greg.nokes.name/assets/2008/8/12/Screenshot-1.jpg" alt="Nose" width="80" height="80" />General lack of sleep equates to this blog moving in the near future. I don't know if I am going to care and keep the old posts and comments yet. That is in the "to be determined' category.

What has been determined is that this place needs a major revamp. So, a revamping I go, a revamping I go...

Yeah...

Lack of sleep.

Chalk it up to that, not the things hiding in the curves of the corners.