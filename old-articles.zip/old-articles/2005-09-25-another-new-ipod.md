---
id: 906
title: Another new iPod?!?!
date: 2005-09-25T20:16:01+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/another-new-ipod
permalink: /2005/09/25/another-new-ipod/
categories:
  - Fun!
description: "Discover Apple's latest iPod innovation that's generating buzz - explore the new features and capabilities that might just convince you to upgrade your music experience."
---
<p><a href="http://www.ifilm.com/ifilmdetail/2680559?htv=12&amp;htv=12">Check</a> it out. I just might have to get one!</p>