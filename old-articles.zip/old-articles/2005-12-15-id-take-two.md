---
id: 1177
title: 'ID - take two'
date: 2005-12-15T13:07:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/id-take-two
permalink: /2005/12/15/id-take-two/
categories:
  - Fun!
description: "NPR presents compelling arguments for and against Intelligent Design theory. Listen to this insightful real audio snippet exploring both sides of the ID debate."
---
<p><a href="http://www.npr.org/templates/story/story.php?storyId=5024450">This</a> real audio snippet from <span class="caps">NPR</span> is a really good look at ID. You should listen to it. They present some powerful arguments for and against ID.</p>


<p>Good stuff.</p>