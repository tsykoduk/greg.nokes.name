---
id: 2968
title: Surreal is as Surreal does
date: 2007-11-10T18:03:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/surreal-is-as-surreal-does
permalink: /2007/11/10/surreal-is-as-surreal-does/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><img src="https://greg.nokes.name/assets/2007/11/10/ch071110.gif" width="620px" /></p>