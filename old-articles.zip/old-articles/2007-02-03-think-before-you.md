---
id: 2137
title: 'Think before you...'
date: 2007-02-03T21:42:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/think-before-you
permalink: /2007/02/03/think-before-you/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/yi3erdgVVTw"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/yi3erdgVVTw" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>