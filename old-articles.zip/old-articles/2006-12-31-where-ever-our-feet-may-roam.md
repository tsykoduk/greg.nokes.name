---
id: 1945
title: Where ever our feet may roam
date: 2006-12-31T02:21:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/where-ever-our-feet-may-roam
permalink: /2006/12/31/where-ever-our-feet-may-roam/
categories:
  - Mundane
---
<p>So... in between heaps of code, I was reminiscing about the old days when I was a <span class="caps">BBS</span> geek. The most memorable <span class="caps">BBS</span> that I was on was called Club Fresno. It had about 30 phone lines, and was a true trend setter for it's day - a multi-line <span class="caps">BBS</span>. <a href="http://www.google.com/search?q=%22Club%20Fresno%22%20bbs&#38;sourceid=mozilla2&#38;ie=utf-8&#38;oe=utf-8">Google to the rescue</a>. Heh. I only found two mentions of good ol' club Fres out there - one blog post by an <a href="http://debicollinsworth.blogspot.com/2005/07/ode-to-sister.html">ex-member</a> and a <a href="http://profile.myspace.com/index.cfm?fuseaction=user.viewprofile&#38;friendid=118109418">My Space</a> profile.</p>


<p>So, here's a third result about Club Fresno, the Multi Line <span class="caps">BBS</span>.</p>


<p>:)</p>