---
id: 1113
title: Mad Drawing Skilz
date: 2005-11-11T18:06:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mad-drawing-skilz
permalink: /2005/11/11/mad-drawing-skilz/
categories:
  - Fun!
  - Philosophy! and Politics!
description: "Watch an artistic time-lapse video of a woman being drawn from the inside out in this mesmerizing digital art demonstration showcasing incredible drawing skills."
---
<p>Yeah - check <a href="http://fcmx.net/vec/v.php?i=003702">this</a> out as you watch a woman being drawn from the inside out. Pretty trippy.</p>


<p>Not really work safe.</p>