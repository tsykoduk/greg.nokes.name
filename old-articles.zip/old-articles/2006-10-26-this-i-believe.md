---
id: 1532
title: 'This I believe....'
date: 2006-10-26T09:53:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-i-believe
permalink: /2006/10/26/this-i-believe/
categories:
  - Philosophy! and Politics!
---
<blockquote> I believe that there is no God. I'm beyond atheism. Atheism is not believing in God. Not believing in God is easy-you can't prove a negative, so there's no work to do...</blockquote>

<p>-Penn Jillette on <a href="http://www.npr.org/templates/story/story.php?storyId=5015557">This I Believe</a></p>


<p>I believe that there is an elephant in Penn's trunk.</p>


<p>I heard this spot when it was on, and I must say that I was moved. It concisely sums up a lot of the problems that I have with the entire concept of there being an 'omni-whatever' being. This is a topic that I have done a lot of writing about, and a lot of thinking about, and Penn can sum up my years of pondering in a few short paragraphs.</p>


<p>When I first stumbled across the Buddhist teaching about God, I felt like I had come home. It felt right, and correct, and that it was summing up what I had been trying to verbalize all of these years. To sum it up - If God exists, and is all powerful, then he is evil to allow all of the suffering that has occurred at the hand of Man and Nature over the years. Evil to have turned a blind eye to what his creation has wrought.</p>


<p>The idea that we need to ask forgiveness for our 'sins' from some higher power always struck me as wrong. What about the Hitlers of the world? What if they, after inflicting suffering upon their fellow man, saw the error of their ways, and recanted just before they died? Would they get treated the same as a Dali Lama or a Mother Theresa? According to the majority of the modern Christian movement - yes. Once you are 'washed in the blood of Christ' all your sins are forgiven. All.</p>


<p>I believe that we are each totally responsible for our actions, and that we cannot seek forgiveness because there is no one to give it, others then the folks we have wronged. I believe that everyone else in the world believing this would make the world a better place.</p>


<p>In my belief, there is no place for people who commit atrocious acts in the name of some religion, expecting to be forgiven. There is no forgiveness, Only consequences.</p>