---
id: 1434
title: Can I have one?
date: 2006-07-19T20:31:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/can-i-have-one
permalink: /2006/07/19/can-i-have-one/
categories:
  - Science!
---
<blockquote>Martin Eberhard holds the brake down with his left foot and presses on the accelerator with his right. The motor revs, the car strains against the brake. I hear ... almost nothing. Just a quiet whine like the sound of a jet preparing for takeoff 5 miles away. We're belted into a shimmering black sports car on a quiet, tree-lined street in San Carlos, California, 23 miles south of San Francisco. It has taken Eberhard three years to get this prototype ready for mass production, but with the backing of PayPal cofounder Elon Musk, Google's Larry Page and Sergey Brin, and ex-eBay chief Jeff Skoll, he has created Silicon Valley's first real auto company.</blockquote>

<p>-<a href="http://www.wired.com/news/wiredmag/0,71414-0.html">Wired</a></p>


<p>It's a interesting <a href="http://en.wikipedia.org/wiki/Mashup_(web_application_hybrid)">mash-up</a> of IT smarts and Detroit muscle. These sort of synergistic effects are what are really needed. People sometimes get blinders and only see the ground in front of their feet. We need to look beyond our self induced horizons to see the real world...</p>