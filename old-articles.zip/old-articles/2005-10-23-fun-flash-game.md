---
id: 982
title: Fun Flash Game
date: 2005-10-23T09:46:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/fun-flash-game
permalink: /2005/10/23/fun-flash-game/
categories:
  - Computers! and Code!
  - Fun!
description: "Discover a unique Flash game combining Tetris gameplay with Teletubbies-style visuals for maximum evil fun. A quirky gaming experience you won't forget."
---
<p>Sorta like a combination of tetris and teletubbies. Maximum Evil!</p>


<p>Update - Linkage might help :)</p>


<p>Update 2 - Ok.. I am a total space cadet. I cannot find the fscking thing again. So, you will just have to live knowing that it was one of the cooler things that I have ever seen.</p>


<p>sorry.</p>