---
id: 988
title: Waaaay to much time
date: 2005-10-27T09:53:07+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/waaaay-to-much-time
permalink: /2005/10/27/waaaay-to-much-time/
categories:
  - Computers! and Code!
description: "Learn how to build an incredible R2D2 computer case mod with detailed step-by-step instructions. Creative PC modding project for Star Wars fans with too much time."
---
<p>Ok.. this is cool, and an example of what happens if you have waaay to much time on your hands:</p>


<center><a href="http://www.extremetech.com/slideshow/0,1206,pg=0&#38;s=200&#38;a=163159,00.asp"><img src="http://common.ziffdavisinternet.com/util_get_image/10/0,1425,sz=1&#38;i=109934,00.jpg" width="400" /></a></center>

<p>Yes, that's an <span class="caps">R2D2</span> computer case. Click through to see how it was built.</p>