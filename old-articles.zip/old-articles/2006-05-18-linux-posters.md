---
id: 1394
title: Linux Posters
date: 2006-05-18T08:10:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/linux-posters
permalink: /2006/05/18/linux-posters/
categories:
  - Computers! and Code!
  - Fun!
  - Philosophy! and Politics!
description: "5-hour limit reached ∙ resets 6pm"
---
<div style="float: right; margin-left: 10px; margin-bottom: 10px;">
 <a href="http://www.flickr.com/photos/glagla/54320217/" title="photo sharing"><img src="http://static.flickr.com/31/54320217_f4184f01dc_m.jpg" alt="" style="border: solid 2px #000000;" /></a>

</div>
This kind person has posted a bunch of inspirational Linux posters for hanging about the office. You should go and check them out. There certainly are a few that really - um - stand out.
<br clear="all" />