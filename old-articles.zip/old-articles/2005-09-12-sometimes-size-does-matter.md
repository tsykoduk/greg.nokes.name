---
id: 867
title: Sometimes, size does matter!
date: 2005-09-12T22:14:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/sometimes-size-does-matter
permalink: /2005/09/12/sometimes-size-does-matter/
categories:
  - Fun!
description: "Based on the extremely limited content of this 2005 blog post (which appears to be just a short humorous reference with a link), here's an SEO meta description:"
---
<p><a href="http://www.bigad.com.au/movie.html">Really!</a></p>


<p>It is very big, however.</p>