---
id: 968
title: 'Star Wars: Photoshopping Project'
date: 2005-10-12T08:59:47+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/star-wars-photoshopping-project
permalink: /2005/10/12/star-wars-photoshopping-project/
categories:
  - Fun!
description: "Learn how to create Star Wars-themed Photoshop manipulations and digital art projects. Step-by-step tutorial for sci-fi photo editing techniques and creative design."
---
<center><a href="http://www.bloggerheads.com/star%5Fwars/"><img src="http://www.bloggerheads.com/star%5Fwars/images/star_wars_dusk_dawn.jpg"/></a>
<em>"Seth, I'm <u>telling</u> you, I <u>saw</u> her signalling the stormtroopers!"</em></center>