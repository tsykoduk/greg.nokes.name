---
id: 1192
title: 'It's getting bad out there'
date: 2006-01-03T18:42:27+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-getting-bad-out-there
permalink: /2006/01/03/it-s-getting-bad-out-there/
categories:
  - Computers! and Code!
description: "Critical Windows zero-day exploit threatens users with no official patch until next week. Get step-by-step instructions to protect your system now."
---
<p>Check this out; There is a nasty nasty windows problem in the wild (a '<a href="http://en.wikipedia.org/wiki/Zero-day_exploit">Zero Day Exploit</a>'). This one is bad. Microsoft is not doing anything about it until next week. - So, check out my <a href="http://geek.nokes.name">Tech Blog</a> for a detailed how to on <a href="http://geek.nokes.name/archives/200">fixing this</a>.</p>


<p>This is totally serious, and could become a major problem.</p>


<p><em><span class="caps">UPDATE</span> (1/5/05) Microsoft just released the patch. Go to windows update to get it!</em></p>