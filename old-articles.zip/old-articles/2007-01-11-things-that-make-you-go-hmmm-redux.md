---
id: 2090
title: Things that make you go Hmmm redux
date: 2007-01-11T02:05:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/things-that-make-you-go-hmmm-redux
permalink: /2007/01/11/things-that-make-you-go-hmmm-redux/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
<p>First, go <a href="http://lessig.org/freeculture/free.html">here</a>. After you watch that, let's talk about it.</p>


<p>Do you think that anything needs to be done, or are we good with the status quo?</p>


<p>Will Vista's unbridled, stifling <span class="caps">DRM</span>'y'ness effect you in any way? Is our culture doomed to stagnation and death?</p>


<p>So, what have you done?</p>