---
id: 942
title: 'Stupid Laws, Phishing's for Kids!'
date: 2005-10-06T14:40:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/stupid-laws-phishing-s-for-kids
permalink: /2005/10/06/stupid-laws-phishing-s-for-kids/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
description: "Explore why new laws against cell phone use while driving and phishing are redundant when existing distracted driving and theft laws already cover these crimes."
---
<p>One of my beefs with the US's whole system is the stupid laws that get enacted by well meaning folks. One of my favorite is the 'no talking on cell phones while driving' law. We don't need another law about that! There is already one on the books. It's illegal to drive while you are distracted. So, if you are chattering on your cell phone, and swerving all over the place - that pretty much looks like distracted driving, right?</p>


<p>Well, California has done it again. It's now illegal to '<a href="http://en.wikipedia.org/wiki/Phishing">Phish</a>'.  Phishing is the art of stealing folk's bank account access numbers and passwords, and then robbing them blind. So, stealing was not already illegal in California? Or is this just another stupid law about something that is already covered?</p>