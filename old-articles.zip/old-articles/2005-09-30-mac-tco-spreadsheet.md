---
id: 915
title: Mac TCO Spreadsheet
date: 2005-09-30T08:08:31+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mac-tco-spreadsheet
permalink: /2005/09/30/mac-tco-spreadsheet/
categories:
  - Computers! and Code!
description: "Mac vs Windows total cost of ownership analysis with detailed TCO comparison spreadsheet, security considerations, and real-world cost breakdowns for business decisions."
---
<p>Winn has posted a very good look at the <span class="caps">TCO</span> of Mac vs. Wintendo. The <a href="http://securityawareness.blogspot.com/2005/09/mad-as-hell-finale-recommendations-and.html">article</a> is well worth reading, and the following comments are also worth slogging through.</p>