---
id: 1365
title: 'Apple's got some new ads out'
date: 2006-05-02T08:56:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/apple-s-got-some-new-ads-out
permalink: /2006/05/02/apple-s-got-some-new-ads-out/
categories:
  - Computers! and Code!
description: "5-hour limit reached ∙ resets 6pm"
---
<p>And, ho boy, they are <a href="http://www.apple.com/getamac/ads/">doozies</a>. My favorite was 'viruses', what was yours?</p>