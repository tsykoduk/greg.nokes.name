---
id: 829
title: Hi Speed Yoda
date: 2005-08-31T06:35:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hi-speed-yoda
permalink: /2005/08/31/hi-speed-yoda/
categories:
  - Fun!
description: "Discover a hilarious high-speed Yoda video that's work-safe and guaranteed to entertain. Download this 14MB gem for some Star Wars comedy gold!"
---
<p>You just <span class="caps">HAVE</span> to check <a href="http://homepage.hispeed.ch/molph/vids/yoda.mpg">this</a> out! It's big (14 + megs) but work safe (no naughty bits showing).</p>