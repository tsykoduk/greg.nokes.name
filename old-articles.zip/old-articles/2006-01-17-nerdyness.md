---
id: 1219
title: Nerdyness
date: 2006-01-17T14:26:01+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/nerdyness
permalink: /2006/01/17/nerdyness/
categories:
  - Fun!
description: "Discover how nerdy you really are! Take the ultimate nerd test and find out if you're nerdier than 86% of the population. Fun personality quiz results inside."
---
<center><a href="http://www.nerdtests.com/ft_nq.php?im"><img src="http://www.nerdtests.com/images/ft/nq.php?val=1759" alt="I am nerdier than 86% of all people. Are you nerdier? Click here to find out!"/></a></center>

<p>Yup - that says it all.</p>


<p>(HT: <a href="http://www.davejustus.com">Justus</a> the big non-nerd. I think that he cheated.)</p>