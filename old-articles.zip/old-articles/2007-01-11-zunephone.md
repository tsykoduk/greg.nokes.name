---
id: 2092
title: Zunephone
date: 2007-01-11T02:06:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/zunephone
permalink: /2007/01/11/zunephone/
categories:
  - Computers! and Code!
  - Fun!
---
<p>I gotta get me two of these!</p>


<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/WRLRjKCGHek"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/WRLRjKCGHek" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>