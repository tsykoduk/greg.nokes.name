---
id: 1116
title: Hybrids down in flames?
date: 2005-11-14T14:14:57+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hybrids-down-in-flames
permalink: /2005/11/14/hybrids-down-in-flames/
categories:
  - Science!
description: "Despite being the most fuel-efficient cars available, gas-electric hybrids struggle to justify their high sticker prices economically, raising questions about their viability."
---
<blockquote>Gas-electric hybrids are the most fuel-efficient passenger cars on the road and ecologically there isn't a more viable option. Until something big changes, though, the industry-high efficiency can't economically offset the steep sticker price.</blockquote>
-<a href="http://www.omninerd.com/articles/articles.php?aid=41">OmniNerd</a>

<p>I have been saying this for quite a while now. They just did the math to prove it.</p>