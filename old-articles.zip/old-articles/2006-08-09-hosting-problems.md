---
id: 1441
title: 'Hosting problems...'
date: 2006-08-09T19:54:40+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hosting-problems
permalink: /2006/08/09/hosting-problems/
categories:
  - Computers! and Code!
---
<p>Looks like the spam bots might have chalked up another victory. This site (and all on my account) were taken down due to a massive database hit - all comments. I assume that the spambots where hammering me - and hammering me hard.</p>


<p>Well, we have added another layer to the defenses. I brought <a href="http://error.wordpress.com/2006/07/04/bad-behavior-2/">Bad Behavior</a> back. We'll see how this works...</p>