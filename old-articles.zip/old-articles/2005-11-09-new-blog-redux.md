---
id: 1111
title: New Blog Redux
date: 2005-11-09T20:58:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-blog-redux
permalink: /2005/11/09/new-blog-redux/
categories:
  - Computers! and Code!
description: "Greg Nokes shares his latest blog creation - Opinions from On High - discussing his recent blog building frenzy and highlighting the visual design elements he's proud of."
---
<p>Just got done with another new blog - <a href="http://princess.nokes.name">Opinions from On High</a>. I guess that I have been on a blog building frenzy as of late. This one I am really proud of though. I like the effects, and I think that the colors really go well.</p>