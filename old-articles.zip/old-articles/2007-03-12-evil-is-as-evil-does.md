---
id: 2227
title: ''Evil is as evil does''
date: 2007-03-12T17:27:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/evil-is-as-evil-does
permalink: /2007/03/12/evil-is-as-evil-does/
categories:
  - Fun!
---
<table width=350 align=center border=0 cellspacing=0 cellpadding=2><tr><td bgcolor="#CCCCCC" align=center>
<font face="Georgia, Times New Roman, Times, serif" style='color:black; font-size: 14pt;'>
<strong>You Are 66% Evil</strong>
</font></td></tr>
<tr><td bgcolor="#DDDDDD">
<center><img src="http://images.blogthings.com/howevilareyouquiz/evil-4.jpg" height="100" width="100"></center>
<font color="#000000">
You are very evil. And you're too evil to care.<br />
Those who love you probably also fear you. A lot.
</font></td></tr></table>
<div align="center"><a href="http://www.blogthings.com/howevilareyouquiz/">How Evil Are You?</a></div>