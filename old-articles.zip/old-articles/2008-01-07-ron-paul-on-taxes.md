---
id: 3075
title: Ron Paul on Taxes
date: 2008-01-07T23:20:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/ron-paul-on-taxes
permalink: /2008/01/07/ron-paul-on-taxes/
categories:
  - Philosophy! and Politics!
---
<blockquote>The Founding Fathers did not have this current state of taxation in mind when the high taxes of England drove them to rebellion and the creation of our nation.</blockquote>

<p>-<a href="http://www.ronpaul2008.com">Ron Paul</a> in his <a href="http://www.house.gov/paul/tst/tst97/tst032097.htm">Texas Straight Talk column, March 20, 1997</a></p>


<p>My query is: How much have taxes gone up since then?</p>