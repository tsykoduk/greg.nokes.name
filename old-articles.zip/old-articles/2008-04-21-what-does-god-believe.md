---
id: 7161
title: What does God Believe?
date: 2008-04-21T15:37:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/what-does-god-believe
permalink: /2008/04/21/what-does-god-believe/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><a href="http://www.tmcm.com/comics/tags/too+much+coffee+man/169_athe"><img src="https://greg.nokes.name/assets/2008/4/20/169_athe.gif"></a></p>