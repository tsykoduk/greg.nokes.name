---
id: 910
title: '419'ers Monologue'
date: 2005-09-30T07:45:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/419-ers-monologue
permalink: /2005/09/30/419-ers-monologue/
categories:
  - Fun!
description: "Based on the full content, this appears to be a very brief blog post from 2005 that simply shares a link to zefrank.com and mentions having a day off for housework. The title \"419'ers Monologue\" is misleading as it doesn't actually contain content about 419 scams (Nigerian email scams). Here's an SEO-optimized meta description:"
---
<p>Yeah - <a href="http://www.zefrank.com/request/index_better.html">this</a> is actually really cool!</p>


<p>In other news I have the day off (WooHoo!) in order to do some housework (Booo! Hisss!) Got the tunes blasting right now...</p>