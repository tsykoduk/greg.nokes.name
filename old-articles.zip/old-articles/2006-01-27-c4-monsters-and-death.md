---
id: 1243
title: c4, Monsters and Death
date: 2006-01-27T23:30:23+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/c4-monsters-and-death
permalink: /2006/01/27/c4-monsters-and-death/
categories:
  - Fun!
description: "Explore C4 explosive gameplay with hamsters, monsters, and death-defying action in this quirky gaming experience that combines strategy and dark humor."
---
<p><a href="http://www.deathjr.com/c4hamstergame/">Heh</a></p>