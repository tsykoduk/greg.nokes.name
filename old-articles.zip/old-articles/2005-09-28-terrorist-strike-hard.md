---
id: 909
title: Terrorist strike hard
date: 2005-09-28T17:59:45+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/terrorist-strike-hard
permalink: /2005/09/28/terrorist-strike-hard/
categories:
  - Fun!
  - Philosophy! and Politics!
description: "Digital terrorism in gaming raises questions about virtual threats and publisher responsibility when malicious players spread chaos in MMORPGs and online worlds."
---
<blockquote> A digital virus spread by terrorists left bodies on the streets and cities quarantined by the government...For a week, the efforts of malicious players left behind massive casualties, made cities nearly uninhabitable...</blockquote>

<p>-<a href="http://www.securityfocus.org/news/11330">SecurityFocus</a></p>


<p>Luckily this was just in a game - but this poses an interesting thought. In game, terrorists took a plague and spread it all over. I don't know if the terrorists had any agenda besides death and destruction, but what if they had? Could you threaten a <span class="caps">MMOG</span> publisher with acts of in game terror to get some change made? Could they hold you responsible for acts of in game terror?</p>