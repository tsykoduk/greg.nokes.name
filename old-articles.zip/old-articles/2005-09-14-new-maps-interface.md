---
id: 879
title: New Maps Interface
date: 2005-09-14T17:34:40+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-maps-interface
permalink: /2005/09/14/new-maps-interface/
categories:
  - Computers! and Code!
description: "Discover the new FlashEarth interface that combines Google Maps and MSN Virtual Earth into one powerful mapping tool for enhanced navigation and exploration."
---
<p>There is a new interface to Google Maps and <span class="caps">MSN VE</span> out there - <a href="http://www.flashearth.com/">Check</a> it out!</p>