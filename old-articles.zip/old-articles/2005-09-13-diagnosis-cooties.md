---
id: 868
title: 'Diagnosis: Cooties'
date: 2005-09-13T13:18:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/diagnosis-cooties
permalink: /2005/09/13/diagnosis-cooties/
categories:
  - Fun!
description: "Personal goals and abilities shared through a playful \"7 things\" meme tag from a tech blogger, covering life aspirations from retirement to transcendence and quirky talents."
---
<p>I should have known better then to trust a <a href="http://welcomesithlords.blogspot.com/2005/09/diagnosis-cooties.html">Sith Lord</a>!</p>


<blockquote>So unless I want 7 years of bad luck, or whatever bad befalls those who don't participate in the tag, I should answer these questions seven:</blockquote>

<p>&lt;!<del>-more</del>-&gt;
7 things I plan to do before I die:</p>


<p>1) Retire, and enjoy it.
2) Finish a project. Any freaking project!
3) Collect all of them!
4) Get my pilot's license
5) Learn to Scuba
6) Dance on the head of a pin (working on building a really big pin)
7) Transend</p>


<p>7 things I can do:</p>


<p>1) Focus really hard
2) Forget things really well
3) Lie well
4) Use lies to make funnies ("They just found out that ketchup is cancer causing." "Really??" "Noooo. Silly")
5) Recall all sorts of strange facts (great at trivial pursuits and cranium)
6) Have fun!
7) Enjoy myself even if I am not 'winning'</p>


<p>7 things I cannot do:</p>


<p>1) Play pool well (not that I do not try...)
2) Play golf well (not that I do not try...)
3) Talk to girls (luckly Wifie did all of the talking the first - oh - several years)
4) Dodge wifie's thrown shoes when I give her lip.
5) Understand stupid people (that includes me. I can be really stupid at times)
6) Eat just one.
7) Be totally serious</p>


<p>7 things that attract me to the opposite sex:</p>


<p>1) Committed (as in long term relationships - alto the other helps too...)
2) Smart
3) Funny
4) Upbeat (cannot stand mopyness. I do enough of that myself)
5) Energetic
6) Understanding that I am a total screwup, and being ok with it
7) Some one that is not weak - Some one that can take care of herself.
8) Some one just like Wifie (to make up for #3 above, so I do not have to practice #4)</p>


<p>7 things I say most often:</p>


<p>1) Have Fun!
2) Have A Good One
3) I'd like a venti, triple, black and white mocha, soy and no wip
4) I'm tired honey...
5) I don't want to do the dishes!
6) One more game, honey, Please?
7) Ouch.</p>


<p>7 celebrity crushes:</p>


<p>1) Hmmm... Laura Croft (money and... um... yeah)
2) Traci Lords
3) RuPaul
4) the chic in Alias
5) Starbuck in the new Battlestar
6) Tux, the Linux Pengiun
7) Aphrodite (you know, the greek goddess?)</p>


<p>7 people I want to do this:</p>


<p>1) I second ObiWazzhisfaceKenobi
2) IllumanitiRob
3) Mystic
4) Dave Justus (sucks, don't it? Trying to be a serious blogger and you get this?)
5) Elmo
6) God
7) You - There - Reading this! Yes, you. You too!</p>