---
id: 1520
title: 37 Signals on Why Mac?
date: 2006-10-20T00:29:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/37-signals-on-why-mac
permalink: /2006/10/20/37-signals-on-why-mac/
categories:
  - Computers! and Code!
---
<p>You can see the video <a href="http://www.apple.com/education/whymac/compsci/video.html">Here</a>.</p>


<p>I agree a lot with what they say - but I add that the Mac just gets out of the way. Things work like I expect them to, and I do not have to think about the details of what I am doing as much as the big picture.</p>


<p>To steal a marketing slogan - "Mac: Let your fingers do the walking"</p>