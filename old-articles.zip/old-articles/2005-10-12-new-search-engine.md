---
id: 973
title: New search engine
date: 2005-10-12T15:22:52+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-search-engine
permalink: /2005/10/12/new-search-engine/
categories:
  - Fun!
description: "Discover Gizoogle, the unique search engine that translates web results into Snoop Dogg-style slang. Fun alternative search tool with entertaining results."
---
<p>I found this new search engine. Its pretty cool. I think tizzy <span class="caps">I W</span>-to-tha-izzill use it fizzle now on</p>


<table border="0" cellpadding="2" cellspacing="0"><tr>
<form target=_blank action="http://www.gizoogle.com" name="submit" method="get" style="margin-left: 2em;"><td>
<div align="center"><img src="http://www.gizoogle.com/logo_small.gif" width="197" height="46"/><br />
<input maxlength="256" size="20" name="criterion" value="" style="font-size:75%;"/>
<input type="submit" value="Siz-earch" style="font-size:65%;"/></div></td></form></tr></table>

<blockquote>In tha first story, Spokane po-po brotha were unavailable ta respond ta a citizen clockin' n interven'n in a felony in progress where tha potential fo` violence was real. In tha second story, Spokane po-po offica were available ta be dispatched ta investigate a 'false alarmâ€ at an unoccupied business, Anthony's Restaurant, a site favored by Spokane Mayor Jim Wizzy . Hollaz to the East Side.</blockquote>