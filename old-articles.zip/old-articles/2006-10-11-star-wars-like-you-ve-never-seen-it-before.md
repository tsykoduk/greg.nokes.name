---
id: 1498
title: 'Star Wars like you've never seen it before'
date: 2006-10-11T12:27:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/star-wars-like-you-ve-never-seen-it-before
permalink: /2006/10/11/star-wars-like-you-ve-never-seen-it-before/
categories:
  - Computers! and Code!
  - Fun!
---
<p>You have to telnet to towel.blinkenlights.nl - open a command prompt and type telnet towel.blinkenlights.nl</p>


<p>Ok.. so, go to start/run and type in cmd.exe.</p>


<p>Got it?</p>


<p>Good.</p>