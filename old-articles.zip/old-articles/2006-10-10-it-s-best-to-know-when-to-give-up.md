---
id: 1496
title: 'It's best to know when to give up...'
date: 2006-10-10T10:02:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-best-to-know-when-to-give-up
permalink: /2006/10/10/it-s-best-to-know-when-to-give-up/
categories:
  - Fun!
---
<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/y_toelZ664c"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/y_toelZ664c" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>