---
id: 1429
title: More on Net Neturality
date: 2006-06-24T16:56:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-on-net-neturality
permalink: /2006/06/24/more-on-net-neturality/
categories:
  - Philosophy! and Politics!
---
<blockquote>Net neutrality is this:

<code>If I pay to connect to the Net with a certain quality of service, and you pay to connect with that or greater quality of service, then we can communicate at that level.</code>

<p>That's all. Its up to the ISPs to make sure they interoperate so that that happens.
Net Neutrality is <span class="caps">NOT</span> asking for the internet for free.</p>


<p>Net Neutrality is <span class="caps">NOT</span> saying that one shouldn't pay more money for high quality of service. We always have, and we always will</blockquote></p>


<p>-<a href="http://en.wikipedia.org/wiki/Tim_Berners_Lee">The Inventor of the World Wide Web</a>, Sir Tim Berners-Lee.</p>


<p>Go - read the <a href="http://dig.csail.mit.edu/breadcrumbs/node/144">rest of his post</a>. This is a very serious issue, and could have major impacts on the ability of the United States to continue to compete in the new global economy...</p>