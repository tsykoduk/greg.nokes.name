---
id: 1587
title: New version of Office Space
date: 2006-11-09T21:09:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-version-of-office-space
permalink: /2006/11/09/new-version-of-office-space/
categories:
  - Fun!
---
<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/dGNs7QMeV7E"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/dGNs7QMeV7E" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>