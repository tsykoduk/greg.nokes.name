---
id: 960
title: Google Newreader
date: 2005-10-07T23:52:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-newreader
permalink: /2005/10/07/google-newreader/
categories:
  - Computers! and Code!
description: "Google launches a promising new RSS feed reader that works seamlessly on Mac, offering a potential alternative to Safari's built-in RSS capabilities."
---
<p>I read a lot of <span class="caps">RSS</span> feeds - and I have trying to find a tool that will help keep them all straight. The best reader that I have found is safari - it's included with my Mac, it does a good job and it's really straight forward.</p>


<p>Enter <a href="http://www.google.com/reader/things/intro">Google</a>. Looks like they just might have another kewl tool in the wings. It's a bit slow right now, but I expect to see good things coming from this. And - in a google first - it works with Mac right out of the gate!</p>