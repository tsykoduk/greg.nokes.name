---
id: 3059
title: Spokane RP Folks
date: 2008-01-01T23:01:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spokane-rp-folks
permalink: /2008/01/01/spokane-rp-folks/
categories:
  - Philosophy! and Politics!
---
<center><object width="425" height="373"><param name="movie" value="http://www.youtube.com/v/cgbguIr-IlE&#38;rel=1&#38;border=1"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/cgbguIr-IlE&#38;rel=1&#38;border=1" type="application/x-shockwave-flash" wmode="transparent" width="425" height="373"></embed></object></center>