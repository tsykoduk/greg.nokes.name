---
id: 1343
title: 4 billion loosers!
date: 2006-04-20T09:47:13+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/4-billion-loosers
permalink: /2006/04/20/4-billion-loosers/
categories:
  - Fun!
  - Philosophy! and Politics!
description: "5-hour limit reached ∙ resets 6pm"
---
Scott Adams <a href="http://dilbertblog.typepad.com/the_dilbert_blog/2006/04/4_billion_loser.html">asks</a>
<blockquote>Now I have another question for the believers. And by the way, I'm genuinely curious. I don't do this just to stir up things, although that's fun too. I actually wonder how you think. My question is this: How do you explain to yourself that 4 billion people (minimum) believe different from you?

<p>These are the only reasons I can imagine. Pick one or tell me what I missed.</blockquote>
A good read.</p>