---
id: 1191
title: Cross site plug
date: 2005-12-27T13:50:55+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cross-site-plug
permalink: /2005/12/27/cross-site-plug/
categories:
  - Mundane
description: "Learn why Internet Explorer poses security risks and discover better browser alternatives. Includes security testing tools and expert recommendations for safer web browsing."
---
<p>I just wrote a <em>most excellent</em> article on Internet Explorer's security over at the <a href="http://geek.nokes.name/2005/12/27/microsoft-ie-unsafe/">Geek's Grotto</a>. If you are still using IE, you might want to check it out. It includes a link to a browser security check site that seems to be pretty darn good.</p>