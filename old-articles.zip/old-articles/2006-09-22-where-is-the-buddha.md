---
id: 1471
title: Where is the Buddha?
date: 2006-09-22T08:47:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/where-is-the-buddha
permalink: /2006/09/22/where-is-the-buddha/
categories:
  - Philosophy! and Politics!
---
<blockquote>The Buddhist Channel is pleased to present to you the last book written by the late Chief Ven. Dr K Sri Dhammananda. To fulfill the wish of  the late venerable, this e-Book shall be distributed free of charge. Please help to fulfill his wish by forwarding it to as many people as you can.</blockquote>

<p>To help, I am also hosting this book <a href="https://greg.nokes.name/assets/2006/9/22/WhereistheBuddha.pdf">here</a>. It's a great read....</p>