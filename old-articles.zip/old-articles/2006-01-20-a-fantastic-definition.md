---
id: 1213
title: A fantastic definition
date: 2006-01-20T14:49:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-fantastic-definition
permalink: /2006/01/20/a-fantastic-definition/
categories:
  - Fun!
description: "Based on the content, this appears to be a very short blog post from 2006 that simply links to Uncyclopedia's definition of nihilism and asks for reader's opinions. Given the minimal content and humorous nature (linking to Uncyclopedia, which is a parody wiki), here's an SEO-optimized meta description:"
---
<p>is <a href="http://uncyclopedia.org/wiki/Nihilism">here.</a> What do you think? Does it define the word correctly?</p>