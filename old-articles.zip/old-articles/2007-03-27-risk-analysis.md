---
id: 2248
title: Risk Analysis
date: 2007-03-27T14:35:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/risk-analysis
permalink: /2007/03/27/risk-analysis/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<embed src="http://images.gocomics.com/images/drm/comicViewerUc.swf?w=600&#38;h=195&#38;k=341f0f0629f42282ad4a9a2b737b8fa1" width="600" height="195" quality="high" wmode="transparent" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash"></embed>

<p>From <a href="http://www.gocomics.com/calvinandhobbes/2007/03/27/">Go Comics</a></p>