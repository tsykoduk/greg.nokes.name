---
id: 844
title: Pocket Mod
date: 2005-09-06T06:48:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/pocket-mod
permalink: /2005/09/06/pocket-mod/
categories:
  - Fun!
description: "PocketMod is a free DIY personal organizer that transforms a single sheet of paper into a functional PDA. Learn how to create your own portable planner today!"
---
<p>A new <a href="http://www.pocketmod.com/"><span class="caps">PDA</span></a> - best of all, it's Free!</p>