---
id: 1497
title: 'Ain't technology grand?'
date: 2006-10-10T11:06:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/technology
permalink: /2006/10/10/technology/
categories:
  - Computers! and Code!
  - Science!
---
<p>Wait for it..</p>


<p>If you give this a chance, it's actually really cool...</p>


<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/NZNTgglPbUA"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/NZNTgglPbUA" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>