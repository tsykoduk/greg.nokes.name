---
id: 1308
title: bitty bits
date: 2006-03-14T22:26:39+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bitty-bits
permalink: /2006/03/14/bitty-bits/
categories:
  - Mundane
description: "Learn why tearing up credit card applications isn't enough to protect your identity. This eye-opening investigation reveals shocking security flaws in pre-approved offers."
---
<blockquote>You should probably buy a shredder today.

<p>I get a heck of a lot of credit card applications in the mail.
A bunch for Visa, quite a few from Mastercard and tons of them from American Express.</p>


<p>I almost always tear them in half and throw them away.</p>


<p>Sometimes, if I am feeling particularly paranoid, I'll tear them into little bitty pieces.</p>


<p>Is that good enough?</blockquote></p>


<p>Thus starts a great little <a href="http://www.cockeyed.com/citizen/creditcard/application.shtml">story</a>.</p>