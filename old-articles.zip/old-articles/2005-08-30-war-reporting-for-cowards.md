---
id: 822
title: War Reporting for Cowards
date: 2005-08-30T08:06:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/war-reporting-for-cowards
permalink: /2005/08/30/war-reporting-for-cowards/
categories:
  - Mundane
description: "Neurotic journalist Chris Ayres shares hilarious and harrowing tales from his time embedded with Marines during the Iraq invasion in this compelling NPR report."
---
<p>In <a href="http://www.npr.org/templates/story/story.php?storyId=4823346"> War Reporting for Cowards</a> NPR does a really interesting radio report about Chris Ayres, a self-described "neurotic, Gen-X hypochondriac," who ended up embedded in a Marine unit during the invasion of Iraq. He details out some of the hardships that he faced - like picking out a tent. A must listen!</p>