---
id: 1446
title: Site updates
date: 2006-08-16T20:31:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/site-updates
permalink: /2006/08/16/site-updates/
categories:
  - Mundane
---
<p>So, I have changed things up here yet again. I am still working on the new theme, but most of the dust has settled. I also updated the About page with some pithy words... ok... not pithy, but what the heck, eh?</p>