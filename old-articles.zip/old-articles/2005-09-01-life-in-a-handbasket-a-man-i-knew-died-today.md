---
id: 836
title: 'Life In A Handbasket: A Man I Knew Died Today'
date: 2005-09-01T09:47:48+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/life-in-a-handbasket-a-man-i-knew-died-today
permalink: /2005/09/01/life-in-a-handbasket-a-man-i-knew-died-today/
categories:
  - Philosophy! and Politics!
description: "A heartfelt tribute to a beloved colleague who passed away at 57, exploring how brief connections can profoundly impact our lives and the importance of cherishing each day."
---
<blockquote>A man I knew died today.

<p>I was working late when the news came in. It was a heart attack at around noon. He was 57 years old, and just retired a month earlier.</p>


<p>He was a good man, who enjoyed life, people, and a good laugh.</p>


<p>When visiting him at his desk I was always amazed at his knowledge, and his outlook on life. He enjoyed reading, and seemed to know everything about history and religion. Because of this I often tried to coax him into joining my website so we could dive deep into discussions, but he was never much of a computer person.</p>


<p>On the day he retired he was given a large red rocking chair, and looked very at home sitting in it with a grin from ear to ear.</p>


<p>Although I have only known him for about three years, the news of his passing hit me like a 2&#215;4 between the eyes. I liked him, enjoyed his company, and welcomed his manner as he spoke about life and living.</p>


<p>Someone was removed from life who really enjoyed it and there is no amount of pondering that can explain why. There is never any rhyme or reason when it comes to death. The man is gone, but his life will forever be remembered by those of us he has associated with.</p>


<p>The important thing is that this man was loved by many, and had touched more lives then I could explain here. I know that for the rest of my days I will always remember the brief time we had spent together locked in debate about life, the universe, and everything.</p>


<p>It was an honor to know this man, and to get to share in his wisdom if only for a short time. Would he have known of the impact he left in my life just from our acquaintance? Probably not, but then again, I believe it shows that how you live your life day to day can affect many people you would not even think of.</p>


<p>Go out into the world to work and play. Spend as much time with your family as you can, because each and every day is precious. More importantly, take a moment to remember those who have passed. Not to dwell on the sad times, but reflect on the good times. Think of them and smile. That is what they would want you to do.</p>


<p>A man I knew died today, and he will be missed.</blockquote></p>


<p>-<a href="http://www.handbasket.info/News/article/sid=165.html">Life In A Handbasket</a></p>


<p>The author of Life in A Handbasket is a co-worker of mine, as was the Man who Died yesterday. I knew him for over 5 years. We worked in different areas, but our paths crossed every month or so. I always enjoyed talking with him. He was a great man. One of the few great men that I had ever met.</p>


<p>My heart goes out to his family.</p>