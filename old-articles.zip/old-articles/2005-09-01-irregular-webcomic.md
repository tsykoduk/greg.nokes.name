---
id: 835
title: Irregular Webcomic
date: 2005-09-01T07:00:03+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/irregular-webcomic
permalink: /2005/09/01/irregular-webcomic/
categories:
  - Fun!
  - Philosophy! and Politics!
description: "Discover why Irregular Webcomic is a must-read daily comic through Greg's recommendation and featured strip analysis. Join the fun with creative storytelling and humor."
---
<p>The Irregular Webcomic is one of my daily reads - <a href="http://www.irregularwebcomic.net/cgi-bin/comic.pl?comic=949">today</a> showcases why!</p>