---
id: 1586
title: Just funny
date: 2006-11-08T22:56:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/just-funny
permalink: /2006/11/08/just-funny/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><a href="http://www.boingboing.net/2006/11/08/rumsfeld_resignation.html">This</a> is a pretty funny take on Rumsfeld's resignation, from a Mac Geek view..</p>