---
id: 1381
title: 'If fryer biodiesel smells like fries...'
date: 2006-05-12T10:13:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/if-fryer-biodiesel-smells-like-fries
permalink: /2006/05/12/if-fryer-biodiesel-smells-like-fries/
categories:
  - Science!
description: "5-hour limit reached ∙ resets 6pm"
---
<blockquote>Marlborough Company Produces World's First Sample Of Bio-Diesel From Algae Extracted From Region's Sewerage Ponds

<p>Marlborough-based Aquaflow Bionomic Corporation announced today that it had produced its first sample of home-grown bio-diesel fuel with algae sourced from local sewerage ponds.</p>


<p>'We believe this is the world's first commercial production of bio-diesel from algae outside the laboratory, in 'wild' conditions. To date, bio-diesel from algae has only been tested under controlled laboratory conditions with specially selected and grown algae crops,â€ explains Aquaflow spokesperson Barrie Leay</blockquote></p>


<p>-<a href="http://www.scoop.co.nz/stories/SC0605/S00030.htm">Scoop</a></p>