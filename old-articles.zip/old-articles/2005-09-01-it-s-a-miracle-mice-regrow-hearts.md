---
id: 837
title: 'It's a miracle! mice regrow hearts'
date: 2005-09-01T14:35:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-a-miracle-mice-regrow-hearts
permalink: /2005/09/01/it-s-a-miracle-mice-regrow-hearts/
categories:
  - Science!
description: "Scientists create miracle mice that can regenerate amputated limbs and damaged organs, offering hope for human medical breakthroughs in tissue regeneration and recovery."
---
<blockquote><span class="caps">SCIENTISTS</span> have created "miracle mice" that can regenerate amputated limbs or damaged vital organs, making them able to recover from injuries that would kill or permanently disable normal animals.

<p>The experimental animals are unique among mammals in their ability to regrow their heart, toes, joints and tail.</blockquote></p>


<p>-<a href="http://www.theaustralian.news.com.au/common/story_page/0,5744,16417002%255E30417,00.html">The Australian</a></p>


<p>We all know that 'mice today, people tomorrow'. Imagine the possibilities. Broken wrist that will never heal correctly? Chop it off, and let it regrow new.</p>


<p>It reminds me of a quote from Firefly.</p>


<blockquote>Wash: "Psychic, though? That sounds like something out of science fiction."

<p>Zoe: "We live in a space ship, dear."</blockquote></p>


<p>We are truly living in a spaceship, dear.</p>