---
id: 1123
title: Seen in the wild
date: 2005-11-17T19:28:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/seen-in-the-wild
permalink: /2005/11/17/seen-in-the-wild/
categories:
  - Computers! and Code!
description: "Discover the hilarious Longhorn dinner plate joke that mocked Microsoft's Windows Vista codename with a hidden Mac OS X logo - a classic tech humor moment from 2005."
---
<div align="center"><img src="http://www.tuaw.com/images/2005/04/longhorndinner.jpg" /></div>

<p>I just Have to get one!</p>


<p>Ok... for those that don't get the joke.</p>


<p>Longhorn was Microsoft's codename for Windows  Vista before they named it. Notice the little Mac <span class="caps">OS X</span> logo underneath.</p>


<p>Everyone laugh along now.</p>