---
id: 1440
title: 'Interesting talk...'
date: 2006-08-03T11:25:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/interesting-talk
permalink: /2006/08/03/interesting-talk/
categories:
  - Philosophy! and Politics!
---
Marilyn Manson on the O'Reily Factor:
&lt;!<del>-more</del>-&gt;
<center><object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/dE2ZB_uHfRw"></param><embed src="http://www.youtube.com/v/dE2ZB_uHfRw" type="application/x-shockwave-flash" width="425" height="350"></embed></object></center>

<p>Give it a chance - it's an interesting talk.</p>