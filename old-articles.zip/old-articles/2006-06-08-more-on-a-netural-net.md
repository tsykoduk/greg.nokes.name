---
id: 1411
title: 'More on a netural 'Net'
date: 2006-06-08T13:47:15+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-on-a-netural-net
permalink: /2006/06/08/more-on-a-netural-net/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
<blockquote><font size="-1"> Allowing broadband carriers to control what people see and do online would fundamentally undermine the principles that have made the Internet such a success...A number of justifications have been created to support carrier control over consumer choices online; none stand up to scrutiny."</font>
<font size="<del>1"&gt;</del> <a href="http://commerce.senate.gov/pdf/cerf-020706.pdf">Vint Cerf</a></font> <font size="-2">[PDF]</font>
<span style="font-size: 11px">Google Chief Internet Evangelist and Co-Developer of the Internet Protocol</span></blockquote>
and
<blockquote><font size="-1">The neutral communications medium is essential to our society. It is the basis of a fair competitive market economy. It is the basis of democracy, by which a community should decide what to do. It is the basis of science, by which humankind should decide what is true. Let us protect the neutrality of the net."</font><font size="-1">
- <a href="http://dig.csail.mit.edu/breadcrumbs/blog/4">Tim Berners-Lee</a></font>
<span style="font-size: 11px">Inventor of the World Wide Web</span></blockquote>
Check out the <a href="http://www.google.com/help/netneutrality.html">open letter</a> from <a href="http://en.wikipedia.org/wiki/Eric_Schmidt">Eric Schmidt
</a>