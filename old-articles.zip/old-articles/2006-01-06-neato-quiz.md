---
id: 1209
title: Neato Quiz
date: 2006-01-06T23:06:23+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/neato-quiz
permalink: /2006/01/06/neato-quiz/
categories:
  - Mundane
description: "Discover my Belief-O-Matic quiz results from Beliefnet, showing how religious and spiritual beliefs align with various faith traditions including Buddhism and Unitarian Universalism."
---
<p>So, I took the quiz at Beliefnet called "<a href="http://www.beliefnet.com/story/76/story_7665_1.html">Belief-O-Maticâ„¢</a>". Go and take it. My scores are after the jump...</p>


<p>&lt;!<del>-more</del>-&gt;</p>


<font size="2" face="verdana" color="#336699"><strong> </strong></font>
<table>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>1. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8041_1.html">Unitarian Universalism</a> <font size="2" color="#999999"> (100%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>2. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8042_1.html">Theravada Buddhism</a> <font size="2" color="#999999"> (98%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>3. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8058_1.html">Neo-Pagan</a> <font size="2" color="#999999"> (89%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>4. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8040_1.html">Secular Humanism</a> <font size="2" color="#999999"> (89%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>5. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8045_1.html">Mahayana Buddhism</a> <font size="2" color="#999999"> (83%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>6. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8038_1.html">Liberal Quakers</a> <font size="2" color="#999999"> (81%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>7. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8055_1.html">New Age</a> <font size="2" color="#999999"> (77%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>8. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8048_1.html">Jainism</a> <font size="2" color="#999999"> (67%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>9. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8059_1.html">Taoism</a> <font size="2" color="#999999"> (67%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>10. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8028_1.html">Mainline to Liberal Christian Protestants</a> <font size="2" color="#999999"> (66%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>11. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8049_1.html">Sikhism</a> <font size="2" color="#999999"> (62%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>12. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8027_1.html">Nontheist</a> <font size="2" color="#999999"> (61%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>13. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8054_1.html">Reform Judaism</a> <font size="2" color="#999999"> (57%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>14. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8047_1.html">Hinduism</a> <font size="2" color="#999999"> (50%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>15. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8056_1.html">New Thought</a> <font size="2" color="#999999"> (47%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>16. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8037_1.html">Orthodox Quaker</a> <font size="2" color="#999999"> (44%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>17. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8057_1.html">Scientology</a> <font size="2" color="#999999"> (44%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>18. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8051_1.html">BahÃ¡'Ã­ Faith</a> <font size="2" color="#999999"> (39%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>19. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8039_1.html">Christian Science (Church of Christ, Scientist)</a> <font size="2" color="#999999"> (31%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>20. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8053_1.html">Orthodox Judaism</a> <font size="2" color="#999999"> (31%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>21. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8052_1.html">Islam</a> <font size="2" color="#999999"> (22%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>22. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8029_1.html">Mainline to Conservative Christian/Protestant</a> <font size="2" color="#999999"> (22%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>23. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8035_1.html">Church of Jesus Christ of Latter-Day Saints (Mormons)</a> <font size="2" color="#999999"> (20%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>24. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8036_1.html">Seventh Day Adventist</a> <font size="2" color="#999999"> (18%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>25. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8033_1.html">Eastern Orthodox</a> <font size="2" color="#999999"> (13%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>26. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8030_1.html">Roman Catholic</a> <font size="2" color="#999999"> (13%) </font></strong><font size="2" color="#999999" /></font></td>
</tr>
<tr>
<td><strong><font size="2" face="verdana" color="#336699"><strong>27. </strong></font></strong></td>
<td><font size="2" face="verdana" color="#336699"><strong><a href="http://www.beliefnet.com/story/80/story_8034_1.html">Jehovah's Witness</a> <font size="2" color="#999999"> (10%)</font></strong></font></td>
</tr>
</table>
Interesting results - pretty much expected however. But 81% Liberal Quaker? that's just odd.