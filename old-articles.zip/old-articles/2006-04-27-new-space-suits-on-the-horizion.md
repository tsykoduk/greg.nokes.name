---
id: 1363
title: New Space Suits on the Horizion
date: 2006-04-27T21:24:39+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-space-suits-on-the-horizion
permalink: /2006/04/27/new-space-suits-on-the-horizion/
categories:
  - Philosophy! and Politics!
  - Science!
description: "5-hour limit reached ∙ resets 6pm"
---
<center><a href="http://mvl.mit.edu/EVA/biosuit/index.html"><img src="http://mvl.mit.edu/EVA/biosuit/biosuit_images/Newman_biosuit.jpg" /></a></center>Well, we are certainly getting closer to the a workable space suit. Gotta love those folks at <span class="caps">MIT</span>!