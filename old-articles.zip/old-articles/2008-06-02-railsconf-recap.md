---
id: 7207
title: RailsConf Recap
date: 2008-06-02T22:21:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/railsconf-recap
permalink: /2008/06/02/railsconf-recap/
categories:
  - Computers! and Code!
  - Fun!
  - Mundane
---
<p>So, I got to go hang out with all of the folks at RailsConf in portland this year. Way cool, lots of fun!</p>
<!--more-->

<p>Highlights:</p>


<p>"If you think I am lying, just punch me!" <del>- <span class="caps">WACK</span> -</del> OW! (the great brawl of 2008)</p>


<p>"Is that Bacon on that maple bar??" (asks a New Yorker)</p>


<p>"apparently we should use our surplus to build giant demonic penises. i mean, towers. yeah." (Via Twitter when <span class="caps">DHH</span>'s keynote shows a slide of Dubai)</p>


<p>"You mean we have been following directions from someone who's nickname was Mr Magoo? <span class="caps">WTF</span>??" (after 23 hour trek thru downtown portland looking for a bar... any bar...)</p>


<p>Yeah - so bad <a href="http://gallery.mac.com/tsykoduk#100008&#38;view=mosaic&#38;sel=0&#38;bgcolor=dkgrey">pictures</a> have been posted, sleep has been obtained, and the trip is over.</p>