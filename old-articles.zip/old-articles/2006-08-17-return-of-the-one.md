---
id: 1447
title: 'Return of the 'One''
date: 2006-08-17T18:30:39+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/return-of-the-one
permalink: /2006/08/17/return-of-the-one/
categories:
  - Philosophy! and Politics!
---
<p>If you cast your eyes to the upper right hand side of this site, you will see that the little 'ribbon banner' back. If you are a long time reader, you might recall <a href="https://greg.nokes.name/?s=one.org&#38;sbutt=Go">a few articles</a> about One.org. Go, and check it out. After all, they do not want you're money, just your voice...</p>