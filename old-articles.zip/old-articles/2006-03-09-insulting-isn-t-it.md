---
id: 1304
title: 'Insulting, isn't it?'
date: 2006-03-09T13:34:34+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/insulting-isn-t-it
permalink: /2006/03/09/insulting-isn-t-it/
categories:
  - Philosophy! and Politics!
description: "Exploring the democratic principle that no one has the right not to be insulted, and why this matters for racial and ethnic fairness in modern society."
---
<blockquote>So in a democracy no one, however powerful or impotent, can have a right not to be insulted or offended. That principle is of particular importance in a nation that strives for racial and ethnic fairness.</blockquote>
-From <a href="http://www.nybooks.com/articles/18811">The Right to Ridicule</a> By <a href="http://www.nybooks.com/authors/90">Ronald Dworkin</a>

<p>I've never heard of this guy before, but he certainly has written a lot. I really like what he said in this article, however. Good read.</p>