---
id: 3065
title: NYSE Goes Linux!
date: 2008-01-03T20:39:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/nyse-goes-linux
permalink: /2008/01/03/nyse-goes-linux/
categories:
  - Computers! and Code!
  - Fun!
---
<a href="http://ars.userfriendly.org/cartoons/?id=20071216"><img class="aligncenter" src="https://greg.nokes.name/assets/2008/1/3/uf011016.gif" alt="" width="432" height="317" /></a>