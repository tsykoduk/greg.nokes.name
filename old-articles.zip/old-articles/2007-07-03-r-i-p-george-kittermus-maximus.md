---
id: 2886
title: 'R.I.P. George 'kittermus Maximus'
date: 2007-07-03T18:54:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/r-i-p-george-kittermus-maximus
permalink: /2007/07/03/r-i-p-george-kittermus-maximus/
categories:
  - Mundane
  - Philosophy! and Politics!
---
<center><a href="http://www.flickr.com/photos/tsykoduk/8479792/" title="Photo Sharing"><img src="http://farm1.static.flickr.com/6/8479792_6878ca92d3_m.jpg" width="180" height="240" alt="Picture 007" /></a></center>

<p>Leukemia and Kidney Failure. He will be missed...</p>