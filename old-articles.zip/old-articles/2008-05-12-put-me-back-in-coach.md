---
id: 7183
title: Put me back in, coach!
date: 2008-05-12T22:05:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/put-me-back-in-coach
permalink: /2008/05/12/put-me-back-in-coach/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
<p>I just found <a href="http://www.secondrotation.com/">this site</a>. Really cool concept. Read it, use it, rinse and repeat. I have a feeling that ol' Lappy is going to them soon. Shela will be getting a newer laptop soon (she wants an Air) and I need an iMac to go with my new Macbook.</p>


<p>Anyways... good stuff. I will report back after Lappy is sent off to the wild blue.</p>