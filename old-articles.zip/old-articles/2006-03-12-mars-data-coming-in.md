---
id: 1306
title: Mars data coming in
date: 2006-03-12T21:11:03+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mars-data-coming-in
permalink: /2006/03/12/mars-data-coming-in/
categories:
  - Science!
description: "NASA's Mars Reconnaissance Orbiter successfully enters Mars orbit, promising unprecedented high-resolution images and crucial data for future Mars exploration missions."
---
<blockquote>With a crucially timed firing of its main engines today, <span class="caps">NASA</span>'s new mission to Mars successfully put itself into orbit around the red planet. </blockquote>

<p>-<a href="http://www.nasa.gov/mission_pages/MRO/news/mro-20060310.html"><span class="caps">NASA</span></a></p>


<p>With the red planets ability to suck probes into oblivion, this is good news. This orbiter will give us a better look at Mars then we have ever had before. As Mars is a likely target for our next big push in exploration, this is an important first step.</p>


<blockquote>"Our spacecraft has finally become an orbiter," said <span class="caps">JPL</span>'s Jim Graf, project manager for the mission. "The celebration feels great, but it will be very brief because before we start our main science phase, we still have six months of challenging work to adjust the orbit to the right size and shape." </blockquote>

<p>One of the things that I am really looking forward to is some of the pictures that this will give us. One of the cameras can send back over 700 mega-pixel images. There will be some great desktop pictures!</p>