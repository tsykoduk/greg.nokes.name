---
id: 998
title: Thoreau Speaks
date: 2005-10-28T21:47:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/thoreau-speaks
permalink: /2005/10/28/thoreau-speaks/
categories:
  - Philosophy! and Politics!
description: "Nature's fierce contest with Winter begins as Thoreau observes the bare trees revealing their muscular strength. Discover timeless insights on seasonal change and natural beauty from America's greatest transcendentalist philosopher."
---
<blockquote>Nature now, like an athlete, begins to strip herself in earnest for her contest with her great antagonist, Winter. In the bare trees and twigs what a display of muscle!</blockquote>

<p>-<a href="http://blogthoreau.blogspot.com/2005/10/thoreaus-journal-29-oct-1858.html">Thoreau</a></p>