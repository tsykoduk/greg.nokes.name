---
id: 15534
title: Talk at Lone Star Ruby Conf
date: 2013-08-20T14:08:43+00:00
author: Greg Nokes
layout: post
guid: https://greg.nokes.name/?p=15534
permalink: /2013/08/20/talk-at-lone-star-ruby-conf/
categories:
  - Mundane
tags:
  - Talks
excerpt_separator:  <!--more-->
---
I was invited to speak on a panel about Cloud Computing at Lone Star Ruby Conference this year. It was a good time, and not much blood was spilled. After the break, find the video...

<!--more-->


<iframe src="http://www.youtube.com/embed/BL_yHui-80M" height="315" width="560" allowfullscreen="" frameborder="0"></iframe>