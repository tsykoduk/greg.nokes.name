---
id: 1491
title: New version of Skeet Shooting?
date: 2006-10-05T01:24:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-version-of-skeet-shooting
permalink: /2006/10/05/new-version-of-skeet-shooting/
categories:
  - Fun!
---
<p><a href="http://www.glumbert.com/media/carshoot">This</a> seems like a great new sport...</p>