---
id: 665
title: Poll Finds Drop in Muslim Support for Terrorism
date: 2005-07-14T12:53:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/poll-finds-drop-in-muslim-support-for-terrorism
permalink: /2005/07/14/poll-finds-drop-in-muslim-support-for-terrorism/
categories:
  - Philosophy! and Politics!
---
<blockquote>Osama bin Laden's standing has dropped significantly in some key Muslim countries, while support for suicide bombings and other acts of violence has "declined dramatically," according to a new survey released today.

		<p>In a striking finding, predominantly Muslim populations in a sampling of six North African, Middle East and Asian countries are also as alarmed as Western nations about Islamic extremism, which is now seen as a threat in their own nations too, the poll found.</p>


		<p>"Most Muslim publics are expressing less support for terrorism than in the past. Confidence in Osama bin Laden has declined markedly in some countries, and fewer believe suicide bombings that target civilians are justified in the defense of Islam," concluded the Pew Global Attitudes Project.</blockquote></p>


		<p>- <a href="http://www.washingtonpost.com/wp-dyn/content/article/2005/07/14/AR2005071401030.html">Poll Finds Drop in Muslim Support for Terrorism</a></p>


		<p>I don't know if this is spun at all, but if it is true - are we starting to see the start of the beginning of the end?</p>