---
id: 166
title: Screenshot!
date: 2005-03-11T14:56:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/screenshot
permalink: /2005/03/11/screenshot/
categories:
  - Philosophy! and Politics!
---
<center><a href=http://www.nokes.name/photos/albums/userpics/10001/Screenshot.png><img src=http://nokes.name/photos/albums/userpics/10001/normal_Screenshot.png width="400" height="400" /></a></center><br /><br /><br />Here is a screenshot from the default install of Ubuntu Linux. They have done a really good job with a sexy look and feel, clean graphics, and a quick system. The only changes that I made from the default was to make the task bars translucent. You can click on the image for a 1:1 scale image - but it's really big.<br /><br />-Tsyko<br /><br /><i>Edit: So I guess that size does matter. At the request of several of you, I have made the screenshot on the Blog bigger</i>