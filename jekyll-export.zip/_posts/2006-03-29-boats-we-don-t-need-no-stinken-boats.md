---
id: 1319
title: 'Boats? We don&#039;t need no stinken boats!'
date: 2006-03-29T07:07:30+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/boats-we-don-t-need-no-stinken-boats
permalink: /2006/03/29/boats-we-don-t-need-no-stinken-boats/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><center><a class="imagelink" href="http://greg.nokes.name/wp-content/uploads/2006/03/116204838_862deb998e.jpg" title="116204838_862deb998e.jpg"><img id="image720" src="http://greg.nokes.name/wp-content/uploads/2006/03/116204838_862deb998e.thumbnail.jpg" alt="116204838_862deb998e.jpg" /></a></center></p>
<p>So - imagine my surprise when I woke up to this!</p>