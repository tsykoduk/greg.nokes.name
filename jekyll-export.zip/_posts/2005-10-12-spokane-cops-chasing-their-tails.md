---
id: 969
title: Spokane Cops Chasing their Tails?
date: 2005-10-12T11:57:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spokane-cops-chasing-their-tails
permalink: /2005/10/12/spokane-cops-chasing-their-tails/
categories:
  - Philosophy! and Politics!
---
<blockquote>In the first story, Spokane police officers were unavailable to respond to a citizen observing and intervening in a felony in progress where the potential for violence was real. In the second story, Spokane police officers were available to be dispatched to investigate a "false alarm" at an unoccupied business, Anthony's Restaurant, a site favored by Spokane Mayor Jim West.</blockquote>

	<p>-<a href="http://whitecaps.blogspot.com/2005/10/false-alarm-oh-send-cops-anyway.html">Whitecaps</a></p>


	<p>With the current budget woes that Spokane faces, Whitecaps makes some good points. Why respond to unverified alarms, and let citizens swing in the wind?</p>


	<p>Things that make you go Hmmm</p>