---
id: 771
title: Your password is like..
date: 2005-08-17T12:31:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/your-password-is-like
permalink: /2005/08/17/your-password-is-like/
categories:
  - Computers! and Code!
---
Your password is like a Lover. Best when enjoyed alone, and not passed around.
<blockquote>Let me just sum this up with a bit of security advice: Don't ever give your account info to anyone else <span class="caps">AND</span> don't ever let someone (not even Ma or Pa) use your computer logged in as you. Yes, there are times when you will want to for convenience sake, and I'm sure the usage will appear inert and innocent, but they always do. Guest accounts are there for a reason. Your account is meant for you and no one else.</blockquote>
-<a href="http://securityawareness.blogspot.com/2005/08/root-nasty-four-letter-word.html">Security Awareness for Ma, Pa and the Corporate Clueless</a>

I have run into many problems with accounts, passwords and failure to control them over the years.. a few of my favorites follow

<!--more-->

First off - years ago a company lets their network admin go. They leave on less then pleasant terms. A week later, they realize that they do not have the supervisor password to there NetWare 3.x box.

They call the ex-admin. He says that he does not have the password anymore. They panic

They call me - I charge them an hour's labor to drive out, and execute an <span class="caps">NLM</span> that changes the password for the supervisor user on a NetWare 3.x box.

Another one - An admin deletes the Admin account on a NetWare 4.x tree. The only admin account. They do not notice until they need to add another user. They cannot get into the tree to do anything.

They call me, I come out. They only tell me that they needed help adding a user. Several hours later (and a call to Novell Tech Support, a Fax to them with the signature of the owner of the company and a downloaded one shot <span class="caps">NLM</span>) we run an <span class="caps">NLM</span> and create a new admin user account.

A teacher leaves his computer logged in and unlocked during the lunch hour. Some kids use his computer to access less then appropriate material. The teacher is written up for accessing the material as it was his user name and computer that accessed it.

A user leaves his computer logged in. Another user uses his email account to send less then Politically Correct jokes to their supervisor. Guess who gets written up? The user that left his computer logged in.

All of this should go to show that your account is extremely important. Do not give out your password to anyone.

I used to run training for security awareness for several companies that I used to work for. I would ask the question - what if your helpdesk calls and needs your password for some work on your account?

What if the president of the US needs your password?

Just say no. Keep your passwords to yourself. Change your passwords often, and use things that are complex, and memorable.

like the following

Iluv2:)@thesun

I love to smile at the sun

Hard to guess, hard to hack, good password.

Good luck out there - it's a dangerous world!