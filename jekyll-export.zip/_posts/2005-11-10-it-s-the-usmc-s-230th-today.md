---
id: 1112
title: 'It&#039;s the USMC&#039;s 230th today!'
date: 2005-11-10T11:04:45+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/it-s-the-usmc-s-230th-today
permalink: /2005/11/10/it-s-the-usmc-s-230th-today/
categories:
  - Mundane
---
<p>It's the <a href="http://www.usmc.mil/"><span class="caps">USMC</span></a>'s 230th birthday today. I found this <a href="https://www.godaddy.com/gdshop/holiday/usmc/2005_playmovie.asp?isc=gdg1110&#38;se=%2B">little</a> flash movie about it.</p>


	<p>We do not always agree with the policys that send the Marines in, but with out them, the Army, Airforce, Navy and Coast Guard, we would not enjoy the freedoms that we do today.</p>


<blockquote>Don't hit at all if it is honorably possible to avoid hitting; but never hit soft.</blockquote>

	<p>-<a href="http://en.wikipedia.org/wiki/Teddy_Roosevelt">Theodore Roosevelt</a></p>


	<p>Here's to every one who ever served, is serving, or is going to serve.</p>


<hr />
Update: The <span class="caps">USMC</span>'s Birthday was yesterday (November 10th), however today is Veterans day in the US - A time to remember all those who helped and help us stay free.

	<p><a href="http://www.samanthaburns.com/archives/2005/11/remembrance_day_1.html">Sam</a> has some good info on Canada's contributions - let's not forget our neighbors to the north!</p>


	<p><a href="http://davejustus.blogspot.com/2005/11/thank-you.html">Justus</a> has a nice graphic up as well</p>


	<p>A very heartfelt <a href="http://botanicalgirl.blogspot.com/2005/11/thanks-to-veterans.html">article</a> - good stuff</p>