---
id: 96
title: How to feed Cats with Linux
date: 2005-02-14T20:42:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/how-to-feed-cats-with-linux
permalink: /2005/02/14/how-to-feed-cats-with-linux/
categories:
  - Computers! and Code!
  - Fun!
---
<p><a href="http://www.linuxjournal.com/article/7403">Chris McAvoy</a> writes:<br /><br /><blockquote>We have to work, but that doesn't mean our cats should have to go without stinky little fish, right? Why should our economic necessities have a negative effect on their treat times? Isn't it our responsibility to build them an Internet-enabled, Linux-based, cat-feeding device?</blockquote><br /><br />Heh - leave it to Linux geeks to coddle their kittens this much. Read on for all the 'gory' details</p>