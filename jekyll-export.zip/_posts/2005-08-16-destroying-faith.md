---
id: 750
title: Destroying Faith
date: 2005-08-16T08:29:59+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/destroying-faith
permalink: /2005/08/16/destroying-faith/
categories:
  - Philosophy! and Politics!
---
<blockquote>When we debunk a fanatical faith or prejudice, we do not strike at the root of fanaticism. We merely prevent its leaking out at a certain point, with the likely result that it will leak out at some other point. Thus by denigrating prevailing beliefs and loyalties, the militant man of words unwittingly creates in the disillusioned masses a hunger for faith. For the majority of people cannot endure the barrenness and futility of their lives unless they have some ardent dedication, or some passionate pursuit in which they can lose themselves. Thus, in spite of himself, the scoffing man of words becomes the precursor of a new faith.</blockquote>

		<p>-<a href="http://en.wikipedia.org/wiki/Eric_Hoffer">Eric  Hoffer</a></p>


		<p>(HT: <a href="http://hereticalideas.com/index.php?p=3151">Da Heretics</a>)</p>