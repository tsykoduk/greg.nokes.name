---
id: 518
title: Pictures from Darfur
date: 2005-06-09T15:22:45+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/pictures-from-darfur
permalink: /2005/06/09/pictures-from-darfur/
categories:
  - Philosophy! and Politics!
---
<p>Here is a really good <a href="http://www.flickr.com/photos/andrewheavens/sets/416158/">photo set</a> from Darfur.</p>


		<p>This is one of the things that I really think is fantastic about the "<em>new media</em>". People are able to post things almost as they happen. You are able to see views into others lives in unprecedented clarity. Shrinking the world is a good thing. If we know our neighbors, and know that they are people with wants, fears and needs just like we are, perhaps we will be less likely to want to kill them.</p>


		<p>I have great hopes for the future.</p>