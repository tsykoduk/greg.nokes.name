---
id: 664
title: Suicide Bombing as a Virus
date: 2005-07-14T11:06:56+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/suicide-bombing-as-a-virus
permalink: /2005/07/14/suicide-bombing-as-a-virus/
categories:
  - Philosophy! and Politics!
---
<p>It seems that some other folks are starting to 'get it'. <a href="http://greg.nokes.name/index.php?s=memes&#38;submit=Search">Toxic Memes</a> are the most dangerous threat to our race of all time.</p>


	<blockquote>It seems that what we're dealing with here is something far more elusive than a shadowy and sinister organization. It's an idea, a particularly virulent viral meme. It seeds itself via websites and chat rooms, is nurtured and grown in the soil of hate and disenfranchisement and eventually kills it's host. Trying to fight this idea with guns, arrests and an 'US' against 'THEM' dichotomy is stupid, pointless and just produces more mental fertilizer for the idea to grow in. The only way to fight ideas is through other ideas. Ideological antibiotics, administered through the opening of dialogue between communities, breaking down boundaries instead of setting them up and nurturing more beneficial strains of meme.</blockquote>

		<p>- <a href="http://www.donotthinkofablueelephant.co.uk/"> do not think of a blue elephant</a></p>


		<p>Changing the meme structure of these people is a hard row to hoe.</p>


	<blockquote>I wish I knew a sure fire silver bullet that would end Islamism. My bet is that the answer is accountable, democratic governments in the Middle East, but that is admittedly just a guess at this point.</blockquote>

		<p>- <a href="http://davejustus.blogspot.com/2005/07/some-democrats-get-it.html">Justus</a></p>


		<p>I think that this is a good start. Free societies tend to breed people that believe in tolerance more then death - more positive Memes if you will.</p>


		<p>However, this is just the start. This problem has been brewing since Biblical times. It's not going to end anytime soon.</p>