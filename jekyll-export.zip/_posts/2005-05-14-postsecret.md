---
id: 417
title: PostSecret
date: 2005-05-14T22:36:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/postsecret
permalink: /2005/05/14/postsecret/
categories:
  - Philosophy! and Politics!
---
<p>For those of you that have not gone to <a href="http://postsecret.blogspot.com/">PostSecret</a> here are two examples of why I read it</p>


		<p>(insert photo of cool postcard here)</p>


		<p>and</p>


		<p>(insert photo of cool postcard here)</p>


		<p><br />
	Every week, this site brings me insight, fear, humor and sadness. The complete range of human experience. I am a better person for it, and I want to thank the people behind it, and bring more people to it.
	<br />
	<i> Ok, so the pictures are not always coming through. When I get a chance, I will check out what I can do about that. Just go to the site - you will see what I mean.</i></p>