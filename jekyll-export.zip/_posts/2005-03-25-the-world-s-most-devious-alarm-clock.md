---
id: 135
title: 'The World&#039;s Most Devious Alarm Clock'
date: 2005-03-25T07:50:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-world-s-most-devious-alarm-clock
permalink: /2005/03/25/the-world-s-most-devious-alarm-clock/
categories:
  - Computers! and Code!
  - Fun!
---
<p><a href="http://hardware.slashdot.org/article.pl?sid=05/03/25/0017259&amp;from=rss">The World's Most Devious Alarm Clock</a><br /><br /><blockquote>from the snooze-bar-with-a-mallet dept.<br />wired_parrot writes 'If you have trouble waking up, try this: <span class="caps">MIT</span> media lab has created an alarm clock that, when you press the snooze bar, runs off into a corner, a different hiding place every day. Try hitting the snooze bar again now!'</blockquote><br /><br />Anyone that knows me, knows that I simply have to get one. That's too cool! Imagine the possibilities - you could set traps for it (<i>If I pile the clothes like this, when it jumps off the nightstand it will get stuck</i> or <i>Well, you see the alarm clock jumps down and hits this lever which trips this fan which blows this wirlygig which turns this crank which drops this ball into this track which rolls down and moves this seesaw which pushes this rod up which dumps this bucket of water into this other bucket which swings across the room which pushes this lever which turns on the coffee machine.</i>)<br /><br /><br />-Tsyko</p>