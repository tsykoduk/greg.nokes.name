---
id: 8203
title: How an engineer sees the world
date: 2009-01-14T17:46:00+00:00
author: tsykoduk
layout: post
guid: 30/2009/01/14/how-an-engineer-sees-the-world
permalink: /2009/01/14/how-an-engineer-sees-the-world/
categories:
  - Computers! and Code!
  - Fun!
---
Some times  you just have to assume that the rest of the world is insane and you are sane....

            <!--more-->

            <a href="http://xkcd.com/530/"><img src="http://imgs.xkcd.com/comics/im_an_idiot.png" style="width: 580px;" /></a>