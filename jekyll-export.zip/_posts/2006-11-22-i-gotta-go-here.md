---
id: 1603
title: 'I gotta go here&#8230;'
date: 2006-11-22T17:18:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-gotta-go-here
permalink: /2006/11/22/i-gotta-go-here/
categories:
  - Fun!
  - Philosophy! and Politics!
  - Science!
---
<p>I think that I will have to take a trip to this museum...</p>


<blockquote>The world's first Creationist museum - dedicated to the idea that the creation of the world, as told in Genesis, is factually correct - will soon open. Stephen Bates is given a sneak preview and asks: was there really a tyrannosaurus in the Bible?...

	<p>...Theological scholars may have noticed that there are, in fact, no dinosaurs mentioned in the Bible - and here lies the Creationists' first problem. Since there are undoubtedly dinosaur bones and since, according to the Creationists, the world is only 6,000 years old - a calculation devised by the 17th-century Bishop Ussher, counting back through the Bible to the Creation, a formula more or less accepted by the museum - dinosaurs must be shoehorned in somewhere, along with the Babylonians, Egyptians and the other ancient civilisations. As for the Grand Canyon - no problem: that was, of course, created in a few months by Noah's Flood.</p>


	<p>...But what, I ask wonderingly, about those fossilised remains of early man-like creatures? Marsh knows all about that: "There are no such things. Humans are basically as you see them today. Those skeletons they've found, what's the word? ... they could have been deformed, diseased or something. I've seen people like that running round the streets of New York."...</p>


	<p>...A little licence is allowed, however, where the Bible falls down on the details. The depiction of a wall-sized section of Noah's Ark is based, not on the traditional picture of a flat-decked boat, but one designed by navy engineers with a keel and bows, which might, at least, have floated. "You can surmise," says Marsh. When you get inside, there's nifty computer software telling you how they fitted all the animals in, too....</blockquote></p>


	<p>You know, this really speaks for it's self. But I still want to know - How did they fit 2 of each of the <a href="http://hypertextbook.com/facts/2003/FelixNisimov.shtml">between 2 and 100 million species</a> in a boat?</p>