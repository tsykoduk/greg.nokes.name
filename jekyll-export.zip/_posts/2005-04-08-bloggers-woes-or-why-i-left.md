---
id: 227
title: Bloggers Woes, or why I left..
date: 2005-04-08T11:31:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bloggers-woes-or-why-i-left
permalink: /2005/04/08/bloggers-woes-or-why-i-left/
categories:
  - Computers! and Code!
---
<p><a href="http://www.blogger.com">Blogger</a> is having major issues.</p>


	<p>I had my blog over there for quite a while, and honestly, I liked it. It was simple, effective and all in all a good thing.</p>


	<p>But <a href="http://www.blogger.com">Blogger</a> has grown too fast. They are having serious preformance issues. The commenting system crashes. There are no ping/trackbacks. They post <em>"it's a free service, don't complain"</em>. If I could have signed up for a pay account that actually worked, I would have. I really liked their software (except the trackback issue). I hated the cronic slowness and other problems.</p>


	<p>So, I got <a href="http://wordpress.org/">WordPress</a>.</p>


	<p>I put the problems squarely in the lap of <a href="http://www.blogger.com">Blogger.</a> They are now <a href="http://weblog.siliconvalley.com/column/dangillmor/archives/000802.shtml">owned</a> by <a href="http://www.google.com">Google.</a> Why not add a few hundred servers? Why not charge for premium accounts, and funnel that money back into expansion?</p>


	<p>Excuses aside, they are providing a service. If they expect to keep their good name, the service needs to meet expectations. If it does not, people will not use their service.</p>


	<p>Here's to hoping that <a href="http://www.blogger.com">blogger</a> will get it together and fix their issues - they have done a lot to advance blogging, and they could become a force to be reckoned with in the blogosphere. Heres hoping that they come back in full force.</p>


	<p>-Tsyko</p>