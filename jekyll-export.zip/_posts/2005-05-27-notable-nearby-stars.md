---
id: 489
title: Notable Nearby Stars
date: 2005-05-27T16:00:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/notable-nearby-stars
permalink: /2005/05/27/notable-nearby-stars/
categories:
  - Science!
---
<p><a href="http://www.solstation.com/stars.htm">Notable Nearby Stars</a> - a great resource page.</p>


		<p>Another <a href="http://www.projectrho.com/smap06.html">good page</a> - lots of 3d stuff.</p>


		<p><span class="caps">NASA</span>'s <a href="http://nstars.arc.nasa.gov/index.cfm">Nearby Stars Database</a></p>