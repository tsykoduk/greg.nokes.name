---
id: 1461
title: Not bad, but Not true.
date: 2006-09-20T15:07:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/not-bad-but-not-true
permalink: /2006/09/20/not-bad-but-not-true/
categories:
  - Philosophy! and Politics!
---
<blockquote>To be serious for a second: my thing about religion is generally not that it's bad, but that it's false. The history of religion is far too complex to be summed up as 'goodâ€ or 'bad,â€ and there are obviously components of both. The Salvation Army, odious discrimination policies notwithstanding, does a tremendous amount of good. Religious people are generally better at donating to charity than non-religious ones (last I heard; I don't have specific figures, so this could be wrong). And I like a lot of the art and architecture.</blockquote>

	<p>-<a href="http://cosmicvariance.com/2006/09/15/no-true-believer/">Sean at Cosmic Variance</a></p>


	<p>I think that most large movements (religious, political, economic) have good sides and bad sides.</p>


	<p>Look at Iraq. Saddam was an ruthless dictator who ruled with an iron fist, but the streets were safer. We are trying to give Iraq democracy and freedom, but the streets are less safe then a white guy in a white sheet with a pointy hat in Compton.</p>


	<p>I think that we need to look at all of our institutions, and remove the negative portions. They are simply not healthy for us, or for our children.</p>