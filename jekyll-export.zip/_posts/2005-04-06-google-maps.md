---
id: 205
title: Google Maps
date: 2005-04-06T13:18:25+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-maps
permalink: /2005/04/06/google-maps/
categories:
  - Computers! and Code!
---
<p>If you have not checked out <a href="http://maps.google.com">Google Maps</a> you really need to. It's a cross between keyhole and mapquest. Wow.</p>