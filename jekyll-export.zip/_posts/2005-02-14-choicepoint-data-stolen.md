---
id: 97
title: Choicepoint data stolen!
date: 2005-02-14T20:29:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/choicepoint-data-stolen
permalink: /2005/02/14/choicepoint-data-stolen/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
<p><a href="http://slashdot.org/">Slashdot</a> writes:<br /><br /><blockquote>Criminals posing as legitimate businesses have accessed critical personal data stored by ChoicePoint Inc., a firm that maintains databases of background information on virtually every U.S. citizen. The incident involves a wide swath of consumer data, including names, addresses, Social Security numbers, credit reports and other information. ChoicePoint notified between 30,000 and 35,000 consumers in California that their personal data may have been accessed by 'unauthorized third parties.' No obvious notice appears to be on their website.</blockquote><br /><br />Wow. Scary. Read <a href="http://www.epic.org/privacy/choicepoint/">this</a> for some background about who uses Choicepoint and what kind of services and data they provide.<br /><br />One would have hoped that a company that deals with such sensitive data would have stronger safeguards in place. Hopefully this breach is a wake up call for them and the rest out there...<br /><br />-Tsyko</p>