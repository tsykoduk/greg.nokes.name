---
id: 875
title: More information then you can shake a stick at!
date: 2005-09-13T20:07:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-information-then-you-can-shake-a-stick-at
permalink: /2005/09/13/more-information-then-you-can-shake-a-stick-at/
categories:
  - Computers! and Code!
---
<p>Ok.. so, I wanted to let ya'll know what tunes I was listening to (<em>out of some strange wanting to let the world live through my iTunes playlist</em>). So, if you now look at the 'sidebar' you will see <em>What's Playing</em>. Strangely enough, it shows what I am listening to right now.</p>


	<p>Ain't technology just cool?</p>