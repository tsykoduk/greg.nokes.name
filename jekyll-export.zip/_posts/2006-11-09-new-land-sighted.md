---
id: 1588
title: New Land Sighted!
date: 2006-11-09T21:23:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-land-sighted
permalink: /2006/11/09/new-land-sighted/
categories:
  - Philosophy! and Politics!
  - Science!
---
<blockquote>
	<p>The Pacific Ocean has given birth to a new volcanic island near <a href="http://maps.google.com/maps?f=q&#38;hl=en&#38;q=tonga&#38;ie=UTF8&#38;z=7&#38;t=k&#38;om=1">Tonga</a>, according to ocean-going eyewitnesses.</p>


	<p>Crew on board a yacht called the "Maiken" believed they were the first to see a volcanic island forming a day out
	from Neiafu, Tonga, while sailing towards Fiji in August, the Matangi Tonga news website reported Wednesday.</p>

</blockquote>




	<p>-<a href="http://www.seedmagazine.com/news/2006/11/pacific_ocean_gives_birth_to_n.php">Seed Magazine</a></p>


	<p>It's refreshing to be reminded about the cyclic nature of life and death and how it applies to so much more then just humans and other animals. This sort of event reminds me that I am insignificant in the grand scheme of things. Just think - there are events happening out there that dwarf anything we humans could conceive of doing at this time. <a href="http://antwrp.gsfc.nasa.gov/apod/ap061105.html">Case in point</a>. Humbling.</p>