---
id: 189
title: New communications methods discovered!
date: 2005-04-01T14:15:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-communications-methods-discovered
permalink: /2005/04/01/new-communications-methods-discovered/
categories:
  - Computers! and Code!
  - Science!
---
<p>From <a href="http://science.slashdot.org/article.pl?sid=05/04/01/1417218&#38;from=rss">Slashdot</a>..</p>


<blockquote>Odin's Raven writes "Opera Software's R-and-D department today announced the discovery of a new technology dubbed 'Opera SoundWave' - a platform-independent speech solution for short- and medium-range interpersonal communication. Based on open standards, Opera's patent-pending <span class="caps">P2P</span> speech technology uses analogue signals carried through open air, enabling users to communicate in real- time without the use of computers or mobile phones. Details (including link to tech preview) are available in their press release. I wonder how long it will be before a <span class="caps">FOSS</span> implementation of this technology emerges?"</blockquote>

	<p>Wow. that sounds really cool. I think that it could totally change the world, the way that we communicate and everything else. I think this is going to be big...</p>


	<p>Read more <a href="http://www.opera.com/pressreleases/en/2005/04/01/">Here</a>!</p>