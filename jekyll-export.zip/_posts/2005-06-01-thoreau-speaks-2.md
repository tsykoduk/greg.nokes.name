---
id: 496
title: Thoreau Speaks
date: 2005-06-01T14:00:52+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/thoreau-speaks-2
permalink: /2005/06/01/thoreau-speaks-2/
categories:
  - Philosophy! and Politics!
---
<blockquote>The morning wind forever blows; the poem of the world is uninterrupted, but few are the ears that hear it.</blockquote>

		<p>- <a href="http://blogthoreau.blogspot.com/">The Blog of Henry David Thoreau</a></p>