---
id: 7123
title: Black Holes, Stranglets and Oh My!
date: 2008-03-28T18:08:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/black-holes-stranglets-and-oh-my
permalink: /2008/03/28/black-holes-stranglets-and-oh-my/
categories:
  - Fun!
  - Science!
---
<blockquote>The builders of the world’s biggest particle collider are being sued in federal court over fears that the experiment might create globe-gobbling black holes or never-before-seen strains of matter that would destroy the planet.</blockquote>
This is serious. Globe Gobbling Black Holes? Destruction of the Planet? Stop the Presses!

<!--more-->
<p style="text-align: center;"><img id="thumber" class="aligncenter" src="http://greg.nokes.name/assets/2008/3/28/bad_earth.png" alt="" width="444" height="490" /><span style="font-size: 11px;"><a href="http://deanreevesii.deviantart.com/art/An-Earth-Shattering-Experience-146786821?q=gallery%3Adeanreevesii%2F23937479&amp;qo=0">Amazing Image</a> © 2008 <a href="http://www.deanreevesii.com">Dean Reeves</a> II</span></p>
(from <a href="http://cosmiclog.msnbc.msn.com/archive/2008/03/27/823924.aspx">MSNBC</a>)
<blockquote>The Large Hadron Collider, or LHC, is due for startup later this year at CERN’s headquarters on the French-Swiss border. It’s expected to tackle some of the deepest questions in science: Is the foundation of modern physics right or wrong? What existed during the very first moment of the universe’s existence? Why do some particles have mass while others don’t? What is the nature of dark matter? Are there extra dimensions of space out there that we haven’t yet detected?</blockquote>
Ok, so we have Big Science being done… but where are the black holes?
<blockquote>Former nuclear safety officer Walter Wagner has been raising such questions for years - first about an earlier-generation “big bang machine” known as the Relativistic Heavy-Ion Collider, and more recently about the LHC.

Last Friday, Wagner and another critic of the LHC’s safety measures, Luis Sancho, filed a lawsuit in Hawaii’s U.S. District Court. The suit calls on the U.S. Department of Energy, Fermilab, the National Science Foundation and CERN to ease up on their LHC preparations for several months while the collider’s safety was reassessed.</blockquote>
Ahhh… I start to see the light.

Silly people, science is Good! Honestly, (as the article discusses) the interaction between Cosmic Rays and the upper atmosphere is higher energy then this little dinky thing. After all, I seem to recall (but cannot find a citiation for) there was a fear that the first Fusion Bomb would cause a chain reaction and blow up the world’s oceans.

Some level of prudent care must be taken, but I doubt that these scientists <strong>want</strong> to blow up or implode the planet.

Here’s to the LHC providing us with lots of years of cool stuff to come!