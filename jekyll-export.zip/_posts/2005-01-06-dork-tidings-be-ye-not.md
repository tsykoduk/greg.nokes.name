---
id: 65
title: 'Dork Tidings &#8211; Be Ye Not&#8230;'
date: 2005-01-06T15:04:38+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/dork-tidings-be-ye-not
permalink: /2005/01/06/dork-tidings-be-ye-not/
categories:
  - Mundane
---
<p>The Almighty <a href="http://www.livejournal.com/users/muskrat_john">Muskrat</a> has some <a href=http://www.livejournal.com/users/muskrat_john/50021.html>good advice</a>...<br /><br />-Sicko</p>