---
id: 7054
title: Dell vs Apple
date: 2008-03-02T06:14:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/dell-vs-apple
permalink: /2008/03/02/dell-vs-apple/
categories:
  - Computers! and Code!
  - Fun!
---
<img class="aligncenter" src="http://greg.nokes.name/assets/2008/3/2/cQabNGVQIvrsACFGdd.jpg" alt="" width="420" height="252" />