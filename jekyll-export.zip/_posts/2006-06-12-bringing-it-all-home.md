---
id: 1414
title: 'Bringing it all home&#8230;'
date: 2006-06-12T13:57:54+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bringing-it-all-home
permalink: /2006/06/12/bringing-it-all-home/
categories:
  - Philosophy! and Politics!
---
In a comment on Lord Chimmy's <a href="http://bloodsuckingfiends.blogspot.com/2006/06/bitches.html">post</a> about Ann Coulter's new book, we are directed to <a href="http://www.commondreams.org/views06/0610-23.htm">this article</a>.
<blockquote>Now that its original meaning has been hopelessly distorted by hatred and bad vibes, the term "Christian" really should be banished to the hall of linguistic abominations where it belongs.

	<p>Say "Christian" in mixed company and the image of a bejeweled evangelist hawking a right-wing social agenda will come immediately to mind.</p>


	<p>Very few think of Christians as the same folks who embraced lepers and other social outcasts even before faith-based tax credits kicked in to provide "incentives" for doing the Lord's work.</blockquote>
Tony Norman really hits the nail on it's head. He does an excellent job of summing up what I have been trying to say:</p>


	<p>Christianity, as it is practiced today, is not a positive influence on the world. I really feel that today's version of Christianity is not all in sync with what Jesus taught. We will really never know, as we do not have any good accounts of his life, other then the massively edited and contradictory Bible.</p>


	<p>Some who call themselves Christians are very good and helping people, however, more are self absorbed and only really in it for the <em>afterlife insurance</em> policy that it gives. I was actually told "Well, since you do not believe in an afterlife, what's to stop you from being a Christian just in case they are right?" Am I missing something? Does God really want followers who follow for the sake of following?</p>


	<p>I propose the following: Re-write the Bible. Get rid of as many of the problems as you can. Extract the essence of Christianity, and repackage it for a new century. Don't say 'if it's not broke don't fix it' because it is broken. Look at the perception that is out there. "<em>Say "Christian" in mixed company and the image of a bejeweled evangelist hawking a right-wing social agenda will come immediately to mind.</em>" pretty much sums it up.</p>


	<p>Now, don't get me wrong. I am certainly not espousing moving the 'Christian Agenda' away from the Right. I simply want folks to understand what Christian means. And it's not forcing your version of family values down my throat through laws aimed at removing my choice. You could make a law that stated "everyone in this great nation was mandated to attend Church and profess the Christian Faith". Would that make us all Christian? I don't think so.</p>


	<p>That would simply take the rest of the meaning out of the word. We think it's barbaric when a person is executed in a Muslim country for infractions such as dressing wrong, but in attempting to make every action that does not agree with Christian morality illegal, we are fast slipping down the slope towards just such a barbaric legal system.</p>


	<p>I heard an Evangelical talking on some talk show. They said that they would use every means at their disposal to enforce their views - because if you disagreed with them, it was analogues to drinking drano, and of course we would try and stop someone from drinking drano. Yes, if I were to see some one drinking drano, I would attempt to stop them. I would do this because I have empirical evidence that drinking drano can kill or seriously harm you. No one has evidence that if you are not Christian, you are in physical or spiritual danger. We have beliefs about it, but beliefs do not proof make.</p>


	<p>I guess that I can sum it up as: Be damn sure before you force another person to act or not act in a certain way. There is nothing black and white in faith based religions. Faith, by definition, is not provable. When it comes to effecting others, make sure that you are on the side that is provably good."<em>an it harm none, do as thou wilt</em>"</p>