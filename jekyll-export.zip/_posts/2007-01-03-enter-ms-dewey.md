---
id: 1991
title: Enter Ms. Dewey
date: 2007-01-03T20:19:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/enter-ms-dewey
permalink: /2007/01/03/enter-ms-dewey/
categories:
  - Computers! and Code!
---
<p>Microsoft has a new search interface - <a href="http://www.msdewey.com/">Ms. Dewey</a>.</p>


	<p>This is bad UI design on so many levels. First off, it gets annoying in about 35.3 seconds. Secondly, it's a freaking pig. Slow, slow slow. And, to top it all off, you only get a few results after putting up with Ms. Dewey's lame jokes.</p>


	<p>I think that this really underscores how Microsoft views their consumers. They know best, and we just have to sit down, shut up and ride. I for one want off that wacky roller coaster.</p>


	<p>When are they going to realize, on Mount Redmond, that the consumer is fed up with crappy, insecure, poorly designed, not thought out bloatware?</p>


	<p>If you had a choice between a glitzy car, with all the bells and whistles, which would break down every 100 or so miles, or a sleek, well designed 100 mile to the gallon virtually indestructible car, or a free tank, which one would you choose? (read <a href="http://www.cryptonomicon.com/beginning.html">this</a> to get the analogy, and a good history of computers and the IT industry)</p>


	<p>I for one, use tanks for my servers, and sleek machines for my laptops.</p>