---
id: 61
title: Yummyness
date: 2005-01-09T09:23:31+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/yummyness
permalink: /2005/01/09/yummyness/
categories:
  - Mundane
---
<p>Left over Kielbasa in scrambled egges for breakfast. Then sno shoveling later and a nice quiet day.<br /><br />I love winter!</p>