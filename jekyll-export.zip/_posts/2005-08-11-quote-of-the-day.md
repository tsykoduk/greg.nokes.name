---
id: 730
title: Quote of the Day
date: 2005-08-11T21:48:15+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/quote-of-the-day
permalink: /2005/08/11/quote-of-the-day/
categories:
  - Philosophy! and Politics!
---
<blockquote>Mediocre minds usually dismiss anything which reaches beyond their own understanding.</blockquote>

	-Francois de La Rochefoucald

		<p>(HT: <a href="http://hereticalideas.com/index.php?p=3140">Heretical Ideas</a>)</p>