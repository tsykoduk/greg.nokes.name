---
id: 83
title: Top of the morning to ya!
date: 2005-02-19T08:57:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/top-of-the-morning-to-ya
permalink: /2005/02/19/top-of-the-morning-to-ya/
categories:
  - Philosophy! and Politics!
---
<center><img src="http://money.cnn.com/2003/09/04/pf/saving/pepsi_monkey_game/monkey.03.jpg"/></center>