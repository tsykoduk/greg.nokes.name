---
id: 289
title: 'Product Page &#8211; Gadget Universe'
date: 2005-04-19T14:56:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/product-page-gadget-universe
permalink: /2005/04/19/product-page-gadget-universe/
categories:
  - Fun!
---
<p><a href="http://www.gadgetuniverse.com/cgi-bin/sgin0101.exe?T1=TH+446&#038;FNM=25&#038;UID=2005040918585642&#038;GEN9=">We all need one of these.</a></p>


		<p>Oh my gawd.</p>