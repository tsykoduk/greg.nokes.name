---
id: 916
title: Re-Evolution
date: 2005-10-07T23:54:24+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/re-evolution
permalink: /2005/10/07/re-evolution/
categories:
  - Philosophy! and Politics!
---
<blockquote><em>If the truth can be told so as to be understood, it will be believed.</em>

	<p>Human history represents such a radical break with the natural systems of biological organization that preceded it, that it must be the response to a kind of attractor, or dwell point that lies ahead in the temporal dimension. Persistently Western religions have integrated into their theologies the notion of a kind of end of the world, and I think that a lot of psychedelic experimentation sort of confirms this intuition, I mean, it isn't going to happen according to any of the scenarios of orthodox religion, but the basic intuition, that the universe seeks closure in a kind of omega point of transcendance, is confirmed, it's almost as though this object in hyperspace, glittering in hyperspace, throws off reflections of itself, which actually ricochet into the past, illuminating this mystic, inspiring that saint or visionary, and that out of these fragmentary glimpses of eternity we can build a kind of map, of not only the past of the universe, and the evolutionary egression into novelty, but a kind of map of the future, this is what shamanism is always been about.</p>


	<p>A shaman is someone who has been to the end, it's someone who knows how the world really works, and knowing how the world really works means to have risen outside, above, beyond the dimensions of ordinary space, time, and casuistry, and actually seen the wiring under the board, stepped outside the confines of learned culture and learned and embedded language, into the domain of what Wittgenstein called "the unspeakable", the transcendental presense of the other, which can be absanctioned, in various ways, to yield systems of knowledge which can be brought back into ordinary social space for the good of the community, so in the context of ninety percent of human culture, the shaman has been the agent of evolution, because the shaman learns the techniques to go between ordinary reality and the domain of the ideas, this higher dimensional continuum that is somehow parallel to us, available to us, and yet ordinarily occluded by cultural convention out of fear of the mystery I believe, and what shamans are, I believe, are people who have been able to de-condition themselves from the community's instinctual distrust of the mystery, and to go into it, to go into this bewildering higher dimension, and gain knowledge, recover the jewel lost at the beginning of time, to save souls, cure, commune with the ancestors and so forth and so on.</p>


	<p>Shamanism is not a religion, it's a set of techniques, and the principal technique is the use of psychedelic plants. What psychedelics do is they dissolve boundaries, and in the presence of dissolved boundaries, one cannot continue to close one's eyes to the ruination of the earth, the poisoning of the seas, and the consequences of two thousand years of unchallenged dominator culture, based on monotheism, hatred of nature, suppression of the female, and so forth and so on. So, what shamans have to do is act as exemplars, by making this cosmic journey to the domain of the Gaian ideas, and then bringing them back in the form of art to the struggle to save the world. The planet has a kind of intelligence, that it can actually open a channel of communication with an individual human being. The message that nature sends is, transform your language through a synergy between electronic culture and the psychedelic imagination, a synergy between dance and idea, a synergy between understanding and intuition, and dissolve the boundaries that your culture has sanctioned between you, to become part of this Gaian supermind, I mean I think it's fairly profound, it's fairly apocalyptic. History is ending. I mean, we are to be the generation that witnesses the revelation of the purpose of the cosmos. History is the shock wave of the eschaton. History is the shock wave of eschatology, and what this means for those of us who will live through this transition into hyperspace, is that we will be privileged to see the greatest release of compressed change probably since the birth of the universe. The twentieth century is the shudder that announces the approaching cataracts of time over which our species and the destiny of this planet is about to be swept.</p>


	<p><em>If the truth can be told so as to be understood, it will be believed.</em></p>


	<p>The emphasis in house music and rave culture on physiologically compatible rhythms and this sort of thing is really the rediscovery of the art of natural magic with sound, that sound, properly understood, especially percussive sound, can actually change neurological states, and large groups of people getting together in the presence of this kind of music are creating a telepathic community of bonding that hopefully will be strong enough that it can carry the vision out into the mainstream of society. I think that the youth culture that is emerging in the nineties is an end of the millenium culture that is actually summing up Western civilization and pointing us in an entirely different direction, that we're going to arrive in the third millenium, in the middle of an archaic revival, which will mean a revival of these physiologically empowering rhythm signatures, a new art, a new social vision, a new relationship to nature, to feminism, to ego. All of these things are taking hold, and not a moment too soon.</blockquote></p>


	<p>-<a href="http://en.wikipedia.org/wiki/Terence_McKenna">Terence McKenna</a></p>


	<p>First off, I disagree that psychedelics are necessary, or even a good path. I think that the same results can be obtained with deep meditation and the search for enlightenment. Honestly, I feel that the results from a mediative study are easier to reproduce, and more 'accurate' then those obtained though the use of mind altering drugs and plants. In no way, take this as a validation of using drugs. Ok, that's out of the way! :)</p>


	<p>I was first introduced to this philosophy when I was listening to the Boss Drum by the Shamen about 12 or 15 years ago.  It really resonated with me on several levels.</p>


	<p>I just wanted to post it - because I find it fascinating.</p>