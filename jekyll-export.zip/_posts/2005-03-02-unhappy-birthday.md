---
id: 187
title: Unhappy Birthday!
date: 2005-03-02T12:07:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/unhappy-birthday
permalink: /2005/03/02/unhappy-birthday/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p>From <a href="http://www.unhappybirthday.com/">Unhappy Birthday</a><br /><blockquote> "Did you know Happy Birthday is copyrighted and the copyright is currently owned and actively enforced by Time Warner?<br /><br />Did you know that if you sing any copyrighted song:<br />...at a place open to the public<br />...or among a substantial number of people who are not family or friends<br />You are involved in a public performance of that work?<br /><br />Did you know an unauthorized public performance is a form of copyright infringement?"</blockquote><br /><br />You know, I had often wondered why many major chains (such as <a href = http://www.applebees.com/>Applebees) do not use the 'traditional' words. I had heard rumors before that the song was copyrighted, but I had never tracked down the reality of story. Enter <a href = http://mako.yukidoke.org/copyrighteous/projects/20050301-00.html>Mako</a>, your freindly neighboorhood anarchist. <br /><br />So, the moral of this story is this - If you sing Happy Birthday to your freind or family member in a public place, you can be sued for copyright infringement? Check out <a href = http://www.unhappybirthday.com/>Unhappy Birthday for the full scoop, and methods of turning in your freinds, foes and random people for this shocking crime!</p>