---
id: 172
title: 'You know you are a gamer when&#8230;'
date: 2005-03-07T22:48:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/you-know-you-are-a-gamer-when
permalink: /2005/03/07/you-know-you-are-a-gamer-when/
categories:
  - Fun!
---
<center><a href="http://dicepool.com/catalog/quiz.php"><br /><br /><img src="http://dicepool.com/catalog/images/splats/boring.jpg" height="200px" width="400px" alt="I am a d6"/></a><br /><br /><p><a href="http://dicepool.com/catalog/quiz.php">Take the quiz at dicepool.com</a></p></center>