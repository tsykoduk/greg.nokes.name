---
id: 856
title: Good comment stream!
date: 2005-09-09T09:38:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/good-comment-stream
permalink: /2005/09/09/good-comment-stream/
categories:
  - Philosophy! and Politics!
---
<blockquote> Who can we blame for building levies that were designed to withstand a cat 3 storm? Who can we blame for sending a cat 5 storm?

	<p>Let's fire God. If you want to push the blame up, and fire the guy who is really responsible, well, God let all of this happen right?</p>


	<p>God must be evil.</p>


	<p>All of this blame and firing crap is just stupid, as the previous few paragraphs tried to point out. Bush is not an evil person. Clinton was (is) not evil. I disagreed with his handling of a lot of things (Somalia, the Balkans, Cigars) however, I did not, and do not, think that he was the devil. When I got the chance, I voted my feelings, and lost (he got a second term). I accepted that. I am a grownup - I know that I do not always get my way.</blockquote></p>


	<p>That is my latest post on <a href="http://emilyscraziness.blogspot.com/2005/09/frustration.html">this</a> comment stream. Good stuff, on a Good Blog!</p>