---
id: 366
title: Political Tests and scores
date: 2004-10-14T16:13:43+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/political-tests-and-scores
permalink: /2004/10/14/political-tests-and-scores/
categories:
  - Philosophy! and Politics!
---
<p><span style="font-family:arial;">I guess that this is the day to take political tests... </span></p><p>
<span style="font-family:arial;">The thing to be aware of (as I am sure that you are) is that the questions tend to corral you into the responses that the askers want.

	<p></span><span style="font-family:arial;">Just remember - </span><a href="http://www.sjgames.com/pentabarf"><span style="font-family:arial;">Semper Discordia</span></a><span style="font-family:arial;">!
</span></p><p><span style="font-family:arial;">Took the </span><a href="http://www.theadvocates.org/quiz.html"><span style="font-family:arial;">Worlds Smallest Political Quiz</span></a><span style="font-family:arial;">
</span></p><p><span style="font-family:arial;">The <b><span style="COLOR: rgb(255,0,0)">red dot</span></b> on the Chart shows where I fit on the political map.</span></p><p><span style="font-family:arial;"><img height="352" src="http://www.theadvocates.org/quiz/draw.php?p=10&amp;e=10" width="351" usemap="#quizmap" border="0" /> <map name="quizmap"><area shape="POLY" coords="175,0,263,88,223,127,127,127,88,88" href="http://www.theadvocates.org/quiz/quiz.php#libertarian"></area><area shape="POLY" coords="0,175,88,88,127,127,127,223,88,263" href="http://www.theadvocates.org/quiz/quiz.php#liberal"></area><area shape="POLY" coords="350,175,263,263,223,223,223,127,263,88" href="http://www.theadvocates.org/quiz/quiz.php#conservative"></area><area shape="POLY" coords="175,350,263,263,223,223,127,223,88,263" href="http://www.theadvocates.org/quiz/quiz.php#authoritarian"></area><area shape="RECT" coords="127,127,223,223" href="http://www.theadvocates.org/quiz/quiz.php#centrist"></area></map></p>


	<p></span></p><p><span style="font-family:arial;">Just found </span><a href="http://www.votingcatholic.org/quiz_1.php?session_id=1322300527"><span style="font-family:arial;">this political test</span></a><span style="font-family:arial;">.. It scored me vs the Catholic Bishops, Bush and Kerry. The higher percentage equates to more agreement on this issue.</p>


	<p>Here is my score:</p>


	<p>Overall
Bishops -18%
Bush 9%
Kerry -27%</p>


	<p>Protecting Human Life
Bishops -25%
Bush -25%
Kerry 50%</p>


	<p>Promoting Family Life
Bishops -100%
Bush -100%
Kerry -100%</p>


	<p>Pursuing Social Justice
Bishops 0%
Bush 45%
Kerry -70%</p>


	<p>Pursuing Global Solidarity
Bishops 0%
Bush 100%
Kerry -50%</p>


Wow. Some of those questions and category's are really... um... biased. But what did I expect? Everyone has their axe to grind. </span></p><p><span style="font-family:arial;">-Tsyko</span></p><p>
</p>