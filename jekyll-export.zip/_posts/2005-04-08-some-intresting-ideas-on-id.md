---
id: 231
title: Some intresting ideas on ID
date: 2005-04-08T13:45:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/some-intresting-ideas-on-id
permalink: /2005/04/08/some-intresting-ideas-on-id/
categories:
  - Science!
---
<p><a href="http://hereticalideas.com/index.php?p=2773">Heretical Ideas Â» <span class="caps">NOT</span>-SO-INTELLIGENT <span class="caps">DESIGN</span></a></p>


<blockquote>
But you'd think one thing that opponents of ID (like myself) should invoke more often are the examples of downright shoddy design put forth by the creator of the universe. The design of the human testicles, for instance. Here we have one of the primary reproductive organs located in a sac outside of the body and very, very vulnerable to damage. Why? Because human sperm can't be produced at normal human body temperature! That doesn't seem like intelligent design to me.</blockquote>