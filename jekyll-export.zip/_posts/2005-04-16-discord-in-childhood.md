---
id: 280
title: Discord in Childhood
date: 2005-04-16T22:50:18+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/discord-in-childhood
permalink: /2005/04/16/discord-in-childhood/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://www.bartleby.com/127/4.html">Discord in Childhood</a>, <a href="http://www.online-literature.com/dh_lawrence/">D.H. Lawrence</a></p>


	<center><em><span class="caps">OUTSIDE</span> the house an ash-tree hung its terrible whips,
	And at night when the wind arose, the lash of the tree
	Shrieked and slashed the wind, as a ship's
	Weird rigging in a storm shrieks hideously.
	<br />Within the house two voices arose in anger, a slender lash
	Whistling delirious rage, and the dreadful sound
	Of a thick lash booming and bruising, until it drowned
	The other voice in a silence of blood, 'neath the noise of the ash.</em></center><br />