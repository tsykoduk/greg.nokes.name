---
id: 626
title: Fur vs Leather
date: 2005-07-06T22:19:06+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/fur-vs-leather
permalink: /2005/07/06/fur-vs-leather/
categories:
  - Fun!
---
<blockquote>"People are more violently opposed to fur than leather because it's safer to harass rich women than motorcycle gangs."-John Varley</blockquote>

		<p>Hat Tip <a href="http://hereticalideas.com/wordpress/wp-trackback.php/3065">Heretical Ideas</a></p>