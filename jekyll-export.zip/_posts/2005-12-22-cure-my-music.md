---
id: 1185
title: Cure my Music
date: 2005-12-22T22:12:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cure-my-music
permalink: /2005/12/22/cure-my-music/
categories:
  - Fun!
---
<table width=350 align=center border=0 cellspacing=0 cellpadding=2><tr><td>
<font face="Georgia, Times New Roman, Times, serif" style='color:black; font-size: 14pt;'>
<strong>The Cure Shares Your Taste in Music</strong>
</font></td></tr>
<tr><td>
<center><img src="http://images.blogthings.com/whichmusiciansharesyourtasteinmusicquiz/the-cure.jpg" height="100" width="100"/>
<font color="#000000">
<a href="http://click.linksynergy.com/fs-bin/click?id=CkIfgYlVpZA&#38;offerid=78941.462765450&#38;type=10&#38;subid="><br />
See their whole playlist here (iTunes required)<br />
</a>
</font></center></td></tr></table>
<div align="center"><a href="http://www.blogthings.com/whichmusiciansharesyourtasteinmusicquiz/">Which Musician (or Group) Shares Your Taste in Music?</a></div>

	<p>And, I actually like the Cure! :)</p>