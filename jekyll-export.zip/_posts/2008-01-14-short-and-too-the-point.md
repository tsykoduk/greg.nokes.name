---
id: 3097
title: Short, and too the point
date: 2008-01-14T04:13:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/short-and-too-the-point
permalink: /2008/01/14/short-and-too-the-point/
categories:
  - Philosophy! and Politics!
---
<blockquote>Government big enough to supply everything you need is big enough to take everything you have ... The course of history shows that as a government grows, liberty decreases.</blockquote>

-Thomas Jefferson