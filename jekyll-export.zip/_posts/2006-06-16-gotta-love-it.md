---
id: 1424
title: Gotta Love It!
date: 2006-06-16T13:03:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/gotta-love-it
permalink: /2006/06/16/gotta-love-it/
categories:
  - Computers! and Code!
---
<p>Working on some <a href="http://en.wikipedia.org/wiki/Skunkworks">skunkworks</a> stuff right now. This is just a test of said skunkworks stuff...</p>