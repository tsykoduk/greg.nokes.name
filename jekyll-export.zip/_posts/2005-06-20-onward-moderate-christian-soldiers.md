---
id: 556
title: Onward, Moderate Christian Soldiers
date: 2005-06-20T13:55:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/onward-moderate-christian-soldiers
permalink: /2005/06/20/onward-moderate-christian-soldiers/
categories:
  - Philosophy! and Politics!
---
<blockquote>In the decade since I left the Senate, American politics has been characterized by two phenomena: the increased activism of the Christian right, especially in the Republican Party, and the collapse of bipartisan collegiality. I do not think it is a stretch to suggest a relationship between the two. To assert that I am on God's side and you are not, that I know God's will and you do not, and that I will use the power of government to advance my understanding of God's kingdom is certain to produce hostility.</blockquote>

		<p><a href="http://www.google.com/search?q=JOHN+C.+DANFORTH">
	John C. Danforth</a> has a lot to say about the current crop of right wing Christians in this N.Y. Times <a href="http://www.nytimes.com/2005/06/17/opinion/17danforth.html?ex=1119844800&#38;en=ff5dd6ef0c0d9b2a&#38;ei=5070&#38;emc=eta1">article</a>. It's a very good read, and should be taken to heart. If more Christians followed Mr. Danforth's beliefs, I feel that Christianity would not be at the crossroads that it is today.</p>


		<p>Conversely, if the political parties took his advice to heart, I do not think that the country would be in the state that it is today. We, as a people, are far to divided. We engender hatred over politics. I am sorry, but Hatred over politics is just plain silly. The differences between Bush's and Kerry's platforms were trivial. It all came down to character - not actions and path. We are in a country where every election is poised to become a court battle 'because we did not win!' And we are trying to bring the rest of the world into Democracy. Perhaps we should lead with our actions, instead of just words.</p>