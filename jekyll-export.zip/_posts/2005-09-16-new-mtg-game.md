---
id: 885
title: New MTG game!
date: 2005-09-16T23:15:16+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-mtg-game
permalink: /2005/09/16/new-mtg-game/
categories:
  - Fun!
---
<p>This is just wrong.</p>


	<p>You were warned!</p>


	<p><a href="http://www.brokentoys.org/?p=6849">Enter at your own risk</a></p>