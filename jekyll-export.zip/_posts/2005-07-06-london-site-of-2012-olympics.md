---
id: 624
title: London site of 2012 Olympics
date: 2005-07-06T07:24:27+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/london-site-of-2012-olympics
permalink: /2005/07/06/london-site-of-2012-olympics/
categories:
  - Mundane
---
<p>London has been choosen as the site for the 2012 Olympic Games, according to <a href="http://news.google.com/news?ncl=http://news.scotsman.com/latest.cfm%3Fid%3D749722005&#38;hl=en">various news outlets</a>. Congrats London!</p>