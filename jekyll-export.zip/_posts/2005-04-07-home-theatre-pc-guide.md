---
id: 212
title: Home Theatre PC Guide
date: 2005-04-07T12:34:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/home-theatre-pc-guide
permalink: /2005/04/07/home-theatre-pc-guide/
categories:
  - Computers! and Code!
---
<p>There is a good <a href="http://www.2cpu.com/articles/113_1.html">Home Theatre PC Guide</a> out there. What they talk about is how to build a Home Theater PC - more then  just a <a href="http://www.tivo.com">TiVO</a>. You will be able to record TV to a digital format, display photos, play your Sound Files. It is a one stop shop.</p>


	<p>I think that I am going to build one some day. I have a few old PC's that need a home :)</p>