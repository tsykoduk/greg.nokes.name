---
id: 169
title: LAMP made Easy
date: 2005-03-09T09:24:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/lamp-made-easy
permalink: /2005/03/09/lamp-made-easy/
categories:
  - Computers! and Code!
---
<p>Just stumbled across <a href=http://www.apachefriends.org/en/xampp.html>this</a> little chunk of software. Looks really easy.<br /><br />Now, truth be known, getting Apache, MySQL and <span class="caps">PHP</span> running on a modern Linux distro is dead simple. However, on a Windows box - well that's another story. <a href=http://www.apachefriends.org/en/xampp.html>Xammp</a> makes that easy. So, as part of the first step towards breaking your dependance on the Windows Drug - go, get it, and play...<br /><br /><br />-Tsyko</p>