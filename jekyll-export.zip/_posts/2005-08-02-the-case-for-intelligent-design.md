---
id: 704
title: The case for intelligent design
date: 2005-08-02T15:12:24+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-case-for-intelligent-design
permalink: /2005/08/02/the-case-for-intelligent-design/
categories:
  - Philosophy! and Politics!
---
<blockquote>The case for intelligent design

		<p>What is Intelligent Design? Many scientists <del>- well, nearly all scientists -</del> seem surprised that the President of the United States thinks Intelligent Design should be taught in schools. (See today's news reports about that by Fox News and others.) Most likely, the President is referring to the persuasive 1998 report prepared by J.J. Rivera of Sandia National Laboratories:</p>


		<pre><code>Design engineers are becoming few in number and years worth of experience is about to be lost. What will happen when new weapons are designed or retrofits need to be made? Who will know the lessons learned in the past? What process will be followed? When and what software codes should be used? Intelligent design is the answer to the questions posed above for weapon design.</code></pre>


		<p>The report is titled "Intelligent design using expertise knowledge, manufacturing data, and legacy codes." Its final section, labeled "CONCLUSIONS," says:</p>


		<pre><code>The intelligent designer is still being developed.</blockquote></code></pre>


		<p>- <a href="http://improbable.typepad.com/improbable_research_whats/2005/08/the_case_for_in.html">Improbable Research</a></p>


		<p>Wow... that conclusion says it all.</p>