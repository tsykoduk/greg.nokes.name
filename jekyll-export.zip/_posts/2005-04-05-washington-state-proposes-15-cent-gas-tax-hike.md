---
id: 198
title: Washington State proposes 15-cent gas tax hike
date: 2005-04-05T15:15:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/washington-state-proposes-15-cent-gas-tax-hike
permalink: /2005/04/05/washington-state-proposes-15-cent-gas-tax-hike/
categories:
  - Philosophy! and Politics!
---
Seattle Times: Local News:<a href="http://seattletimes.nwsource.com/html/localnews/2002230443_webtaxhike04.html">The  Senators propose multiyear, 15-cent gas tax hike</a>
<blockquote><span class="caps">OLYMPIA: </span> Senate transportation leaders today proposed a 15 cent per gallon increase in the state gasoline tax, to be slowly phased in over the next 12 years.</blockquote>
Um.. Wow – we already pay $.28 a gallon in taxes on fuel, and now they want to tack on another $.15? Thats $.43 a gallon in taxes alone.

More then likely, the answer is not new and higher taxes, but rather a re-allocation of existing funds.

<a href="http://dor.wa.gov/Docs/Pubs/ExciseTax/FilTaxReturn/MajorTaxes.htm">Washington State took in $752,000,000</a> in Fuel Tax in ‘03. Assuming that everything stays the same, they want us to pay out $1,150,000,000 in fuel taxes!
<blockquote>The plan also includes a gross-weight fee on cars, sports utility vehicles and small trucks, as well as local-option tax increases for cities and counties.</blockquote>
So our tabs are on the way up as well. What happened to the Flat Tabs?

This is just getting silly. Higher and more complex taxes do not engender a stronger economy – they weaken it. We need to take the message to Olympia – No More Taxes! Spend the billions that you take in as if it were your paycheck! No more stupid spending.