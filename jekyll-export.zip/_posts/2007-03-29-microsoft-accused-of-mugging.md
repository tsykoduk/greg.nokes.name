---
id: 2250
title: Microsoft Accused of Mugging
date: 2007-03-29T21:06:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/microsoft-accused-of-mugging
permalink: /2007/03/29/microsoft-accused-of-mugging/
categories:
  - Computers! and Code!
---
<blockquote>Except that I'm left with the uneasy feeling that I've been ever-so-elegantly mugged. Presumably there's no connection between your recent sales downgrade and what you might call the negative goodwill generated for customers like me.</blockquote>

	<p>-<a href="http://www.bbc.co.uk/blogs/thereporters/robertpeston/2007/03/dear_bill_gates_again.html">Robert Peston</a> in an article about Vista.</p>


	<p>Good read. I used to be of the mind that high security meant a lack of usability, however, that is not always the case. In any matter, the reverse it certainly not true. Vista seems to be a big 'FU' from Microsoft to the users who complained about the lack of security.</p>