---
id: 425
title: Tried and true is better
date: 2005-05-17T16:10:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/tried-and-true-is-better
permalink: /2005/05/17/tried-and-true-is-better/
categories:
  - Science!
---
<blockquote>A software problem is causing some Toyota Prius gas-electric hybrid cars to stall or shut down while driving at highway speeds, according to a published report.</blockquote>

		<p>Reports <a href="http://money.cnn.com/2005/05/16/Autos/prius_computer/index.htm?cnn=yes"><span class="caps">CNN</span></a>.</p>


		<p>You know, the more that I hear about these hybrids, the more I think that I like my diesel. It just plain works.</p>