---
id: 1467
title: 'Star Chambers &#8211; Out!'
date: 2006-09-21T16:41:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/star-chambers-out
permalink: /2006/09/21/star-chambers-out/
categories:
  - Philosophy! and Politics!
---
<p>I abhor any use of torture to gain information. By stooping to these base tactics, we are no better then those who we fight. America is supposedly a beacon of freedom in this dark world. Are we to become simply another thinly veiled totalitarian regime?</p>


	<p>We are at a turning point in our history as a nation and as a world. Do we want to be friends with the world, or at war with the world. If we do aspire to rule the world, is it through military might or inclusive partnerships?</p>


	<p>I cannot stress enough how strongly I am against us modifying the Geneva Convention for this 'war on terror'. Terror is not an army which we can meet on the battlefield and vanquish. It's a group of thuggish criminals who operate outside of the rules to gain an upper hand.</p>


	<p>Treat them like the criminals they are, arrest them, jail them, but treat them fairly. As you would want to be treated were the circumstances reversed.</p>


	<p>I urge you to <a href="http://action.downsizedc.org/wyc.php?cid=56">send a letter</a> to your congresscritter in regards to this issue.</p>