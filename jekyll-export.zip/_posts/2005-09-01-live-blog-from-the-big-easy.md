---
id: 838
title: Live blog from the Big Easy
date: 2005-09-01T22:47:13+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/live-blog-from-the-big-easy
permalink: /2005/09/01/live-blog-from-the-big-easy/
categories:
  - Mundane
---
<p>Nothing to say - just check out the real scoop from some one on the <a href="http://mgno.com/">ground</a>.</p>