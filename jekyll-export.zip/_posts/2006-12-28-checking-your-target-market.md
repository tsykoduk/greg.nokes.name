---
id: 1858
title: Checking your target market
date: 2006-12-28T18:30:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/checking-your-target-market
permalink: /2006/12/28/checking-your-target-market/
categories:
  - Computers! and Code!
  - Fun!
---
<p>Checking your target market seems to be a good idea. Obviously these folks did not...</p>


<center><a href="http://www.flickr.com/photos/tsykoduk/336420281/" title="Photo Sharing"><img src="http://farm1.static.flickr.com/157/336420281_602bd48d5c.jpg" width="500" height="400" alt="Checking your target market..." /></a></center>