---
id: 798
title: Covet his Ass
date: 2005-08-24T18:11:12+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/covet-his-ass
permalink: /2005/08/24/covet-his-ass/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p>Mr. Robertson is on a roll!</p>


	<blockquote>Speaking on the television program he hosts, 'The 700 Club,â€ Mr. Robertson lashed out at the Venezuelan strongman once more, telling his audience, 'It's high time that the United States coveted Hugo Chavez' wife.â€

		<p>Warming to his topic, the opinionated preacher added, 'And while we're at it, we should covet his house, his manservant, his maidservant..and his ass, for that matter.</blockquote></p>


		<p>-<a href="http://www.borowitzreport.com/archive_rpt.asp?rec=1202&#38;srch=">Andy Borowitz</a></p>