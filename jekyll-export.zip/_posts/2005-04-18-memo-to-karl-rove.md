---
id: 281
title: Memo to Karl Rove
date: 2005-04-18T08:13:01+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/memo-to-karl-rove
permalink: /2005/04/18/memo-to-karl-rove/
categories:
  - Philosophy! and Politics!
---
<blockquote>Bob Novak, writing about Terry Schiavo last month, inadvertently summed up the problem with the administration's Social Security reform strategy when he wrote, "This is not the cold, analytical debate over Social Security." Just so. If you're wondering why there's so little grass-roots support to date for the president's plan, it's because the focus has been on green-eyeshade issues such as solvency, transition costs, unfunded liabilities and rates of return. Actuaries to the barricades!</blockquote>

		<p>Read the rest of the article <a href="http://www.cato.org/pub_display.php?pub_id=3738">Here</a>.</p>