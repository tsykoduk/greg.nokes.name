---
id: 2265
title: Important Announcement!
date: 2007-04-02T03:41:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/important-announcement
permalink: /2007/04/02/important-announcement/
categories:
  - Philosophy! and Politics!
---
<p>Working with a core group of my friends, I have decided to put together an exploratory committee to look into forming a campaign for President in 2008. We have had several meetings laying the groundwork for this effort. We are excited to announce that we have already secured several large backers who believe that my presidency would bring solutions to most of the worlds problems.</p>


	<p>Our first full scale meeting is tonight, so expect an exciting announcement tomorrow.</p>