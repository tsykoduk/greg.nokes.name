---
id: 1436
title: 'Oh yeah &#8211; Windows is the place to be'
date: 2006-07-20T10:00:28+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/oh-yeah-windows-is-the-place-to-be
permalink: /2006/07/20/oh-yeah-windows-is-the-place-to-be/
categories:
  - Computers! and Code!
---
<blockquote>Washingtonpost.com's Security Fix blog reports that a banner ad running on MySpace.com and other Web sites used a Windows security flaw to push adware and spyware out to more than one million computer users this week. The attack leveraged the Windows Metafile (WMF) exploit to install programs in the PurityScan/ClickSpring family of adware, which bombards the user with pop-up ads and tracks their Web usage.</blockquote>

	<p>-From the <a href="http://blog.washingtonpost.com/securityfix/2006/07/myspace_ad_served_adware_to_mo.html">Washington Post</a> via <a href="http://it.slashdot.org/article.pl?sid=06/07/20/042253&#38;from=rss">Slashdot</a></p>


	<p>Two lessons here...</p>


<ol>
<li>Update update update!</li>
<li>Don't run Windows!</li>
</ol><ol>

	<p>Just go to defcon/blackhat/hack  in a box/etc... and look around. How many folks are running windows on their laptops?</p>


</ol>