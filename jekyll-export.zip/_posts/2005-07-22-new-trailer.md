---
id: 685
title: New trailer
date: 2005-07-22T12:31:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-trailer
permalink: /2005/07/22/new-trailer/
categories:
  - Fun!
---
<p>The new trailer for Serenity is <a href="http://www.uip.nl/Pictures/seren/trailer2.mov">Here</a>. Getting excited!</p>