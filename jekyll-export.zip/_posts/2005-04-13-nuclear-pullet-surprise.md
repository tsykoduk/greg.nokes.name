---
id: 264
title: Nuclear pullet surprise
date: 2005-04-13T13:33:12+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/nuclear-pullet-surprise
permalink: /2005/04/13/nuclear-pullet-surprise/
categories:
  - Fun!
  - Science!
---
<blockquote>A once secret plan to build a nuclear landmine 'run' by live chickens has gone on public display for the first time at The National Archives, Kew, as part of the acclaimed Secret State Exhibition.</blockquote>

	<p>You can read the rest <a href="http://improbable.typepad.com/improbable_research_whats/2005/04/nuclear_pullet_.html">here</a>, but it boils down to this. They were going to stuff a nuclear landmine full of chickens to insure that the weapon's important parts did not get too cold and freeze up during the winter.</p>


	<p>Leave it to the human race to come up with an idea this unique.</p>


	<p>I don't know if I am amazed by our resourcefullness or sickened.</p>