---
id: 204
title: I Murder Hate
date: 2005-04-06T11:29:55+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/i-murder-hate
permalink: /2005/04/06/i-murder-hate/
categories:
  - Philosophy! and Politics!
---
<center>Robert Burns (1759,1796), <a href="http://www.bartleby.com/6/304.html">I Murder Hate</a><br /><br />

	<p><span class="caps">I MURDER</span> hate by flood or field,
Tho' glory's name may screen us;
In wars at home I'll spend my bloodâ€”
Life-giving wars of Venus.
The deities that I adore
Are social Peace and Plenty;
I'm better pleas'd to make one more,
Than be the death of twenty.</center></p>