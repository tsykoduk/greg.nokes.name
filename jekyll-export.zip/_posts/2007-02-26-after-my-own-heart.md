---
id: 2209
title: After my own heart
date: 2007-02-26T19:43:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/after-my-own-heart
permalink: /2007/02/26/after-my-own-heart/
categories:
  - Computers! and Code!
  - Fun!
---
<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/zsqi2QHXaFI"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/zsqi2QHXaFI" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>