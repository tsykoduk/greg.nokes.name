---
id: 240
title: What is this world coming to?
date: 2005-04-10T23:15:52+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/what-is-this-world-coming-to
permalink: /2005/04/10/what-is-this-world-coming-to/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://worldnetdaily.com/news/article.asp?ARTICLE_ID=43685">WorldNetDaily: Man arrested, cuffed after using $2 bills</a></p>


<blockquote>A man trying to pay a fee using $2 bills was arrested, handcuffed and taken to jail after clerks at a Best Buy store questioned the currency's legitimacy and called police.

	<p>According to an account in the Baltimore Sun, 57-year-old Mike Bolesta was shocked to find himself taken to the Baltimore County lockup in Cockeysville, Md., where he was handcuffed to a pole for three hours while the U.S. Secret Service was called to weigh in on the case.</blockquote></p>


	<p>Wow.</p>


	<p>Now, I do not fault the Best Buy employees as much as the police in this matter. After all, it seems that the average retail employee today is decidely wet behind the ears.</p>


	<p>I used to go about asking if places honored Federal Reserve Notes. I usally was told no, or got blank looks. <em>Note: Federal Reserve Notes are any legal US Cash.</em></p>


My favorite quote:
<blockquote>Commenting on the incident, Baltimore County police spokesman Bill Toohey told the Sun: "It's a sign that we're all a little nervous in the post-9/11 world."</blockquote>

	<p>From <a href="http://www.baltimoresun.com/news/local/bal-md.olesker08mar08,1,76004.column?ctrack=1&#38;cset=true">Michael Olesker</a> at the <a href="http://www.baltimoresun.com/">Baltmore Sun</a></p>


	<p>Um. Yeah. Talking about blowing it way out of proportion. Let's use the terrorism card to cover up our mistakes. Some guy paying with $2 bills is going to be the next World Trade pilot. Yeah.</p>


	<p>People. Calm down a notch. Check out the situation before making a choice.</p>


	<p>"Remember, though, your best weapon is between your ears and under your scalp - provided it's loaded."</p>


	<p>B. P. Matson
<a href="http://www.amazon.com/exec/obidos/ASIN/0345353730/survivalarts-20/102-7878343-2935344">Tunnel in the Sky</a>, by Robert Heinlein</p>


	<p>-Tsyko</p>