---
id: 87
title: Out of town
date: 2005-02-17T18:36:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/out-of-town
permalink: /2005/02/17/out-of-town/
categories:
  - Mundane
---
<p>I will be out of town for the next few days. If the hotel does not have wireless internet access, do not expect to see me posting until monday. I know, all of my regular readers will just have to get along with out my sage writings.<br /><br />Oh will the world survive?<br /><br /><br />heh.<br /><br />Well, here are a few <a href=http://www.weebls-stuff.com/toons/37/>links <a href=http://www.weebls-stuff.com/toons/29/>to <a href=http://www.handbasket.info/index.php?name=Web_Links&#38;l_op=visit&#38;lid=108>keep</a> <a href=http://www.handbasket.info/index.php?name=Web_Links&#38;l_op=visit&#38;lid=102>ya'll</a> <a href=http://www.kontraband.com/show/show.asp?ID=1830>going</a>...</p>