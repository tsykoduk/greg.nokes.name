---
id: 1172
title: 'A Child&#039;s Mind'
date: 2005-12-12T21:20:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-child-s-mind
permalink: /2005/12/12/a-child-s-mind/
categories:
  - Philosophy! and Politics!
---
<blockquote> A successful businessman went to a Zen master and announced he had come to learn all about Zen.  The master invited the man to sit down and have tea.  As the master poured the tea, it overflowed.  The businessman shouted, "It's spilling, it's spilling!"  To which the master replied, "Precisely-you came with a full cup.  Your cup is already spilling over, so how can I give you anything?  Unless you come with emptiness, I can give you nothing."

    Your journey . . . begines when you empty your mind of all the overused and undernourishing ideas you have inherited . . . Using your Beginner's Mind, you will see things in a refreshing, exhilirating way . . . Open yourself up to your unlimited potential . . . This is your initiation into the eloquence of the thinking body and the grace of the dancing mind.

    <em>Huang, Chungliang and Jerry Lynch.  Thinking Body, Dancing Mind:  TaoSports for extraordinary performance in athletics, business, and life.  Bantam, 1992, p. 29</em>.  </blockquote>

	<p>-<a href="http://www.beginners-mind.net/what_is.htm">What is the beginner's mind?</a></p>


	<p>I have made a career out of learning. No, not a career, a life. One of the things that I have found most important in this life of learning is to throw away preconceived notions. Approaching problems with an open mind is crucial. If you have some idea in your head about what is causing an issue, you can poison your mind to other options. Only with an open mind can you really see.</p>


	<p>Seeing is important.</p>