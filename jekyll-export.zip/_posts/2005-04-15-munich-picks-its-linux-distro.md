---
id: 272
title: Munich picks its Linux distro
date: 2005-04-15T22:55:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/munich-picks-its-linux-distro
permalink: /2005/04/15/munich-picks-its-linux-distro/
categories:
  - Computers! and Code!
---
<blockquote>Debian has got the nod from the city of Munich for its trail-blazing migration from Windows to Linux on the desktop

		<p>The City of Munich has chosen to migrate its 14,000 desktops to a free Linux distribution, rather than a commercial version of the open source operating system.</p>


		<p>The City's administration said on Thursday that it will use the Debian distribution, which will be customised to meet the needs of the city administration.</blockquote></p>


		<p><a href="http://news.zdnet.co.uk/software/linuxunix/0,39020390,39195204,00.htm">Munich picks its Linux distro - ZDNet UK News</a></p>


		<p>One of the things that I most like about <a href="http://www.debian.org/">Debian</a> and <a href="http://www.ubuntulinux.org/">Ubuntu</a> is my ablity to completly customize it. Nothing is hidden behind the smoke and mirrors of Redmond. I can, and have, change the <a href="http://www.gnome-look.org">complete look and feel</a> of the computer to <a href="http://www.kde-look.org">suit my personal tastes</a>.</p>


		<p>In a corprate enviroment, I think this kind of power would be greatly appreacated. For example, you can change out a few files, and have the boot up splash screen display your corprate logo, or legal warning banner - or what ever you want.</p>


		<p>Microsoft is starting to wake up, however. Their patch management has made huge strides over the last few years - and they are actually starting to consiter security as an important feature.</p>


	<blockquote>The City of Munich is not the only government organisation to chose Debian. The German Foreign Office and the Office for IT Security, as well as the City of Vienna, have also opted for the free Linux distribution</blockquote>

		<p><a href="http://www.debian.org/">Debian</a> has a rock solid track record - in fact I think just about the only group with a better one is <a href="http://www.openbsd.org/">OpenBSD.</a> It seems that folks over in Germany are starting to see that, and see that free does not equal poor quality. All in all a big win for <a href="http://www.debian.org/">Debian!</a></p>