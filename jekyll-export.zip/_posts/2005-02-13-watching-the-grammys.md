---
id: 98
title: Watching the Grammys
date: 2005-02-13T21:15:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/watching-the-grammys
permalink: /2005/02/13/watching-the-grammys/
categories:
  - Mundane
---
<p>And not really caring. Most of the pre-digested pabulum that they play is just crap. I really dislike where modern Pop music has gone. Record execs in silver towers make choices based on what will make <b>them</b> the most money, rather then what is good music.<br /><br />Television it's self is mostly crap now days. Shela likes to watch a lot of TV. Well, a lot in my mind. When we met I did have a TV. But it was only hooked up to my Playstation and <span class="caps">DVD</span> player. Not even bunny ears. I had no need for TV. I used the heck out of <a href=http://www.netflix.com>Netflix</a>. I had to increase my subscription to 8 movies at home because I would blow through 4 or 5 movies in a weekend, and I liked to have one or two for the week.<br /><br />I also did a lot of computing - errr - playing on the computers at home then as well. Now I am relegated to the laptop on a lazy boy, trying to ignore the TV. <br /><br />Oh - god - Ricky Martin. I think that I am going to be sick. In Spanish. :)<br /><br />This Ricky Martin/J-Lo thing reminds me of a movie - Four Rooms. Especially the part with Antonio Banderas. Cool stuff.</p>