---
id: 7148
title: Seen on Evil.com
date: 2008-04-11T19:57:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/seen-on-evil-com
permalink: /2008/04/11/seen-on-evil-com/
categories:
  - Fun!
---
<blockquote>We did like this one...
<br /><br />
Seen in mail header:  Free Tibet with purchase of China.
</blockquote>

	<p>-<a href="http://www.evil.com/archives/2008/200804/20080409.htm">Evil.com</a> - They Get It... Daily</p>