---
id: 560
title: What planet am I from??
date: 2005-06-20T14:06:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/what-planet-am-i-from
permalink: /2005/06/20/what-planet-am-i-from/
categories:
  - Fun!
---
<center><table width=400 align=center border=1 bordercolor=black cellspacing=0 cellpadding=2>
	<tr><td bgcolor=#66CCFF align=center>
	<font face="Georgia, Times New Roman, Times, serif" style='color:black; font-size: 14pt;'>
	<b>You Are From Saturn</b></font></td></tr>
	<tr><td align=center bgcolor=#FFFFFF>
	<img src="http://www.quizdiva.net/bt/saturn.jpg"/><br />
	<font color="#000000">You're steady, organizes, and determined to achieve your dreams.
	You tend to play it conservative, going by the rules (at least the practical ones).
	You'll likely reach the top. And when you do, you'll be honorable and responsible.
	Focus on happiness. Don't let your goals distract you from fun!
	Don't be too set in your ways, and you'll be more of a success than you ever dreamed of.</font>
	</td></tr></table>
	<div align="center">
	<a href="http://www.blogthings.com/planetquiz.html">What Planet Are You From?</a>
	</div></center>

		<p>(Hat Tip, <a href="http://davejustus.blogspot.com/">Justus</a>)</p>