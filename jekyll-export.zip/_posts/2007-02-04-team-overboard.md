---
id: 2145
title: Team Overboard
date: 2007-02-04T07:20:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/team-overboard
permalink: /2007/02/04/team-overboard/
categories:
  - Philosophy! and Politics!
---
<blockquote>Enjoy the Superbowl this weekend, but just make sure you don't do it with strangers on a display larger than 55 inches.  If you do, you will be violating the <span class="caps">NFL</span>'s copyrights to the game.  Mass out-of-home viewings at a place where sports viewing is not ordinary business practice goes against the <span class="caps">NFL</span>'s copyrights.

	<p>Also, inviting strangers or charging admission (i.e. you're buying the keg) is against the law.</blockquote></p>


	<p>-<a href="http://blog.wired.com/music/2007/02/your_superbowl_.html">Wired</a></p>


	<p>Sad, really.</p>