---
id: 15319
title: NoGUI VMWare Fusion
date: 2010-08-08T14:22:42+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15319
permalink: /2010/08/08/nogui-vmware-fusion/
categories:
  - Computers! and Code!
---
<p>One of the things that I like to do it launch my VM's with out a GUI - it takes a little less resources, and it does not clutter up my Mac's desktop with windows that I do not need. It's been hard to do in the past.</p>
<p>Enter <a href="http://github.com/tsykoduk/VMWare-Fusion-Launcher">VMWare Fusion Launcher</a>. Currently it's tested under Ruby 1.9.2dev, so YMMV.</p>
