---
id: 99
title: copyrighteous
date: 2005-02-12T22:00:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/copyrighteous
permalink: /2005/02/12/copyrighteous/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://mako.yukidoke.org/copyrighteous/ip/20050210-00.html">Mako</a> Says<br /><blockquote><i>"A couple of weeks ago, I went to a extremely interesting talk by Niva Elkin-Koren on the limits of private ordering (i.e., contracts and licenses) in building communities around the production of free (for definition of free) creative works. She's writing a paper which I hope to get my hands on very soon. I have every reason to believe it will be excellent."</i></blockquote><br /><br />You need to read the rest of this and the all of the links...<br /><br />Go!<br /><br />Now!</p>