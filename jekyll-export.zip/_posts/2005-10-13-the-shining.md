---
id: 974
title: The Shining
date: 2005-10-13T18:28:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-shining
permalink: /2005/10/13/the-shining/
categories:
  - Fun!
---
<p>is coming out again - check out the <a href="http://www.angryalien.com/0504/shiningbunnies.html">trailer</a>!</p>


	<p><em><strong>edit</strong>: Yes - two new versions of The Shining. <a href="http://browncoats.serenitymovie.com/serenity/">Shiny</a>!</em></p>