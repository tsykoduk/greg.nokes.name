---
id: 1556
title: Enlightenist Manifesto
date: 2006-11-01T13:53:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/enlightenist-manifesto
permalink: /2006/11/01/enlightenist-manifesto/
categories:
  - Philosophy! and Politics!
---
<blockquote>Enlightenists believe in the awe-inspiring, wonder, beauty and complexity of the universe, and aspire to unpick its mysteries by reason, constant questioning, observation, experiment, and analysis of evidence. The bedrock of our morality is empathy, from which logically springs love, forgiveness, tolerance and a profound desire to make a just, egalitarian society and reduce suffering. The more knowledge a person has, the more they question and understand the real world, and the more they are required to analyse what is true then the greater the increase in empathy. Enlightenists care and wish to do good not because a vengeful God tells them to, but because intelligence suggests it is the only and the right thing to do.</blockquote>

	<p>-<a href="http://www.sundayherald.com/58809">Muriel Gray</a></p>