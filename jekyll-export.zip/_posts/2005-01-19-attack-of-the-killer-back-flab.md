---
id: 50
title: Attack of the Killer Back Flab!
date: 2005-01-19T09:00:22+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/attack-of-the-killer-back-flab
permalink: /2005/01/19/attack-of-the-killer-back-flab/
categories:
  - Fun!
---
<p>I was driving around the blog-o-sphere last nite, and I came across a mention of <a href=http://www.google.com/search?q=back+flab&#38;start=0&#38;start=0&#38;ie=utf-8&#38;oe=utf-8&#38;client=firefox&#38;rls=org.mozilla:en-US:unofficial>Back Flab</a> at <a href=http://poorrolemodel.blogspot.com/2005/01/beauty-tips-vs-ugly-tips.htm>PoorRoleModel</a>. Now this got me thinking. And jiggling. <br /><br />Do I have back flab? <br /><br />How can I tell? I do not often actually <b>look</b> at my back. So, sitting in the <a href=http://www.ai.mit.edu/people/paulfitz/spanish/index.html>Comfy Chair</a> I started to jiggle my back. To see if it would, infact, jiggle.<br /><br />Sadly, no jiggling.<br /><br />Well, no jiggling on my back.<br /><br />I guess I will have to work harder if I want to get some back flab of my own. Or perhaps I could just go out and buy some?<br /><br />I think that I should research companys that sell back flab. When this gets out, there is going to be a run on this stuff, and their stock could do better then a <a href=http://www.zoology.ubc.ca/~bwilson/herring.html>dry herring</a> at a <a href=http://www.everythingferret.com/gastrointestinal_disorders_in_ferrets.htm>ferret eating</a> contest.<br /><br /><br /><br /></p>