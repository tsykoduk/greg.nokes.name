---
id: 985
title: 'Apple&#039;s newest announcement'
date: 2005-10-23T22:59:09+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/apple-s-newest-announcement
permalink: /2005/10/23/apple-s-newest-announcement/
categories:
  - Computers! and Code!
---
<blockquote>An invitation sent out to the press by Apple displays the words, 'We Got Nothin'â€ on top of a picture of a shrugging Steve Jobs. The pockets on Jobs' trademark blue jeans are turned inside out, apparently signifying that hardware updates or new <span class="caps">OS X</span> applications are not on tap for next week.</blockquote>

	<p>Read the rest at <a href="http://www.macworld.com/weblogs/editors/2005/10/noevent/index.php?lsrc=rsswidget">MacWorld</a>. Apple is certainly racking up the announcements over the last few weeks, and this one is a doozy as well.</p>