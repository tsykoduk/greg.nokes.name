---
id: 268
title: Sometimes
date: 2005-04-14T18:08:08+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/sometimes
permalink: /2005/04/14/sometimes/
categories:
  - Computers! and Code!
---
<p>Sometimes, I really hate computers.</p>