---
id: 15495
title: You Have Another Version of Skype Running
date: 2013-07-12T11:34:49+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15495
permalink: /2013/07/12/you-have-another-version-of-skype-running/
categories:
  - Computers! and Code!
---
I really hate this error. Skype is so unstable for me that I get little slowdowns and lock ups weekly, And about once a month I get this error after I've force killed it. I used to have to google it every time, drop to a command line and do a bunch of stuff. Well no more. Now there is a script to clean up after Skype's mess! Skype - you can barrow this if you want. Just have it run when Skype is launching. 

<!--more-->
<script src="https://gist.github.com/tsykoduk/5986191.js"></script>