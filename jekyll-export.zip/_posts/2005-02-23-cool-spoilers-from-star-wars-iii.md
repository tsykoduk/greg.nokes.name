---
id: 79
title: Cool spoilers from Star Wars III
date: 2005-02-23T21:08:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cool-spoilers-from-star-wars-iii
permalink: /2005/02/23/cool-spoilers-from-star-wars-iii/
categories:
  - Fun!
---
<p><a href=http://www.tpu.fi/~t4jlaaks/ep3/>Here. They are spoilers, so be warned.</p>