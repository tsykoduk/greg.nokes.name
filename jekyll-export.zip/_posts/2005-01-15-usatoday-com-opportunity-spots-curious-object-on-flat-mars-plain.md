---
id: 52
title: 'USATODAY.com &#8211; Opportunity spots curious object on flat Mars plain'
date: 2005-01-15T22:25:51+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/usatoday-com-opportunity-spots-curious-object-on-flat-mars-plain
permalink: /2005/01/15/usatoday-com-opportunity-spots-curious-object-on-flat-mars-plain/
categories:
  - Science!
---
<p><i><a href="http://www.usatoday.com/tech/science/space/2005-01-14-oppty-object_x.htm?csp=34"><span class="caps">USATODAY</span>.com - Opportunity spots curious object on flat Mars plain</a> - <span class="caps">NASA</span>'s Opportunity Mars rover has come across an interesting object â€” perhaps a meteorite sitting out in the open at Meridiani Planum. Initial data taken by the robot's Mini-Thermal Emission Spectrometer (Mini-TES) is suggestive that the odd-looking "rock" is made of metal.</i><br /><br />It's just amazing that this probe is still doing good science like this. A fantasic investment for the world made by the <span class="caps">USA</span>.<br /><br />It's incredible - in the same week we land a probe on Titan - one of the more likely objects to have an 'interesting' surface, and a really old probe finds a 'strange' thing just lying about on Mars.<br /><br />There should be some really intresting news coming out of <span class="caps">NASA</span> over the next few months.</p>