---
id: 265
title: The road ahead
date: 2005-04-13T13:55:09+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-road-ahead
permalink: /2005/04/13/the-road-ahead/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://davejustus.blogspot.com/2005/04/calm-before-storm.html">Dave</a> sez:</p>


<blockquote>In short, the more the Jihadists lose in Iraq, the more likely they are to use their rump forces to try something really crazy in America to make up for it. So let's stay the course in Iraq, but stay extra-vigilant at home.Certainly something worth thinking about. There is endless speculation into the mindset and motivations of Al-Qaida types. Some of what they do seems to make sense, other things seem to be extremely bizarre</blockquote>

	<p>I think that this almost goes with out saying. As a caged or cornered animal, I expect them to fight harder. I expect attempts at acts larger then the World Trade.</p>


	<p>The best way to keep this from happening is to keep them off balance as well as tightening security at home. If they are denied a base of operations, training areas, and the other infrastructure that it takes to run an organization that large, they will be pretty ineffective.</p>


	<p>I think that is what Bush is betting on. Keep hitting them hard - with conventional as well as unconventional forces, keep them running, and they will not have the time or energy to mount an effective attack.</p>


	<p>Long term, I do not think this will be an effective tactic. I feel that we need to start to look at the situation in a more strategic light. We need to identify the why of the matter. Why are these people so angry at us? It's not enough to say that it's just crazy people, or it's their religion - that is patently not true. There are underlying reasons - some caused by our foreign policy over the last 50 years, some caused by where these people live.</p>


	<p>To really end terrorism as it exists today, we need to fix the underlying problems. That is a very long term effort, and it's going to be a hard row to hoe. It will take a lot of introspection on our part, and apologizing for our missteps in the past. It will also take our engendering and promoting a culture of tolerance and openness.</p>