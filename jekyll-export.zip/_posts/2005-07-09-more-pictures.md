---
id: 642
title: More Pictures
date: 2005-07-09T12:13:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/more-pictures
permalink: /2005/07/09/more-pictures/
categories:
  - Philosophy! and Politics!
---
<p>Been out and about taking more pictures...</p>


	<center><a href="http://www.flickr.com/photos/tsykoduk/24702125/" title="Photo Sharing"><img src="http://photos22.flickr.com/24702125_ba820337fc_m.jpg" width="240" height="180" alt="IMG_1874" /></a>
	<br />
	<a href="http://www.flickr.com/photos/tsykoduk/24702278/" title="Photo Sharing"><img src="http://photos21.flickr.com/24702278_19efd54e66_m.jpg" width="240" height="180" alt="IMG_1875" /></a></center>

		<p>Just a sample of my latest photo-skilz. Word up.</p>