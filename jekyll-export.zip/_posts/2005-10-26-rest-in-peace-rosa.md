---
id: 987
title: Rest in Peace, Rosa
date: 2005-10-26T19:18:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/rest-in-peace-rosa
permalink: /2005/10/26/rest-in-peace-rosa/
categories:
  - Philosophy! and Politics!
---
<center><a href="http://en.wikipedia.org/wiki/Rosa_Parks"><img src="http://images.apple.com/home/2005/images/rosaparks20051025.jpg" width=400 /></a></center>

	<p>(HT: <a href="http://www.apple.com:">Apple</a> for the image; Here is a full sized <a href="http://images.apple.com/home/2005/images/rosaparks20051025.jpg">image</a>)</p>