---
id: 455
title: High Holy Day
date: 2005-05-23T10:22:16+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/high-holy-day
permalink: /2005/05/23/high-holy-day/
categories:
  - Philosophy! and Politics!
---
<p>Today, 5/23 is the High Holy Day of the Spokane Chapter of the Evil Penguin Discordian Church.</p>


		<p>Did you know that 5=2+3? and 5+2+3=10? and 10/5=2?</p>


	<blockquote>Let us not partake in bunless hotdogs on this day. Let us shake the <a href="http://www.google.com/search?hl=en&#38;q=cabbage+in+head&#38;btnG=Google+Search">cabbage</a> out of our brains, let us take <a href="http://www.google.com/search?hl=en&#38;lr=&#38;q=communion+starbucks&#38;btnG=Search">communion</a> at StarBucks (the official <a href="http://www.thedistributors.com/inven/subject/philwst.htm">Evil Penguin Discordian Church</a> Facilties management company). All hail who the hell ever you want to hail, or not to hail. Let us work to banish GreyFace! Let us use the great <a href="http://www.google.com/search?hl=en&#38;lr=&#38;q=Turkey+Curse&#38;btnG=Search">turkey curse</a> at all times! <a href="http://www.google.com/search?hl=en&#38;lr=&#38;q=Semper+Discordia&#38;btnG=Search">Semper Discordia</a>!</blockquote>

		<p><em>Attributed to Saint Pope Fred the Penguin King. </em></p>