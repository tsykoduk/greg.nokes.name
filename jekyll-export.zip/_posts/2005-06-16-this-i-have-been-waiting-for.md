---
id: 551
title: This, I have been waiting for
date: 2005-06-16T22:14:02+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-i-have-been-waiting-for
permalink: /2005/06/16/this-i-have-been-waiting-for/
categories:
  - Fun!
---
<center><img src="http://www.sjgames.com/gurps/traveller/interstellarwars/img/cover_sm.jpg" /></center>

	<blockquote><a href="http://www.sjgames.com/gurps/traveller/interstellarwars/"><span class="caps">GURPS</span> Traveller</a>: Interstellar Wars covers the 200 years of war, peace, and overwhelming change as the ancient Vilani Imperium falls to the upstart Terrans. In this time of conflict, the opportunities for adventure are more exciting than ever before!</blockquote>

		<p>Coming in October!</p>