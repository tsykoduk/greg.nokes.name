---
id: 779
title: Yes, Linux can do anything
date: 2005-08-23T18:34:56+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/yes-linux-can-do-anything
permalink: /2005/08/23/yes-linux-can-do-anything/
categories:
  - Computers! and Code!
  - Fun!
---
<blockquote>11 years ago, April 1st 1990, rfc 1149 was written. This rfc specifies a protocol for IP over avian carriers, <span class="caps">CPIP</span> (carrier pigeon internet protocol). In 11 years, noone has bothered to implement this important protocol stack. But happily, we don't need to wait any longer! <span class="caps">BLUG</span> in cooperation with Vesta Brevdueforening has given you rfc 1149 support for Linux.</blockquote>

		<p>-<a href="http://www.blug.linux.no/rfc1149/">Bergen Linux User Group</a></p>


		<p>For you backwoods types, now you can do IP over Carrier Pigeon.</p>