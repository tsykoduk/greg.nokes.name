---
id: 1186
title: 'God&#039;s Keynote speach at HeavenExpo &#039;06'
date: 2005-12-24T13:46:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/god-s-keynote-speach-at-heavenexpo-06
permalink: /2005/12/24/god-s-keynote-speach-at-heavenexpo-06/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p>Yup - you read it correctly! Listen to God's <a href="http://media27b.libsyn.com/podcasts/dailybreakfast/godskeynote.mp3">Keynote speech</a> from the exclusive HeavenExpo '06. God seems like a really cool guy.</p>


<center><a href="http://media27b.libsyn.com/podcasts/dailybreakfast/godskeynote.mp3"><img src="http://www.tuaw.com/media/2005/12/godkeynote.jpg" /></a></center>(HT: <a href="http://www.tuaw.com/2005/12/24/gods-keynote-address/"><span class="caps">TUAW</span></a>)