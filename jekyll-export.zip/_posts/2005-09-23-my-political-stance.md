---
id: 892
title: My Political Stance
date: 2005-09-23T07:11:05+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/my-political-stance
permalink: /2005/09/23/my-political-stance/
categories:
  - Philosophy! and Politics!
---
<center><table style='border:1px solid black'><tr><td align=center> <font size="3"> You are a <center> <br /> <font size="4"><b>Social Liberal</b></font> <br /> <font shmolor="#a8a8a8" size="3">(75% permissive)</font><br /> </center> <br /> and an... <center><br /> <font size="4"><b>Economic Conservative</b></font> <br /> <font shmolor="#a8a8a8" size="3">(68% permissive)</font><br /> </center> <br /> You are best described as a:<br /> <br /></font><font size="+2"><u><center><b>Libertarian</b></center></u></font> <br /> <table id="thetable" name="thetable" background="http://is2.okcupid.com/graphics/politics/chart_political.gif" border="0" cellpadding="0" cellspacing="0" height="375" width="375"> <tbody><tr height="100"> <td width="262"></td> <td width="112"></td> </tr> <tr height="274"><td width="262"></td> <td align="left" valign="top" width="112"><img src="http://is2.okcupid.com/graphics/politics_you.gif" border="0"/></td> </tr> </tbody></table> <br /> <table id="thetable" name="thetable" background="http://is2.okcupid.com/graphics/politics/chart_basic.jpg" border="0" cellpadding="0" cellspacing="0" height="375" width="375"> <tbody><tr height="100"> <td width="262"></td> <td width="112"></td> </tr> <tr height="274"><td width="262"></td> <td align="left" valign="top" width="112"><img src="http://is2.okcupid.com/graphics/politics_you.gif" border="0"/></td> </tr> </tbody></table> <br /><br />Link: <a href='http://www.okcupid.com/politics'><b>The Politics Test</b></a>  on <a href='http://www.okcupid.com'><b>Ok Cupid</b></a></td></tr></table></center>

	<p>(HT: <a href="http://davejustus.blogspot.com/2005/09/politics-test.html">Justus</a>)</p>