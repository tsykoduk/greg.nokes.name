---
id: 2822
title: Gnome settings
date: 2007-05-24T23:30:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/gnome-settings
permalink: /2007/05/24/gnome-settings/
categories:
  - Computers! and Code!
---
<p>I am a pretty die-hard gnome user (when I am on a *nix box). I have developed a set of default settings which make it really usable, and pretty...</p>

<p>So here goes..</p>

<p>Global Settings<br />
  Theme<br />
    Controls: Clearlook<br />
    Window Border: Alphacube 0.9b Metacity Color<br />
    Icons: Dropline Neu!<br />
    Font: All default except Application Font: Berylium<br /></p>

<p>gEdit settings<br />
  Plugins Enabled:<br />
    Document Statistics<br />
    File Browser Pane<br />
    Gemini<br />
    Insert Date/Time<br />
    Modelines<br />
    Snap Open<br />
    Snippits<br />
  Font<br />
   Monaco 10px<br /></p>