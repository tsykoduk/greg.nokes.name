---
id: 59
title: Buddhist resources in Spokane
date: 2005-01-10T13:01:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/buddhist-resources-in-spokane
permalink: /2005/01/10/buddhist-resources-in-spokane/
categories:
  - Philosophy! and Politics!
---
<p><a href=http://www.nwdharma.org/details.php?group_id=22&#38;group_name=Benefaction+Sangha+of+Spokane>Benefaction Sangha of Spokane</a><br /><br /><a href=http://www.spokanebuddhisttemple.org>Spokane Buddhist Temple</a><br /><br /><a href=http://www.thubtenchodron.org>Sravasti Abbey</a><br /><br /><a href=http://www.zencenterspokane.org>Zen Center of Spokane</a><br /><br /></p>