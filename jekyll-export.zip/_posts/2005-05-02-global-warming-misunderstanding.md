---
id: 373
title: Global Warming Misunderstanding
date: 2005-05-02T13:56:08+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/global-warming-misunderstanding
permalink: /2005/05/02/global-warming-misunderstanding/
categories:
  - Science!
---
<p><em>(I have not been able to get in and comment on this on Justus For All - Blogger is having issues again. So, my comment is posted here)</em></p>


		<p>On <a href="http://davejustus.blogspot.com/2005/04/new-data-show-global-warming.html#comments">Justus for All</a>, <a href="http://www.blogger.com/profile/1891511">Cube</a> says the following:</p>


	<blockquote>Global warming is a problem that will solve itself.

		<p>If things get warmer and ice melts, then you are going to have longer growing seasons and more greenery.</p>


		<p>The warmer it gets the more ocean you will have also (Most oxygen is produced by the ocean, i bet the ocean also uses the most <span class="caps">C02</span>).</blockquote></p>


		<p>This is not totally untrue. The world will adjust. I guess my concern, is will the human race adjust?</p>


		<p>When that ice melts, the oceans level will rise. Our beach front properties will become more difficult to get to (being under water and all) and our inland cities will be the new beachfront meccas.</p>


		<p>Many of the current breadbaskets (the Central Valley of California for example) will no longer be able to support agribusiness. Food will become scarse. Life will suck for the surviors.</p>


		<p>I am not saying that this will happen tomorrow, or the next day - but it's in our cards unless we do take drastic action.</p>