---
id: 793
title: Bring It On, and On, and On
date: 2005-08-26T17:01:04+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bring-it-on-and-on-and-on
permalink: /2005/08/26/bring-it-on-and-on-and-on/
categories:
  - Philosophy! and Politics!
---
<blockquote>In general, terrorism is a violent tool in a political struggle, where one side is overmatched in conventional terms. Robert Pape, author of the new book, Dying to Win, reviewed 315 suicide bombing attacks between 1983 and 2003 and found that virtually all of them had "a specific secular and strategic goal: to compel democracies to withdraw military forces from the terrorists' national homeland."</blockquote>

	<p>and</p>


<blockquote> Observes Robert Pape: "Since suicide terrorism is mainly a response to foreign occupation and not Islamic fundamentalism, the use of heavy military force to transform Muslim societies over there, if you would, is only likely to increase the number of suicide terrorists coming at us... Suicide terrorism is not a supply-limited phenomenon where there are just a few hundred around the world willing to do it because they are religious fanatics. It is a demand-driven phenomenon."</blockquote>

	<p>-<a href="http://www.cato.org/pub_display.php?pub_id=4312">Cato</a></p>


	<p>I guess that this is the crux of the matter. Now days, we are paying the price for years of mismangment of foriegn affairs by ourselves and the Eurpoeans. There are real reasons that we are hated in portions of the world. It's not just because we are wealthy (altho that does not help) and it's not because we are of a diffrent religion. It's because of our hubris.</p>