---
id: 776
title: Open Source?
date: 2005-08-18T13:55:09+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/open-source
permalink: /2005/08/18/open-source/
categories:
  - Computers! and Code!
  - Philosophy! and Politics!
---
<blockquote><li>An open source project is about people producing free and open software and contributing to something as a team for the benefit of others.</li>
	<li> Open source projects reflect the spirit of collaboration and fun while garnering community feedback and providing good governance that allows for business to confidently invest in its development.</li>
	<li>Open source projects are open to the participation of anybody who can contribute value and is willing to work with the community.</li>
	</blockquote>

		<p>-<a href="http://www.opensourcematters.org/">OpenSourceMatters</a></p>


		<p>I think that this is one of the best definitions of Open Source that I have seen. So many of the Open Source projects forget these tenants. The leaders seem to be off on some adolescent power trip - and beware anyone who questions, asks or even makes a small noise in the corner.</p>


		<p>I guess the beauty of Open Source is that the projects that are run like this will die off, and the better managed ones will succeed.</p>