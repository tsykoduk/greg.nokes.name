---
id: 1114
title: What Peanuts Charactor am I?
date: 2005-11-13T12:14:48+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/what-peanuts-charactor-am-i
permalink: /2005/11/13/what-peanuts-charactor-am-i/
categories:
  - Mundane
---
<p>Ya wanna know?</p>


	<p>Did not think so.. :)</p>


	<p><img src="http://images.quizilla.com/A/anonymousnowhere/1064197208_r_franklin.jpg" border="0" alt="Franklin"/><br />You are Franklin!
<br /><br /><a href="http://quizilla.com/users/anonymousnowhere/quizzes/Which%20Peanuts%20Character%20are%20You%3F/"> Which Peanuts Character are You?</a><br /> <font size="-2">brought to you by <a href="http://quizilla.com">Quizilla</a></font></p>


	<p>(HT: <a href="http://www.samanthaburns.com/archives/2005/11/peanuts_quiz.html">Sam</a>)</p>