---
id: 2233
title: Life, explained
date: 2007-03-21T23:39:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/life-explained
permalink: /2007/03/21/life-explained/
categories:
  - Philosophy! and Politics!
---
<blockquote>When we remember we are all mad, the mysteries disappear and life stands explained.</blockquote>

	<p><a href="http://www.quotationspage.com/quote/1280.html">Mark Twain</a></p>