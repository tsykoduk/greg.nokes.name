---
id: 1213
title: A fantastic definition
date: 2006-01-20T14:49:49+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-fantastic-definition
permalink: /2006/01/20/a-fantastic-definition/
categories:
  - Fun!
---
<p>is <a href="http://uncyclopedia.org/wiki/Nihilism">here.</a> What do you think? Does it define the word correctly?</p>