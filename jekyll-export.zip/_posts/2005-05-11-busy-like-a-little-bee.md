---
id: 414
title: Busy like a little bee
date: 2005-05-11T21:10:18+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/busy-like-a-little-bee
permalink: /2005/05/11/busy-like-a-little-bee/
categories:
  - Mundane
---
<p>Sorry about the derth of posts - I have been really busy lately. Most of this week is shot...</p>