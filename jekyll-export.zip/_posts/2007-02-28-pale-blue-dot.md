---
id: 2211
title: Pale Blue Dot
date: 2007-02-28T17:07:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/pale-blue-dot
permalink: /2007/02/28/pale-blue-dot/
categories:
  - Mundane
  - Philosophy! and Politics!
  - Science!
---
<p><a href="http://www.badastronomy.com/bablog/2007/02/27/pale-blue-dot/">The BA</a> brought this video to my attention. Fantastic stuff.</p>


<object width="425" height="350">
    <param name="movie" value="http://www.youtube.com/v/47EBLD-ISyc"></param>
    <param name="wmode" value="transparent"></param>
    <embed src="http://www.youtube.com/v/47EBLD-ISyc" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed>
</object>

	<p>I really believe that we are on the cusp of a transcendence. Not really in a metaphysical way, but in a social way. People have been talking about it for a long time, because they could <em>feel</em> what was coming. Many have tried to wrap their religion or metaphysics around it. It's simpler then that.</p>


	<p>I think that we are going to see a move away from the old superstitions which hold us back. As we discover more and more about the universe, how it works, and our place it in, it becomes evident that we <b>are not</b> the center of <b>anything</b>.</p>


	<p>We, however do have a great impact on the world which we live on. If we plan on living here much longer, we need to take steps, hard steps, to insure that the world will support us. We are not here to 'dominate' the world, we are here as guests of the world.</p>


	<p>It's far past time to realize that simple fact. We are not the reason that the world is here, the world is the reason that we are here. Once we shift our thinking away from dominance towards partnership, we will be in a lot better place socially, environmentally, and economically.</p>