---
id: 747
title: Is Safe Water too much to ask for?
date: 2005-08-14T19:53:35+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/is-safe-water-too-much-to-ask-for
permalink: /2005/08/14/is-safe-water-too-much-to-ask-for/
categories:
  - Philosophy! and Politics!
---
<blockquote>The issue of mass medication of an unapproved drug without the expressed informed consent of each individual must also be addressed. The dose of fluoride cannot be controlled. Fluoride as a drug has contaminated most processed foods and beverages throughout North America. Individuals who are susceptible to fluoride's harmful effects cannot avoid ingesting this drug. This presents a medico-legal and ethical dilemma and sets water fluoridation apart from vaccination as a public health measure where doses and distribution can be controlled. The rights of individuals to enjoy the freedom from involuntary fluoride medication certainly outweigh the right of society to enforce this public health measure, especially when the evidence of benefit is marginal at best.</blockquote>

		<p>-<a href="http://www.fluoridealert.org/limeback.htm">Fluoride Action Network</a></p>


	<blockquote>John Robideaux, chairman of Fluoridation Works, said his organization has not given up its effort to introduce fluoride into Spokane water and may mount another petition drive in the spring.</blockquote>

		<p>-<a href="http://www.spokesmanreview.com/top/story.asp?ID=22699">the Spokesman Review</a></p>


		<p>I guess that my major concern with this is that I will have to pay for something that not only do I not want, but that I will have to take more action to rid my self off. So, if this passes, they are going to charge me to put this stuff into the water, and then I will have to pay to get it removed again.</p>


		<p>Sucks to be me if this actually makes it, right?</p>


		<p>Why not let people choose? If I want to fluoride my self and my kid, let ME make that choice.</p>