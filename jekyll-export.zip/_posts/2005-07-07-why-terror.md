---
id: 631
title: Why Terror?
date: 2005-07-07T09:08:45+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/why-terror
permalink: /2005/07/07/why-terror/
categories:
  - Philosophy! and Politics!
---
<blockquote>It is hard for most people steeped in the humane, liberal values of Western Civilization to understand the massacre of innocents. To slaughter to make a political point. But terrorism is not likely to disappear. Indeed, it is a surprisingly common practice. Although Americans were taken unaware on September 11, many other peoples have long suffered from the murderous attention of domestic and foreign terrorists.

		<p>Terrorism is common, and will persist, because it is a tool of the weak versus the strong, a cheap military weapon to achieve expensive political goals. As long as there are people willing to kill to advance their ends, there will be terrorists.</blockquote></p>


		<p>- <a href="http://www.cato.org/pub_display.php?pub_id=3317">Doug Bandow</a></p>