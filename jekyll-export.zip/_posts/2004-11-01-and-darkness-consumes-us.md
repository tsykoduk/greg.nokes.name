---
id: 215
title: And darkness consumes us
date: 2004-11-01T16:49:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/and-darkness-consumes-us
permalink: /2004/11/01/and-darkness-consumes-us/
categories:
  - Philosophy! and Politics!
---
<p>I believe that Tolken meant for his books to be an allegory for life. Many of the darkest portions were written while he served in World War One. His books paint a picture that is very much black and white. We have the soul-wrenching evil of Sauron and the lily-white purity of the Elves and Gandalf.</p>


	<p>Or do we? The real world is all shades of grey, and I believe that he showed us a world where under the surface; all was not as black and white as we would be lead to think. For example, the Elves created the problem (Sauron) and were up and leaving. Gandalf never revealed his true intentions, nor that he more then likely saw what was coming. If he had been up front with the 'forces of good' about what they were going to face, would any of them even left their hearths and homes and ventured out?</p>


	<p>Right now, we face a foe just as determined as Sauron was in the books. Instead of marshaling armies, however, he strikes at our culture, our hearts and minds. Do not mistake his aims; his goal is to remake the world into his image. It would be easier to accept if he invaded countries, marched on cities and waged a conventional war, however he knows that he cannot openly fight us and win.</p>


	<p>The Era of the conventional war is slipping away. No one in the world can stand up to the <span class="caps">USA</span> in a conventional slugging match, and the entire world sees this. Other tactics must be used if these people want to wage war on us and have a chance of winning. The tactics of Terror are the manual for the new war. In essence, our strength has caused the New War.</p>


	<p>Unlikely warriors fight many of the battles outside of the public eye. It can be as simple as extending a truly non-judgmental helping hand to some one in need, or as complex as a Special Forces strike on a safe house to remove the threat of an attack. People are fighting and dying right now to keep you and me safe, and we will never know their names, never even know of the conflict that is happening as we tuck each other into bed at night.</p>


	<p>Mistake me not; this war is going on right now, all over the world, in the shadows. If we are to win it, we must fight with resolve. When force is called for, we must strike hard and fast and never waver. When other options are available to us, we must use them.</p>


	<p>-Tsyko</p>