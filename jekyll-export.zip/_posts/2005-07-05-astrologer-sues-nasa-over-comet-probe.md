---
id: 623
title: Astrologer Sues NASA Over Comet Probe
date: 2005-07-05T17:01:46+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/astrologer-sues-nasa-over-comet-probe
permalink: /2005/07/05/astrologer-sues-nasa-over-comet-probe/
categories:
  - Fun!
---
<p>From the Too Stupid to be True? department</p>


		<p><a href="http://science.slashdot.org/article.pl?sid=05/07/05/1422222&#038;from=rss">Slashdot </a> says:</p>


	<blockquote><span class="caps">NASA</span>'s mission that sent a space probe smashing into a comet raised more than cosmic dust <del>- it also brought a lawsuit from a Russian astrologer. 'Bai is seeking damages totaling $300 million -</del> the approximate equivalent of the mission's cost-for her "moral sufferings," Izvestia said, citing her lawyer Alexander Molokhov. She earlier told the paper that the experiment would "deform her horoscope."'</blockquote>

		<p>And, that folks, is that.</p>