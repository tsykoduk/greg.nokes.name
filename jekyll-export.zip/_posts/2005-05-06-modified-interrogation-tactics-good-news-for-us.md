---
id: 406
title: 'Modified interrogation tactics: Good news for us!'
date: 2005-05-06T14:05:39+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/modified-interrogation-tactics-good-news-for-us
permalink: /2005/05/06/modified-interrogation-tactics-good-news-for-us/
categories:
  - Philosophy! and Politics!
---
<p>William Anderson has this to <a href="http://blog.lewrockwell.com/lewrw/archives/007992.html#more">say</a></p>


	<blockquote>Cal Thomas, in a recent column, <a href="http://www.townhall.com/columnists/calthomas/ct20050502.shtml">endorses torture</a> of our "enemies," but at least he does not directly try to Christianize it... This column, however, demonstrates that Thomas's moral compass is a bit skewed. </blockquote>

		<p><a href="http://www.townhall.com/columnists/calthomas/ct20050502.shtml">Thomas </a> says in the article:</p>


	<blockquote>These people are evil to the core. The only way to protect ourselves is to extract information they might have by whatever means necessary. This war won't be won (at least by our side) if we impose on ourselves restrictions that the terrorists do not impose on themselves.</blockquote>

		<p>and</p>


	<blockquote>Are we not paying attention to the beheading videos? The barbarians are at the gate. In fact, they have broken down the gate. Why are we letting them in and treating them only a little more harshly than unwelcome holiday relatives?</blockquote>

		<p>I would hope that we treat the with the dignity that they deserve as human beings! Yes, they have information that we need. There are other ways to get it that do not include torture. I understand more then most that we are at war - that our enemy wants nothing less the the destruction of our very culture. And I understand that they will stop at nothing to achive their ends.</p>


		<p>Lowering our selves to their inhuman standards is not the path to take. We might defeat them using those tactics, however we will become them. And they would win in the end.</p>


		<p>We are the good guys. We need to remind ourselves of that, and act like it. We are fighting thugs and bullys - let's not slip and become what we fight!</p>


		<p>"<em>This war won't be won if we impose on ourselves restrictions that the terrorists do not impose on themselves.</em>"</p>


		<p>So - let's go all out and strap bombs onto some Marines and send them into buildings full of civilians. If we must use the Terrorist's tactics, let's not slip up and forget one. How about just carpet bombing the Gaza Strip. Oh and we cannot forget the Montana Militia - we should car bomb their Safeways and Albertsons.</p>


		<p>We <strong>must</strong> impose restrictions on ourselves that the Terrorists will not impose on themselves. To even consider not is ludicrous.</p>