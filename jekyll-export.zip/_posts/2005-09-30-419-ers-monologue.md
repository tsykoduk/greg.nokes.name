---
id: 910
title: '419&#039;ers Monologue'
date: 2005-09-30T07:45:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/419-ers-monologue
permalink: /2005/09/30/419-ers-monologue/
categories:
  - Fun!
---
<p>Yeah - <a href="http://www.zefrank.com/request/index_better.html">this</a> is actually really cool!</p>


	<p>In other news I have the day off (WooHoo!) in order to do some housework (Booo! Hisss!) Got the tunes blasting right now...</p>