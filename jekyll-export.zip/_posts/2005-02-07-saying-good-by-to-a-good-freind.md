---
id: 115
title: 'Saying good by to a good freind&#8230;'
date: 2005-02-07T22:09:25+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/saying-good-by-to-a-good-freind
permalink: /2005/02/07/saying-good-by-to-a-good-freind/
categories:
  - Science!
---
<p><a href=http://www.cnn.com/2005/TECH/space/02/07/budget.nasa.ap/index.html>Sad</a>.<br /><br /></p>