---
id: 15311
title: Interesting Woops
date: 2010-06-08T21:42:18+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15311
permalink: /2010/06/08/interesting-woops/
categories:
  - Computers! and Code!
tags:
  - Hackery
  - OSX
  - WTF
---
I just had an interesting woops. Installed iPhone SDK onto my snow lepoard machine (for the first time) and it added a <code>PATH=</code> to the <code>/etc/profile</code> file. That took a little working around!