---
id: 744
title: Yes, I own stock!
date: 2004-12-27T15:49:03+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/yes-i-own-stock
permalink: /2004/12/27/yes-i-own-stock/
categories:
  - Fun!
---
<center><a href="http://www.starbucks.com/"><img src="http://www.nwgamers.org/images/starbucksgeek.jpg"/></a></center>

	<p>But at least I had another reason for the trip. I was not in seattle to pay Homage at the Home of the Grounds.</p>


	<p>Really.</p>


	<p>No, really!</p>