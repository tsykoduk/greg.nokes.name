---
id: 42
title: Morning Coffee
date: 2005-01-21T06:37:47+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/morning-coffee
permalink: /2005/01/21/morning-coffee/
categories:
  - Fun!
---
<center><a href="http://home.att.net/slugbutter/evil/" target="new"&gt;<img src="http://home.att.net/slugbutter/evil/good.jpg" border=0/&gt;</a><br /><a href="http://home.att.net/slugbutter/evil/" target="new"&gt;How evil are <i>you</i>?</a></center><br /><br />from <a href="http://home.att.net/</sub>slugbutter/evil/"&gt;here</a><br /><br />Kind of dissapointing - I had always hoped that I was Evil. Guess I need to work on that.<br /><br />Also - you need to check this <a href="http://www.rooftopreport.com/rooftopreport/vw_20_b3.mov">commercial</a> out.<br /><br />Thanks <a href="http://davejustus.blogspot.com/">Justus</a> for giving me a good morning laugh!