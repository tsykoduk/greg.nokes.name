---
id: 480
title: Blogs Ate My Teenager!
date: 2005-05-27T11:52:52+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/blogs-ate-my-teenager
permalink: /2005/05/27/blogs-ate-my-teenager/
categories:
  - Philosophy! and Politics!
---
<blockquote>Is blogging dangerous? The Christian Science Monitor hopes it might be, in a terrifying new article entitled "Teens: It's a diary. Adults: It's unsafe." The article, which oversimplifies blogs as "self-published Web pages," cites stats given by Parry Aftab of Wiredsafety.org: "Internet stalkers have killed at least four minors in the past three years, and law enforcement authorities count about 5,000 reports of attempted sexual predation over the Internet in the past year..." Compare this to the 374 Americans struck by lightning and killed between 1995-2000 (apha.confex.com, May 25, 2005), and you may relax somewhat. Sure, cyberstalkers are scary, but so is the wrath of Zeus.</blockquote>

		<p>From <a href="http://secretlair.com/index.php?/clickableculture/entry/blogs_ate_my_teenager/">Clickable Culture</a></p>


		<p>Yet another case of statistics gone wrong. It's like I said <a href="http://greg.nokes.name/?p=425">before</a>,  The media is in the business of selling papers, air time or what ever. They are not going to report things that will not sell. I agree that parents should be aware of their children's activities, but to be terrorified because they have less then a 0.00001% (5000 acts vs 297 million people in the US) of being victimised? It's more dangerous to step off the curb.</p>


		<p>(Hat Tip <a href="http://weblogtoolscollection.com/archives/2005/05/26/blogs-ate-my-teenager/">Weblogs Tools Collection</a>)</p>