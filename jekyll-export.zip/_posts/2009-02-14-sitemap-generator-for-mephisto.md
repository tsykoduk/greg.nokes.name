---
id: 8452
title: Sitemap Generator for Mephisto
date: 2009-02-14T01:52:00+00:00
author: tsykoduk
layout: post
guid: 30/2009/02/16/sitemap-generator-for-mephisto
permalink: /2009/02/14/sitemap-generator-for-mephisto/
categories:
  - Computers! and Code!
---
<p>The old sitemap generator for mephisto was broken under the newer rails/mephisto plugin scheme. So I spent a few minutes in an airport hacking on it. It now works, with all default settings set, well, defaulty. Go <a href="http://github.com/tsykoduk/mephisto-sitemap-generator/tree/master">get it</a>!</p>


	<p><strong>Update:</strong></p>


	<p>Also... I spent a little time integrating the plugin into mephisto core - including admin side settings. <a href="http://github.com/tsykoduk/mephisto/tree/master">go get it!</a>.</p>