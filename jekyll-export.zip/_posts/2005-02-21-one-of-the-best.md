---
id: 82
title: 'One of the best&#8230;'
date: 2005-02-21T22:03:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/one-of-the-best
permalink: /2005/02/21/one-of-the-best/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p>I stumbled across one of the best photo-documentaries of '<a href=http://www.christojeanneclaude.net/tg.html>The Gates</a>' in New York. It's not of the massive art, but of the people taking pictures of the massive art..<br /><br /><blockquote><center><img src=http://mako.yukidoke.org/fun/picturesque/highlight.png/></center><br /><br />The Gates is a massive art installation by Christo and Jeanne-Claude in Central Park, New York City. It's only going to last for a little over two weeks. As a result, Central Park has been packed. Most of the people packing the park have come with cameras in hand.<br /><br />Today, Mika and I went to visit central park to see it under some freshly fallen snow. Rather than take pictures of the gates, which everybody does, we decided to (sneakily) take pictures of the people taking pictures of the gates.<br /><br />We're calling the resulting photo-documentary Picturesque: Picture of Pictures of the Gates</blockquote><br /><br />Hat Tip - <a href=http://mako.yukidoke.org/copyrighteous>Mako</a>, and you can view the entire work <a href=http://mako.yukidoke.org/fun/picturesque/>here</p>