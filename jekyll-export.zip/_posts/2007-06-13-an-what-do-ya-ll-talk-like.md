---
id: 2858
title: 'An&#039;, what do ya&#039;ll talk like?'
date: 2007-06-13T17:43:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/an-what-do-ya-ll-talk-like
permalink: /2007/06/13/an-what-do-ya-ll-talk-like/
categories:
  - Mundane
---
<table border=0 bgcolor=black cellspacing=2 cellpadding=10><tr bgcolor=white><td align=center><b><font face=verdana,arial,helvetica size=2><a href=http://www.youthink.com/quiz.asp?action=take&#38;quiz_id=9827><font color=#505A84>What American accent do you have? (Best version so far)</font></a></b><p><font color=#505A84 size=4><b>Midland</b></font><p>("Midland" is not necessarily the same thing as "Midwest") The default, lowest-common-denominator American accent that newscasters try to imitate.  Since it's a neutral accent, just because you have a Midland accent doesn't mean you're from the Midland.<p><a href=http://www.youthink.com/quiz.asp?action=take&#38;quiz_id=9827><img alt="Personality Test Results" border=0 src="http://www.youthink.com/quiz_images/full_428371978.jpg"></a></td></tr><tr><td align=center><a href=http://www.youthink.com/quiz.asp?action=take&#38;quiz_id=9827><font face=verdana size=2 color=white><b>Click Here to Take This Quiz</b></font></a><br /><font size=1 color=C0C0C0 face=verdana>Brought to you by <a href=http://www.youthink.com/quiz.asp><font color=white>YouThink.com</font></a> quizzes and personality tests.</font></td></tr></table>