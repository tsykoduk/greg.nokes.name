---
id: 178
title: Hatty-ness
date: 2005-03-07T18:56:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/hatty-ness
permalink: /2005/03/07/hatty-ness/
categories:
  - Fun!
---
<center><br /><a HREF="http://quiz.ravenblack.net/hat.pl"><img BORDER=0 ALIGN="LEFT" WIDTH=80 HEIGHT=80 SRC="http://quiz.ravenblack.net/hat/2.png" ALT="What Sort of Hat Are You? I am a Fedora." /></a>I am <b>a Fedora</b>.<br /><br /><br />The hat of the adventurous, I am spontaneous and active, perhaps sometimes a little foolishly. Regardless, I always come out alright. <a HREF="http://quiz.ravenblack.net/hat.pl">What Sort of Hat Are You?</a></center><br /><br />Yet again - <a href=http://emilyscraziness.blogspot.com>Craziness</a>