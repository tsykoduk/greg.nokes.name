---
id: 1355
title: Is that biodiesel in your pocket or..
date: 2006-04-20T10:01:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/is-that-biodiesel-in-your-pocket-or
permalink: /2006/04/20/is-that-biodiesel-in-your-pocket-or/
categories:
  - Science!
---
<blockquote><p><span class="caps">PORTLAND</span>, Oregon-A tiny chemical reactor that can convert vegetable oil directly into biodiesel could help farmers turn some of their crops into homegrown fuel to operate agricultural equipment instead of relying on costly imported oil.</p>
<p>"This is all about producing energy in such a way that it liberates people," said Goran Jovanovic, a chemical engineering professor at Oregon State University who developed the microreactor.</p></blockquote>
<p>-<a href="http://www.wired.com/news/wireservice/0,70702-0.html?tw=rss.index">Wired</a>
</p>