---
id: 816
title: Congrats to the Bro
date: 2005-08-28T16:43:12+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/congrats-to-the-bro
permalink: /2005/08/28/congrats-to-the-bro/
categories:
  - Mundane
---
<center><img src="http://photos29.flickr.com/38097317_9ea505013f_o.jpg" /></center>

	<p><a href="http://noctrine.blogspot.com/2005/08/what-officially-important-stuff-have-i.html">He made it</a>! Now back to the grindstone for you! Muhahahaah</p>