---
id: 832
title: Music Meme
date: 2005-08-31T21:52:50+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/music-meme
permalink: /2005/08/31/music-meme/
categories:
  - Fun!
---
<p>Gee - this sounds like Fun! (HT: <a href="http://beginaneweachday.blogspot.com/2005/08/music-meme.html">Agent Sierra</a>)</p>


	<p>A.) Go to <a href="http://www.musicoutfitters.com">musicoutfitters</a></p>


	<p>B.) Enter the year you graduated from high school in the search function and get the list of 100 most popular songs of that year</p>


	<p>C.) Bold the songs you like, strike through the ones you hate and underline your favorite. Do nothing to the ones you don't remember (or don't care about).</p>


	<p>&lt;!<del>-more</del>-&gt;
1. <strong>Walk Like An Egyptian, Bangles </strong>
2. <strong>Alone, Heart</strong>
3. Shake You Down, Gregory Abbott
4. I Wanna Dance With Somebody (Who Loves Me), Whitney Houston
5. <strong>Nothing's Gonna Stop Us Now, Starship</strong>
6. <strike>C'est La Vie, Robbie Nevil</strike>
7. <strong>Here I Go Again, Whitesnake</strong>
8. <strong>The Way It Is, Bruce Hornsby and the Range</strong>
9. Shakedown, Bob Seger
10. <strong>Livin' On A Prayer, Bon Jovi </strong>
11. <strong>La Bamba, Los Lobos </strong>
12. <strong>Everybody Have Fun Tonight, Wang Chung</strong>
13. Don't Dream It's Over, Crowded House
14. <strike>Always, Atlantic Starr</strike>
15. With Or Without You, U2
16. Looking For A New Love, Jody Watley
17. Head To Toe, Lisa Lisa and Cult Jam
18. <strike>I Think We're Alone Now, Tiffany </strike>
19. <strong>Mony Mony, Billy Idol</strong>
20. At This Moment, Billy Vera and The Beaters
21. Lady In Red, Chris De Burgh
22. Didn't We Almost Have It All, Whitney Houston
23. I Still Haven't Found What I'm Looking For, U2
24. <strike>I Want Your Sex, George Michael</strike>
25. <strong>Notorious, Duran Duran</strong>
26. <strike>Only In My Dreams, Debbie Gibson</strike>
27. (I've Had) The Time Of My Life, Bill Medley and Jennifer Warnes
28. The Next Time I Fall, Peter Cetera and Amy Grant
29. Lean On Me, Club Nouveau
30. Open Your Heart, Madonna
31. Lost In Emotion, Lisa Lisa and Cult Jam
32. <strong>(I Just) Died In Your Arms, Cutting Crew</strong>
33. Heart And Soul, T'pau
34. You Keep Me Hangin' On, Kim Wilde
35. <strong>Keep Your Hands To Yourself, Georgia Satellites</strong>
36. I Knew You Were Waiting (For Me), Aretha Franklin and George Michael
37. Control, Janet Jackson
38. Somewhere Out There, Linda Ronstadt and James Ingram
39. <strong>U Got The Look, Prince</strong>
40. <strong><u>Land Of Confusion, Genesis</u></strong>
41. <strong>Jacob's Ladder, Huey Lewis and The News </strong>
42. Who's That Girl, Madonna
43. <strong>You Got It All, Jets</strong>
44. Touch Me (I Want Your Body), Samantha Fox
45. I Just Can't Stop Loving You, Michael Jackson and Siedah Garrett
46. Causing A Commotion, Madonna
47. <strong>In Too Deep, Genesis</strong>
48. Let's Wait Awhile, Janet Jackson
49. <strong>Hip To Be Square, Huey Lewis and the News</strong>
50. Will You Still Love Me?, Chicago
51. Little Lies, Fleetwood Mac
52. <strike>Luka, Suzanne Vega</strike>
53. <strong>I Heard A Rumour, Bananarama </strong>
54. Don't Mean Nothing, Richard Marx
55. <strike>Songbird, Kenny G</strike>
56. Carrie, Europe
57. Don't Disturb This Groove, System
58. La Isla Bonita, Madonna
59. Bad, Michael Jackson
60. Sign 'O' The Times, Prince
61. Change Of Heart, Cyndi Lauper
62. Come Go With Me, Expose
63. Can't We Try, Dan Hill
64. <strong>To Be A Lover, Billy Idol</strong>
65. <strong>Mandolin Rain, Bruce Hornsby and the Range</strong>
66. Breakout, Swing Out Sister
67. <strong>Stand By Me, Ben E. King</strong>
68. <strong>Tonight, Tonight, Tonight, Genesis</strong>
69. <strong>Someday, Glass Tiger</strong>
70. When Smokey Sings, <span class="caps">ABC</span>
71. Casanova, Levert
72. <strong>Rhythm Is Gonna Get You, Gloria Estefan and the Miami Sound Machine</strong>
73. <strong>Rock Steady, Whispers </strong>
74. <strong>Wanted Dead Or Alive, Bon Jovi </strong>
75. <strong>Big Time, Peter Gabriel</strong>
76. The Finer Things, Steve Winwood
77. Let Me Be The One, Expose
78. Is This Love, Survivor
79. Diamonds, Herb Alpert
80. Point Of No Return, Expose
81. Big Love, Fleetwood Mac
82. Midnight Blue, Lou Gramm
83.<strong> Something So Strong, Crowded House </strong>
84. <strong>Heat Of The Night, Bryan Adams </strong>
85. Nothing's Gonna Change My Love For You, Glenn Medeiros
86. Brilliant Disguise, Bruce Springsteen
87. Just To See Her, Smokey Robinson
88. Who Will You Run Too, Heart
89. Respect Yourself, Bruce Willis
90. Cross My Broken Heart, Jets
91. Victory, Kool and The Gang
92. Don't Get Me Wrong, Pretenders
93. Doing It All For My Baby, Huey Lewis and The News
94. Right On Track, Breakfast Club
95. Ballerina Girl, Lionel Richie
96. Meet Me Half Way, Kenny Loggins
97. I've Been In Love Before, Cutting Crew
98. <strong>(You Gotta) Fight For Your Right To Party, Beastie Boys</strong>
99. <strong>Funkytown, Pseudo Echo</strong>
100. Love You Down, Ready For The World</p>