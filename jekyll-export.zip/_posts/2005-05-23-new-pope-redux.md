---
id: 454
title: New Pope Redux
date: 2005-05-23T09:47:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-pope-redux
permalink: /2005/05/23/new-pope-redux/
categories:
  - Philosophy! and Politics!
---
<p>There is an intresting <a href="http://www.uscatholic.org/2005/06/dietmarmieth.pdf">article</a> over at <a href="http://www.uscatholic.org/">US Catholic</a> about the biography of the New Pope. It seems that he was at one time rather progressive - and it details his change towards conservatism. A good read - and one that is rather optimistic about Pope Benedict and the future of the Church. After reading this, I have higher hopes for the direction of the Catholic Church in the next few years.</p>


		<p>(hat tip: <a href="http://www.spokesmanreview.com/blogs/journey/archive.asp?postID=2460">Rebecca</a>)</p>