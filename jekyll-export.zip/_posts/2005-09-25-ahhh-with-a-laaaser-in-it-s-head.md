---
id: 907
title: 'Ahhh.. With a Laaaser in it&#039;s head!'
date: 2005-09-25T22:15:45+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/ahhh-with-a-laaaser-in-it-s-head
permalink: /2005/09/25/ahhh-with-a-laaaser-in-it-s-head/
categories:
  - Fun!
---
<p>So, some guys with a bit to much time on their hands build an automated sentry gun. <a href="http://cs-people.bu.edu/aaron/turret/turret.htm">Really</a>!</p>