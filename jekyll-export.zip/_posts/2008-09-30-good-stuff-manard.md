---
id: 7512
title: Good Stuff, Manard!
date: 2008-09-30T22:00:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/good-stuff-manard
permalink: /2008/09/30/good-stuff-manard/
categories:
  - Computers! and Code!
---
<p><a href='http://www.buildingwebapps.com/learning_rails'> <img src='http://www.buildingwebapps.com/images/ads/learningrails_310x90.gif' alt='Learning Rails Free Online Course in Ruby on Rails' height='90' width='310'> </a></p>


	<p>Good series on Rails and how to build web apps.</p>