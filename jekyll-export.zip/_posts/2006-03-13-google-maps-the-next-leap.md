---
id: 1307
title: 'Google Maps &#8211; the next leap'
date: 2006-03-13T22:11:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/google-maps-the-next-leap
permalink: /2006/03/13/google-maps-the-next-leap/
categories:
  - Science!
---
<p>Yup - <a href="http://www.google.com/mars/">Mars</a>. Cool beans stuff there. I expect the images from the <a href="http://www.nasa.gov/mission_pages/MRO/main/index.html"><span class="caps">MRO</span></a> to start showing up there...</p>