---
id: 635
title: Great read!
date: 2005-07-08T09:28:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/great-read
permalink: /2005/07/08/great-read/
categories:
  - Philosophy! and Politics!
---
<p>You need to check out <a href="http://waiterrant.blogspot.com/">Waiter Rant</a>. Fantastic reading.</p>