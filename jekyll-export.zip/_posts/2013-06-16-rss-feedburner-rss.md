---
id: 15483
title: 'rss -> feedburner -> rss'
date: 2013-06-16T08:49:45+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15483
permalink: /2013/06/16/rss-feedburner-rss/
categories:
  - Mundane
---
I'm going to move away from Feedburner, as I am no longer confident in it's long term viability. This is thanks to Google shutting down reader and moving everything towards the walled garden that is Google Plus. So, if you are one of the two or three people that still follow this blog via RSS, you'll want to move to the feed at <a href="http://greg.nokes.name/feed">http://greg.nokes.name/feed</a> instead of any other. I will not be shutting off the feedburner anytime soon but that day is coming.

<!--more-->

Let this be a lesson. There have been several external companies that I have relied upon for "forever" services and every one of them has failed. The first was bigfoot.com and their email redirector (remember them? Email address for life!) and there have been several since then.

The lesson is keep you data in a portable, open format. Keep several copies. Do not rely on one technology, group or organization to do that for you.

This is one reason that I don't give money to companies like Pandora. I prefer have control over my music. Yes, it's in a not very widely used format right now (thanks, Apple) however it's trivial to move to mp3's or what have you. This is also a reason that I maintain my own domain name. Gmail might die, but I can aways move elsewhere and still get my mail.

Anyways, I'll get off my soapbox. After all, two blog posts in as many days? Must be a sign of the apocalypse, right?

As always you can send thoughts about this to me via <a href="http://twitter.com/tsykoduk">twitter</a>