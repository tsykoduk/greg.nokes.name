---
id: 696
title: High School Stereotype
date: 2005-07-29T08:36:24+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/high-school-stereotype
permalink: /2005/07/29/high-school-stereotype/
categories:
  - Fun!
---
<p><img src='http://images.quizfarm.com/1104014769loner.jpg'/><br /><td> You scored as <b>Loner</b>. <br /><br /><table border='0' width='300' cellspacing='0' cellpadding='0'><tr><td><p><font face='Arial' size='1'>Loner</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='69' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>69%</font></td></tr><tr><td><p><font face='Arial' size='1'>Drama nerd</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='50' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>50%</font></td></tr><tr><td><p><font face='Arial' size='1'>Punk/Rebel</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='44' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>44%</font></td></tr><tr><td><p><font face='Arial' size='1'>Stoner</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='38' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>38%</font></td></tr><tr><td><p><font face='Arial' size='1'>Goth</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='31' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>31%</font></td></tr><tr><td><p><font face='Arial' size='1'>Geek</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='31' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>31%</font></td></tr><tr><td><p><font face='Arial' size='1'>Ghetto gangsta</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='19' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>19%</font></td></tr><tr><td><p><font face='Arial' size='1'>Prep/Jock/Cheerleader</font></p></td><td><table border='1' cellpadding='0' cellspacing='0' width='6' bgcolor='#dddddd'><tr><td></td></tr></table></td><td><font face='Arial' size='1'>6%</font></td></tr></table></td><br /><a href='http://quizfarm.com/test.php?q_id=987'>What&#039;s Your High School Stereotype?</a><br /><font face='Arial' size='1'>created with <a href='http://quizfarm.com'>QuizFarm.com</a></font></p>


		<p>(Gee, let's all thank <a href="http://davejustus.blogspot.com/">Justus</a> for this timewaster!)</p>