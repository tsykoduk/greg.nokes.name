---
id: 447
title: BBC escapes censure over Springer broadcast
date: 2005-05-20T08:49:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bbc-escapes-censure-over-springer-broadcast
permalink: /2005/05/20/bbc-escapes-censure-over-springer-broadcast/
categories:
  - Philosophy! and Politics!
---
<blockquote>"...Freedom of expression should never be sufficient reason to attack the values of any section of the community and this particular programme appeared to set out to do this to people of Christian faith."</blockquote>

		<p>You can read the full story <a href="http://media.guardian.co.uk/site/story/0,14173,1480005,00.html">here</a>. Jeeze, some people get their nappies in a bunch about just about anything.</p>


		<p>Humor is a central part of life. With out it, we turn into fuddy-duddys, which is what <a href="http://jubal.westnet.com/hyperdiscordia/negativism.html">Grey Face</a> wants.</p>


		<p>Turn away from <a href="http://user.sezampro.yu/~babbage/ChaosGos.html">Gray Face</a>! Embrace Fun!</p>