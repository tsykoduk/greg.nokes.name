---
id: 2084
title: New York Times on Computer Security
date: 2007-01-08T15:58:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-york-times-on-computer-security
permalink: /2007/01/08/new-york-times-on-computer-security/
categories:
  - Computers! and Code!
---
<blockquote>Using a non-Windows-based PC may be one defense against these programs, known as malware.. Like Windows, Microsoft's Internet Explorer browser is also a large, convenient target for code-writing vandals. Alternative browsers, like Firefox and Opera, may insulate users.</blockquote>

	<p>-<a href="http://www.nytimes.com/2007/01/07/technology/07tips.html?_r=1&#38;oref=slogin"><span class="caps">NYT</span></a></p>


	<p>Need I say any more?</p>