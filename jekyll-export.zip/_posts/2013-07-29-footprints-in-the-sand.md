---
id: 15505
title: Footprints in the Sand
date: 2013-07-29T08:38:16+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15505
permalink: /2013/07/29/footprints-in-the-sand/
categories:
  - Fun!
  - Philosophy! and Politics!
---
Footprints in the Sand

...the Discordian version

I dreamed that I was walking down the beach with the Goddess. And
I looked back and saw footprints in the sand. But sometimes there
were two pairs of footprints and sometimes there was only one.
And the times there was only one set of footprints, those were my
times of greatest trouble. So I asked the Goddess,

"Why in my greatest need did you abandon me?"

She replied, "I never left you. Those were the times we both
hopped on one foot."

And I was really embarassed for bothering Her with such a stupid
question.