---
id: 191
title: Proof of water on Mars!!
date: 2005-04-01T16:56:03+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/proof-of-water-on-mars
permalink: /2005/04/01/proof-of-water-on-mars/
categories:
  - Science!
---
<p>Yup - you heard it!</p>


	<p>The popular Astronomoy Picture of the Day page has photographic proof of water on mars. It will be a little difficult for those of you who don't have a degree on geology to spot the evidence, but with a little effort, I think you'll be able to make it out.</p>


	<p>Check <a href="http://antwrp.gsfc.nasa.gov/apod/ap050401.html">it</a> out!</p>