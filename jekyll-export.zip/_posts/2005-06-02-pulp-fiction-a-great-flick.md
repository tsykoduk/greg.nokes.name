---
id: 499
title: 'Pulp Fiction &#8211; a great flick'
date: 2005-06-02T16:54:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/pulp-fiction-a-great-flick
permalink: /2005/06/02/pulp-fiction-a-great-flick/
categories:
  - Fun!
---
<center><table border="1" cellspacing="0" cellpadding="5" bordercolor="#333333" width="350">  <tr><td>  <center><a href="http://www.pyrrha.org/pulp"><img border=0 width=300 height=107 src="http://www.pyrrha.org/pulp/char/marsellusbanner.jpg" alt="What Pulp Fiction Character Are You?"/></a>  </center>  <p>Your name alone strikes fear into others; but maybe, just maybe, there's a little vulnerability and weakness beneath that stoic, fierce exterior of yours. </p>  <p>Take the <a href="http://www.pyrrha.org/pulp">What Pulp Fiction Character Are You?</a> quiz. </p>  </td></tr>  </table></center>

		<p>Hat Tip - <a href="http://wabimysabi.blogdrive.com/">Wabi My Sabi</a></p>