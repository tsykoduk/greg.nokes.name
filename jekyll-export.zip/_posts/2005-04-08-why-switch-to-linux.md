---
id: 229
title: Why switch to linux?
date: 2005-04-08T12:29:29+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/why-switch-to-linux
permalink: /2005/04/08/why-switch-to-linux/
categories:
  - Computers! and Code!
  - Fun!
---
<p>This <a href="http://www.nata2.info/humor/flash/switchlinux3.swf">short movie</a> explains it best.</p>