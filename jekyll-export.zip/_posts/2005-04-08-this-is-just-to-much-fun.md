---
id: 228
title: This is just to much fun!
date: 2005-04-08T12:19:25+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-is-just-to-much-fun
permalink: /2005/04/08/this-is-just-to-much-fun/
categories:
  - Computers! and Code!
  - Fun!
---
<p>You have got to check this out! <a href="http://www.nata2.info/humor/flash/bowman.swf">Bowman</a></p>


	<p>Remember: One in the head beats two in the torso!</p>