---
id: 8154
title: airtunes ftw
date: 2009-01-09T19:07:00+00:00
author: tsykoduk
layout: post
guid: 30/2009/01/12/airtunes-ftw
permalink: /2009/01/09/airtunes-ftw/
categories:
  - Mundane
---
<p>As many of you (all one of you?) know, I work from home. Yay me. Well I just reorganized my office, and thought I would share</p>

            <!--more-->

            <p>My primary workspace is a 3 level corner desk. I have Harmon Kardon Sound Sticks as my speakers, a 19's <span class="caps">NEC</span> Opticlear as my primary monitor, an apple aluminum keyboard and a mighty mouse. My primary computer is a white MacBook, and it's monitor is my secondary screen.</p>


	<p>I have an old Dell Intel&#174; Pentium&#174; 4 <span class="caps">CPU 1</span>.60GHz with  645624 kB <span class="caps">RAM</span>, a 20gb <span class="caps">HDD</span> and Linux 2.6.24-etchnhalf.1-686 running on it. I use the digital port for my macbook, and the analog port for the debian box, but 99% of the time I just ssh into it.</p>


	<p>To reduce clutter, I have all of the <span class="caps">USB</span> stuff going through the back of the monitor.</p>


	<p>My network starts with a 7mb <span class="caps">DSL</span> connection downstairs, and an Airport Extreme with an old Express 802.11g for iphone and guest access. Upstairs I have an Express extending the 802.11n network, providing printer sharing for my laser printer and also serving my Sound Sticks via AirTunes.</p>


	<p>Since they are on the same desk as my laptop, why do I use airtunes? Two reasons. First, when ever I would pull the plug to move my laptop I'd get some harsh cracking and feedback. Secondly, it allows me to control the speakers volume from my iTunes dashboard widget and still have my computer alert sounds decoupled from that. When I am on the phone, I tend to turn down my tunes, but I still want to hear the alerts.</p>


	<p>Also, when in bridging mode, the Express offers an ethernet port with access to the wireless. So the old *nix box has 100mb to the wireless via a switch. No need to pull cables. Neat-O!</p>


	<p>Long way of saying, problem solved!</p>