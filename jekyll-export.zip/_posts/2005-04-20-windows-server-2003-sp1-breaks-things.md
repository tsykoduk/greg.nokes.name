---
id: 293
title: Windows Server 2003 SP1 breaks things
date: 2005-04-20T15:57:42+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/windows-server-2003-sp1-breaks-things
permalink: /2005/04/20/windows-server-2003-sp1-breaks-things/
categories:
  - Computers! and Code!
---
<blockquote><a href="http://www.eweek.com/article2/0,1759,1788008,00.asp">eWeek</a> reports: "The first reports from users installing Windows Server 2003 Service Pack 1 are in. And as was the case with its client counterpartâ€”Windows XP Service Pack 2â€”the latest <em>Windows Server service pack breaks several key Microsoft and third-party applications</em>. <span class="caps">SP1</span> (Service Pack 1) is primarily a security update. But as was the case with <span class="caps">XP SP2</span> (Service Pack 2), Windows Server 2003 <span class="caps">SP1</span> also will include some brand-new features."</blockquote>

		<p>Well, duh!</p>