---
id: 434
title: John 3:16 offensive
date: 2005-05-19T08:49:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/john-3-16-offensive
permalink: /2005/05/19/john-3-16-offensive/
categories:
  - Philosophy! and Politics!
---
<blockquote><span class="caps">OLYMPIA</span>-The Department of Licensing's Personalized Plate Review Committee today dismissed a complaint against a vanity plate with the message "JOHN316."

		<p>A complaint was filed against this vanity plate in April. This complaint triggered a routine review process the department conducts whenever a complaint is received.</blockquote></p>


		<p>From the <a href="http://access.wa.gov/news/2005/May/n2005417_6164.aspx">Washington State Goverment</a></p>


		<p>Ok - I just heard this on <span class="caps">NPR</span> durning my drive in. The story is that someone saw this vanity plate and was 'offended' by it.</p>


		<p>Now, I support seperation of church and state - I do not think that it is correct to force children to mouth platitudes to a God that they might or might not belive in, but..</p>


		<p>Come on! The person that filed the complaint cannot have been serious. Having a personally choosen vanity plate that espouses a religous preference on a car cannot be seen as the state supporting any religious preference. It's the person's choice what goes on those plates. Each person has the right to worship as they see fit. It's pretty simple folks!</p>