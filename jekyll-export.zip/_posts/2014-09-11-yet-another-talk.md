---
id: 15597
title: Yet Another Talk
date: 2014-09-11T16:34:01+00:00
author: Greg Nokes
layout: post
guid: http://greg.nokes.name/?p=15597
permalink: /2014/09/11/yet-another-talk/
categories:
  - Computers! and Code!
---
I was pressed into service to do a training on Heroku for about 300 developers. It was a fun experience, and I really like to go back and watch myself so that I can critique my performance. Hopefully improve as well.

The second half is  a demo of a loyalty app by by <a href="https://twitter.com/AbePursell" target="_blank">@AbePursell</a>. The app was built using <a href="http://heroku.com">Heroku</a> and <a href="http://salesforce.com">Force</a>.

[embed]http://vimeo.com/102756160[/embed]

&nbsp;