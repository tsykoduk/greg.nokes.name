---
id: 66
title: 'Craziness: Back to the governor thing&#8230;'
date: 2005-01-04T22:06:22+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/craziness-back-to-the-governor-thing
permalink: /2005/01/04/craziness-back-to-the-governor-thing/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://emilyscraziness.blogspot.com/2005/01/back-to-governor-thing.html">emily</a> has this to say<br /><br />"<i>...Personally, I think that the fact that the results have been changed and victory has been declared over 120-something votes (after people criticizing a so-called victory of 420 votes) is a little out-of-whack. If you still care (and are a voter for WA), you can find the petition for a re-vote <a href=http://www.revotewa.com/petition.htm>here</a>. I don't have time at the moment for a longer post than this. Later!</i>"<br /><br />Can't agree more. Click on through, nothing to see here citizen.<br /><br />-Tsyko<br /></p>