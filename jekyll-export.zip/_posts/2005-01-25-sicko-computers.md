---
id: 19
title: 'Sicko Computers&#8230;'
date: 2005-01-25T08:55:13+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/sicko-computers
permalink: /2005/01/25/sicko-computers/
categories:
  - Computers! and Code!
---
<center><a href=http://www.webroot.com/products/spysweeper-indepth?rc=1752&#38;rsc=tech2&#38;ac=lr004><img src="http://images.usatoday.com/sponsors/2005/webroot/jan_/ss_usatoday-300x250.gif"/></a></center><br /><br />Ok... let's do the math.<br /><br />It is commonly held that Microsoft Windows has about 90% of the market share on PC's. If we are to belive the advert, 9 out of 10 computers are infested with spyware. <br /><br />That's about 90%.<br /><br />Hmm...<br /><br /><br /><br />