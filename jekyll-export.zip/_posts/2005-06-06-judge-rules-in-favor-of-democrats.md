---
id: 505
title: Judge rules in favor of Democrats
date: 2005-06-06T11:18:27+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/judge-rules-in-favor-of-democrats
permalink: /2005/06/06/judge-rules-in-favor-of-democrats/
categories:
  - Philosophy! and Politics!
---
<blockquote><span class="caps">WENATCHEE</span> , A Chelan County Superior Court judge today said that despite evidence of numerous election errors, Republicans failed to prove those errors cost their candidate the race.

		<p>Gov. Christine Gregoire's narrow win over Republican Dino Rossi stands, the judge ruled.</p>


		<p>'Irregularity ... is not sufficient to invalidate an election,â€ Judge John Bridges said, who was flanked by two sheriff's deputies as he read his lengthy ruling.</p>


		<p>There is no evidence that ballots were changed or that, as Republicans maintained, ballot boxes were 'stuffed,â€ he explained. 'Unless an election is clearly invalid, when the people have spoken, their verdict should not be disturbed by the courts,â€ he added.  </blockquote></p>


		<p>From the <a href="http://www.spokesmanreview.com/breaking/story.asp?submitDate=20056695639">Spokesman</a></p>