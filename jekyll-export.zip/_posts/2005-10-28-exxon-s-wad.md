---
id: 996
title: 'Exxon&#039;s Wad'
date: 2005-10-28T07:49:35+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/exxon-s-wad
permalink: /2005/10/28/exxon-s-wad/
categories:
  - Philosophy! and Politics!
---
<blockquote>More than a billion dollars a day, $45 million an hour, almost $340 for every living American â€” that's what Exxon Mobil reported in third-quarter revenue Thursday.

	<p>For the oil giant, that translated to $9.9 billion in net income.</blockquote></p>


	<p>-<a href="http://seattletimes.nwsource.com/html/businesstecinexpensive.hnology/2002588325_oilearns28.html">Seattle Times</a></p>


	<p>They must have made so much money because Oil prices were so high, they just had to raise the prices of their gas.</p>


	<p>Now, I do not begrudge them these high profits. We are in a sellers market when it comes to fuel - there are limited ways to get it, and we all need it. That is why we must start to depend on fossil fuels less, and start to invest in ways to make ourselves independent of other countries and oil conglomerates whims.</p>


	<p>I hope that the last years events have shown that, when we can, energy production should be as close to the energy users as possible, clean and inexpensive. We can do this, we just need to make it happen. They Spokane biofuels plant that is being planned is a good start. Nuclear power stations through out the country are another good start.</p>