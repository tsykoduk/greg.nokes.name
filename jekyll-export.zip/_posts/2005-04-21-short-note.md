---
id: 297
title: Short note
date: 2005-04-21T22:23:20+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/short-note
permalink: /2005/04/21/short-note/
categories:
  - Fun!
---
<p>You just <span class="caps">HAVE</span> to check this <a href="http://porktornado.diaryland.com/albumcover.html">post</a> out. Go! Read! Gasp in Horror! Come back and Comment!</p>