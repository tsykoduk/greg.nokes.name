---
id: 1245
title: A Muslim on Hatred
date: 2006-02-15T16:26:23+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-muslim-on-hatred
permalink: /2006/02/15/a-muslim-on-hatred/
categories:
  - Philosophy! and Politics!
---
<blockquote>The controversy regarding the Danish cartoons of the Prophet Mohammed completely misses the point. Of course, the cartoons are offensive to Muslims, but newspaper cartoons do not warrant the burning of buildings and the killing of innocent people. The cartoons did not cause the disease of hate that we are seeing in the Muslim world on our television screens at night - they are only a symptom of a far greater disease.</blockquote>
-<span class="storyhead">  <a href="http://www.portal.telegraph.co.uk/opinion/main.jhtml?xml=/opinion/2006/02/12/do1205.xml&#38;sSheet=/opinion/2006/02/12/ixop.html">We were brought up to hate - and we do</a>, by </span><a href="http://www.noniedarwish.com/pages/745434/"><span class="storyby">Nonie Darwish</span></a>

	<p>A good read.</p>


	<p>Only by spreading the meme of Love will we overcome this current disease of hatred. I know that sounds really hokey - but it's true. Killing them only makes their resolve stronger. Killing us only makes our resolve stronger. The weapons are not bullets and bombs but rather are hate filled minds. Only by defusing those weapons will we ever win this war.</p>


	<p>The West cannot do it. Only the Muslim world can do it. Let's hope that the moderates can prevail. I hate to think what will happen if they do not.</p>