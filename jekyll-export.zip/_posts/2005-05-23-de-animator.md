---
id: 453
title: De-Animator
date: 2005-05-23T07:59:54+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/de-animator
permalink: /2005/05/23/de-animator/
categories:
  - Fun!
---
<p>The <a href="https://gmail.google.com/gmail">Daily Illuminator</a> says:</p>


	<blockquote>Flash games are good. Shooting zombies is good. This <a href="http://artscool.cfa.cmu.edu:16080/~lee/deanimator.html">game</a> would therefore seem to have more than its fair share of goodness.</blockquote>

		<p>In fact the entire site is pretty cool.</p>