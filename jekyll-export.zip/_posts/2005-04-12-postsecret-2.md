---
id: 257
title: PostSecret
date: 2005-04-12T11:00:27+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/postsecret-2
permalink: /2005/04/12/postsecret-2/
categories:
  - Philosophy! and Politics!
---
<p>I heard about this <a href="http://postsecret.blogspot.com/">site</a> on <span class="caps">NPR</span> a few days ago, and then promptly forgot about it. <a href="http://poorrolemodel.blogspot.com/2005/04/have-you-seen-this-one.html#comments">Poor Role Model</a> posted about it - and I went to the site. Very powerful stuff.</p>