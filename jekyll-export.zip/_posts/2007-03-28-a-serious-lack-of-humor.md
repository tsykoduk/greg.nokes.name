---
id: 2249
title: 'A serious lack of humor&#8230;'
date: 2007-03-28T14:09:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/a-serious-lack-of-humor
permalink: /2007/03/28/a-serious-lack-of-humor/
categories:
  - Computers! and Code!
  - Fun!
---
<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/WAAb6ghEOdo"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/WAAb6ghEOdo" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>

	<p>Nothing to say about this one....</p>