---
id: 8332
title: Interview with a reformed adware programmer
date: 2009-01-30T17:20:00+00:00
author: tsykoduk
layout: post
guid: 30/2009/01/30/interview-with-a-reformed-adware-programmer
permalink: /2009/01/30/interview-with-a-reformed-adware-programmer/
categories:
  - Computers! and Code!
---
<blockquote>I should probably first speak about how adware works. Most adware targets Internet Explorer (IE) users because obviously they're the biggest share of the market. In addition, they tend to be the less-savvy chunk of the market. If you're using IE, then either you don't care or you don't know about all the vulnerabilities that IE has.</blockquote>

            <!--more-->

            <p><a href="http://www.schneier.com/blog/archives/2006/08/bruce_schneier.html">Bruce</a> has a <a href="http://www.schneier.com/blog/archives/2009/01/interview_with_10.html">link</a> to a great <a href="http://philosecurity.org/2009/01/12/interview-with-an-adware-author">article</a> this morning. Good read. My most jucy bit:</p>


<blockquote>S: In your professional opinion, how can people avoid adware?

	<p>M: Um, run <span class="caps">UNIX</span>.</p>


	<p>S: [ laughs]</p>


	<p>M: We did actually get the ad client working under Wine on Linux.</p>


	<p>S: That seems like a bit of a stretch!</p>


	<p>M: That was a pretty limited market, I’d say</blockquote></p>