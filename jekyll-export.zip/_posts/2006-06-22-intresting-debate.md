---
id: 1426
title: Intresting debate
date: 2006-06-22T05:50:22+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/intresting-debate
permalink: /2006/06/22/intresting-debate/
categories:
  - Philosophy! and Politics!
---
<center><object width="425" height="350">
<param name="movie" value="http://www.youtube.com/v/TkLxVgXSveA" /></object></center>(HT: <em><a href="http://beginaneweachday.blogspot.com/2006/06/i-heart-jon-stewart.html#comments">Agent Sierra</a> </em>)