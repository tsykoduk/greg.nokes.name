---
id: 1561
title: God loves Lexus
date: 2006-11-03T02:56:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/god-loves-lexus
permalink: /2006/11/03/god-loves-lexus/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<blockquote>And there you have it. Proof of God. Proof that God, clearly, has a wicked sense of humor. Proof that God drinks far, far more heavily than you. Proof that God sees the deep irony of life, and war, and oil, cars, cognac, parking spaces, everything, and laughs demonically. There is simply no other explanation.</blockquote>

	<p>-<a href="http://sfgate.com/cgi-bin/article.cgi?f=/gate/archive/2006/10/27/notes102706.DTL&#38;nl=fix">Mark Morford</a></p>


	<p>Mark makes a great argument for the existence of God - and one who drinks heavily. Now, there's a God that I could get behind!</p>


<blockquote>
	<p>hick&lt;</p>

</blockquote>