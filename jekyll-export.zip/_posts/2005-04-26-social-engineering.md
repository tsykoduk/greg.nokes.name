---
id: 352
title: Social Engineering
date: 2005-04-26T16:42:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/social-engineering
permalink: /2005/04/26/social-engineering/
categories:
  - Fun!
---
<p>The <a href="http://geekwitha45.blogspot.com/2005_04_17_geekwitha45_archive.html#111430965367547420"> GeekWithA.45</a> talks about his run in with Best Buy:</p>


	<blockquote>Here's a rough transcript of my interaction with the cashier &#38; subsequent managers:

		<p>Chipper Teenage Cashier Girl: "May I have your phone number?"</p>


		<p>This is common enough at a lot of places. Retailers want keys to link together purchases, and can mine a lot of information on buying trends and purchase patterns if they can define a household in a granular manner. This is also the purpose behind most grocery store discount cards. For the most part, this is a fairly benign activity, requiring the voluntary cooperation of the consumer. It's also an activity that I routinely decline to participate in.</p>


		<p>Me {out of long habit}: "Nope. I don't give that out."</p>


		<p><span class="caps">CTCG</span>: "Uh...the cash register says I have to get your address for this product."</p>


		<p>Me: {knowing that satellite radio needs a subscription, and thinking this would set me up on the spot} Ok, That's G-e-e-k W-i-t-h...uh, this signs me for the subscription, right?</p>


		<p><span class="caps">CTCG</span>: "Uh, no, it's just for our records..."</p>


		<p>Me: {a slight frost creeping into my voice} "Then you don't need it."</blockquote></p>


		<p>Hmm.. here is an easier method. Find the phone number for Best Buy. Give them that one. Works great, and has the added benifit of messing with their systems.</p>


		<p>The poor, undertrained teenyboppers that work at these places do not make the rules - so just give them what they think they need and move on. :)</p>


		<p>Hat tip <a href="http://sandcastlesandcubicles.blogspot.com/2005/04/trends-in-marketing.html">Cube</a> and <a href="http://geekwitha45.blogspot.com/2005_04_17_geekwitha45_archive.html#111430965367547420">GeekWithA.45</a></p>