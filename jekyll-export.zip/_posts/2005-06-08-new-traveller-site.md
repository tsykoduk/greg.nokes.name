---
id: 517
title: New Traveller Site
date: 2005-06-08T14:34:16+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-traveller-site
permalink: /2005/06/08/new-traveller-site/
categories:
  - Fun!
---
<p>One of my hobbies is <a href="http://www.sjgames.com/gurps/traveller/">Traveller.</a> So, imagine my glee when I was able to help set up a new site for a <a href="http://www.travellerrpg.com/">Traveller</a> Fanzine - <a href="http://stellarreaches.nwgamers.org">Stellar Reaches</a>. If you are a <a href="http://www.farfuture.net/">Traveller</a> Geek - you really should check it out!</p>