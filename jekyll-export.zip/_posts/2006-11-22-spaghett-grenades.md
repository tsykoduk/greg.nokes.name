---
id: 1605
title: Spaghetti Grenades
date: 2006-11-22T19:38:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/spaghett-grenades
permalink: /2006/11/22/spaghett-grenades/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<blockquote>You think this is silly, and it is, but a week ago my mother caused a small commotion at a checkpoint at Boston-Logan after screeners discovered a large container of homemade tomato sauce in her bag. What with the preponderance of spaghetti grenades and lasagna bombs, we can all be proud of their vigilance. And, as a liquid, tomato sauce is in clear violation of the Transportation Security Administration's carry-on statutes. But this time, there was a wrinkle: The sauce was frozen.

	<p>No longer in its liquid state, the sauce had the guards in a scramble. According to my mother's account, a supervisor was called over to help assess the situation. He spent several moments stroking his chin. "He struck me as the type of person who spent most of his life traveling with the circus," says Mom, who never pulls a punch, "and was only vaguely familiar with the concept of refrigeration." Nonetheless, drawing from his experiences in grade-school chemistry and at the <span class="caps">TSA</span> academy, he sized things up. "It's not a liquid right now," he observantly noted. "But it will be soon."</blockquote></p>


	<p>-<a href="http://www.schneier.com/blog/archives/2006/11/tsa_security_ro_1.html">Bruce Schneier</a></p>


	<p>There are things that we can do to make us safer. This is <b>not</b> one of them.</p>