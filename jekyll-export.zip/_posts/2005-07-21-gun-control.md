---
id: 679
title: Gun Control?
date: 2005-07-21T08:52:54+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/gun-control
permalink: /2005/07/21/gun-control/
categories:
  - Fun!
---
<p><a href="http://www.photosig.com/go/photos/view?id=1570120&#38;forward=">Check</a> this out.</p>


		<p>(Hat Tip: <a href="http://sharpmarbles.stufftoread.com/archive/2005/07/21/3658.aspx">SaaM</a>)</p>