---
id: 1459
title: You can Do It!
date: 2006-09-17T12:16:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/you-can-do-it
permalink: /2006/09/17/you-can-do-it/
categories:
  - Computers! and Code!
---
<p><a href="http://www.ubuntulinux.org">Ubuntu Linux</a> is looking for your help. Even if you do not use Linux for what ever reason, they want to know. They have posted a quick and easy <a href="http://surveys.geekosophical.net/">survey</a> for you to take about Operating Systems. Go - tell them what's wrong with Linux and let's give Microsoft a real competitor on the desktop!</p>


	<p>Drop a line here with your thoughts on the survey and we will bat it about.</p>