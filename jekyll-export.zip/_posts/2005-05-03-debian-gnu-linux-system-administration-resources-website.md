---
id: 385
title: Debian GNU/Linux System Administration Resources Website
date: 2005-05-03T13:15:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/debian-gnu-linux-system-administration-resources-website
permalink: /2005/05/03/debian-gnu-linux-system-administration-resources-website/
categories:
  - Computers! and Code!
---
<p>The <a href="http://www.debian-administration.org/">Debian <span class="caps">GNU</span>/Linux System Administration Resources</a> website is a pretty good resource for all of you Debian Geeks out there. It has a bunch of Howtos, Whytos, and other intresting articles. Go, check it out!</p>