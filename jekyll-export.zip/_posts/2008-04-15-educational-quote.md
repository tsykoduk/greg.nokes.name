---
id: 7145
title: Educational Quote
date: 2008-04-15T17:48:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/educational-quote
permalink: /2008/04/15/educational-quote/
categories:
  - Computers! and Code!
  - Fun!
---
<blockquote>sterano: Whats the difference between Raid_0 and Raid_1?<br />
Steve: In Raid_0 the zero stands for how many files you are going to get back if something goes wrong.<br /></blockquote>

	<p>(From <a href="http://bash.org/?854608"><span class="caps">QDB</span></a>)</p>