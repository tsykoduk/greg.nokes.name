---
id: 103
title: 'Strange things afoot&#8230;'
date: 2005-02-10T21:31:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/strange-things-afoot
permalink: /2005/02/10/strange-things-afoot/
categories:
  - Fun!
---
<p>In this weeks <a href=http://www.sjgames.com/ill/archives.html?m=February&#38;y=2005&#38;d=4>Daily Illuminator</a> you are pointed to the <a href=http://web.archive.org/web/20031013040651/http://truthtrek.net/olyphant/olyphant1.htm>Secret of Olyphant</a>. If nothing else, it's an entertaining read.<br /><br />Or so <b>they</b> would have you belive....<br /><br />Muhahahahahaaaaaaa <del>click</del></p>