---
id: 412
title: Quotes from The Big E
date: 2005-05-06T15:56:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/quotes-from-the-big-e
permalink: /2005/05/06/quotes-from-the-big-e/
categories:
  - Philosophy! and Politics!
---
<blockquote>The mystical trend of our time, which shows itself particularly in the rampant growth of the so-called Theosophy and Spiritualism, is for me no more than a symptom of weakness and confusion. Since our inner experiences consist of reproductions, and combinations of sensory impressions, the concept of a soul without a body seem to me to be empty and devoid of meaning.</blockquote>

	<blockquote>I have repeatedly said that in my opinion the idea of a personal God is a childlike one, but I do not share the crusading spirit of the professional atheist whose fervor is mostly due to a painful act of liberation from the fetters of religious indoctrination received in youth. I prefer an attitude of humility corresponding to the weakness of our intellectual understanding of nature and of our own being. </blockquote>

	<blockquote>A man's ethical behavior should be based effectually on sympathy, education, and social ties and needs; no religious basis is necessary. Man would indeed be in a poor way if he had to be restrained by fear of punishment and hope of reward after death.</blockquote>

		<p>and</p>


	<blockquote>The religion of the future will be a cosmic religion. It should transcend personal God and avoid dogma and theology. Covering both the natural and the spiritual, it should be based on a religious sense arising from the experience of all things natural and spiritual as a meaningful unity. Buddhism answers this description. If there is any religion that could cope with modern scientific needs it would be Buddhism.</blockquote>

		<p>All of these from ol' Albert Einstein himself.</p>