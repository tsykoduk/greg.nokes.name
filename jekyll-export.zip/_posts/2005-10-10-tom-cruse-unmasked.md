---
id: 962
title: Tom Cruse Unmasked!
date: 2005-10-10T22:04:36+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/tom-cruse-unmasked
permalink: /2005/10/10/tom-cruse-unmasked/
categories:
  - Fun!
---
<p>Little did we know that Tom Cruse is none other then...</p>


	<p>Darth Stupedus!</p>


	<p>Yup. It happened on <a href="http://www.nwgamers.org/Tom_Cruise_Kills_Oprah.mov">Oprah</a>.</p>


	<p>(HT - That <a href="http://drogidy.blogspot.com/2005/10/where-martians-and-wookies-collide.html">Drogitty</a> Fellow)</p>


	<p>Also on his site, a link to this gem:</p>


<center><a href="http://adrune.blogs.friendster.com/photos/my_favorite_movies/index.html"><img src="http://adrune.blogs.friendster.com/photos/my_favorite_movies/pimpmyride.jpg" /></a></center>