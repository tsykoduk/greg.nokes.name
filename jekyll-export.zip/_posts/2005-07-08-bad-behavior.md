---
id: 638
title: Bad Behavior
date: 2005-07-08T13:50:10+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bad-behavior
permalink: /2005/07/08/bad-behavior/
categories:
  - Computers! and Code!
---
<p>Just installed a Wordpress Plugin called <a href="http://www.ioerror.us/software/bad-behavior/">Bad Behavior</a>. Impressive stuff. It blocked over 425 spam-bots/comment spams and other evil little things in 24 hours. Woot!</p>