---
id: 984
title: And one post in darkness to bind them
date: 2005-10-23T22:44:33+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/and-one-post-in-darkness-to-bind-them
permalink: /2005/10/23/and-one-post-in-darkness-to-bind-them/
categories:
  - Fun!
---
<p>Ok.. the entire blogosphere has just been summed up in one (yes <strong>one</strong>) <a href="http://chieflymusing.com/?p=134">post</a>.</p>


	<p>(HT - <a href="http://sharpmarbles.stufftoread.com/archive/2005/10/21/4126.aspx">SaaM</a>)</p>