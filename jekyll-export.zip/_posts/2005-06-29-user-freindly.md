---
id: 588
title: User Freindly
date: 2005-06-29T09:24:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/user-freindly
permalink: /2005/06/29/user-freindly/
categories:
  - Fun!
---
<center><a href="http://ars.userfriendly.org/cartoons/?id=20050629"><img src="http://www.userfriendly.org/cartoons/archives/05jun/uf008049.gif" alt="User Freindly"  width="180" /></a></center>

		<p>Ok, so if you do not read User Freindly, you should. Go there now. Spend Money. Revel in the glory that is UF.</p>