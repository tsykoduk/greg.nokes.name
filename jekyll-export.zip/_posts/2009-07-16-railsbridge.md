---
id: 15130
title: RailsBridge
date: 2009-07-16T16:57:19+00:00
author: tsykoduk
layout: post
guid: http://greg.nokes.name/?p=15130
permalink: /2009/07/16/railsbridge/
categories:
  - Computers! and Code!
  - Mundane
  - Philosophy! and Politics!
---
On of the tasks that I have undertaken is helping out a non-profit called <a href="http://railsbridge.org">Railsbridge</a> by increasing community awareness. They do a ton of really cool things - like Rails Workshops for Women (one upcoming in <a href="http://www.sarahmei.com/blog/2009/07/06/julyaugust-ruby-workshop-registration-open/">San Francisco</a>!), <a href="http://railsmentors.org/">Rails Mentoring</a>, <a href="http://teachingkids.railsbridge.org/">Student Code Reviews</a>, and undertaking <a href="http://builders.railsbridge.org/">development efforts</a> for worthy Non Profit organizations.

So, stay tuned - good stuff is going to come of this little project. We tend to hang out in #railsbridge on freenode, so if you want to learn more, or you want to see more, head on over, and I'll see you there!