---
id: 512
title: With no fanfare
date: 2005-06-07T10:51:32+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/with-no-fanfare
permalink: /2005/06/07/with-no-fanfare/
categories:
  - Computers! and Code!
---
<blockquote>The latest stable release of Debian is 3.1. The last update to this release was made on June 6th, 2005. </blockquote>

		<p>Run - don't walk, and get it <a href="http://www.debian.org/distrib/">here</a>!</p>