---
id: 211
title: Addicted, I tell ya!
date: 2005-04-07T11:53:26+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/addicted-i-tell-ya
permalink: /2005/04/07/addicted-i-tell-ya/
categories:
  - Fun!
---
<center><table width=400 align=center border=1 bordercolor=black cellspacing=0 cellpadding=2>
<tr><td bgcolor=#66CCFF align=center>
<font face="Georgia, Times New Roman, Times, serif" style='color:black; font-size: 14pt;'>
<b>You Are Best Described By...</b></font></td></tr>
<tr><td bgcolor=#FFFFFF>

<center>
<img src="http://www.quizdiva.net/bt/peaceful.jpg"/>
</center>

<font color="#000000">

<center>
Meditative Rose

By Salvadore Dali</center>
</font></td></tr></table>

<div align="center">
<a href="http://www.blogthings.com/whatfamousartareyouquiz/">What Famous Work of Art Are You?</a>
</div></center>

	<p>Hat Tip <a href="http://emilyscraziness.blogspot.com">The Quizzer</a></p>