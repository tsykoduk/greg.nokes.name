---
id: 2228
title: Lily Allen
date: 2007-03-13T06:01:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/lily-allen
permalink: /2007/03/13/lily-allen/
categories:
  - Fun!
---
<p>I kinda have a thing for Lily Allen - a new British pop sensation. Well, I guess that the makers of the <span class="caps">SIMS</span> like her tuneage as well... so they did this..</p>


<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/NJ89IgLCM0k"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/NJ89IgLCM0k" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>

	<p>You must check out the original as well... so here it is.</p>


<object width="425" height="350"><param name="movie" value="http://www.youtube.com/v/HZyTOROlo9E"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/HZyTOROlo9E" type="application/x-shockwave-flash" wmode="transparent" width="425" height="350"></embed></object>