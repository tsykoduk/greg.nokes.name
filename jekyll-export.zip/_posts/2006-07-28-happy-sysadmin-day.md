---
id: 1439
title: Happy sysadmin day!
date: 2006-07-28T08:04:13+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/happy-sysadmin-day
permalink: /2006/07/28/happy-sysadmin-day/
categories:
  - Mundane
---
<p>Yup - it's that time of year <a href="http://www.ukuug.org/sysadminday/">Again</a>!</p>


	<p>Remeber to buy your sysadmin some presents (iPods, <i>good</i> Chinese Food, geeky toys all accepted) or s/he will turn into <a href="http://bofh.ntk.net/Bastard1.html">the</a> <a href="http://www.theregister.co.uk/odds/bofh"><span class="caps">BOFH</span></a>!</p>