---
id: 1427
title: Cool stuff!
date: 2006-06-22T21:25:16+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/cool-stuff
permalink: /2006/06/22/cool-stuff/
categories:
  - Fun!
  - Science!
---
<p><a href="http://www.thebanmappingproject.com/">The Theban Mapping Project</a> has some really cool maps and 3d walk throughs of the tombs in Thebes and the Valley of the Kings.</p>


<blockquote>Since its inception in 1978, the Theban Mapping Project (TMP, now based at the American University in Cairo) has been working to prepare a comprehensive archaeological database of Thebes. With its thousands of tombs and temples, Thebes is one of the world's most important archaeological zones. Sadly, however, it has not fared well over the years. Treasure-hunters and curio-seekers plundered it in the past; pollution, rising ground water, and mass-tourism threaten it in the present. Even early archaeologists destroyed valuable information in their search for museum-quality pieces.</blockquote>

	<p>I just blew about an hour there. :)</p>