---
id: 1374
title: Conestoga!
date: 2006-05-09T12:04:19+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/conestoga
permalink: /2006/05/09/conestoga/
categories:
  - Fun!
---
<p>Music video after the jump...</p>


	<p>&lt;!<del>-more</del>-&gt;</p>


<center><a href="http://www.tomsmithonline.com"><object width="550" height="400">
<param name="movie" value="http://www.tomsmithonline.com/freestuff/viddio/sja2.swf">
<embed src="http://www.tomsmithonline.com/freestuff/viddio/sja2.swf" width="550" height="400">
</embed>
</param></object></a></center>