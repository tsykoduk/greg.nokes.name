---
id: 3003
title: The King is dead, long live the King
date: 2007-11-29T06:28:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/the-king-is-dead-long-live-the-king
permalink: /2007/11/29/the-king-is-dead-long-live-the-king/
categories:
  - Computers! and Code!
---
<p>So, with this <a href="http://weblog.rubyonrails.com/2007/11/29/rails-2-0-release-candidate-2">article</a>, Rails 2.0 is almost on us.</p>


	<p>I am starting a new F/OSS project as basically the lead developer (until we get some one better). I had about 2 or 3 hours of work into it, found this article, and decided to scrap all of the work and build with rails 2.</p>


	<p>I plan on documenting the changes and cool things that I find here...</p>