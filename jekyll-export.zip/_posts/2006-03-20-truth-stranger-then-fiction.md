---
id: 1318
title: Truth stranger then fiction?
date: 2006-03-20T21:10:15+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/truth-stranger-then-fiction
permalink: /2006/03/20/truth-stranger-then-fiction/
categories:
  - Philosophy! and Politics!
---
<blockquote>An Afghan man who recently admitted he converted to Christianity faces the death penalty under the country's strict Islamic legal system... Prosecuting attorney Abdul Wasi told the judge that the punishment should fit the crime. He says Rahman is a traitor to Islam and is like a cancer inside Afghanistan. Under Islamic law and under the Afghan constitution, he says, the defendant should be executed.</blockquote>
-<a href="http://www.voanews.com/english/2006-03-18-voa7.cfm"><span class="caps">VOA</span> News</a> and <a href="http://news.google.com/news?hl=en&#38;ned=us&#38;ie=UTF-8&#38;ncl=http://www.voanews.com/english/2006-03-18-voa7.cfm">others</a>

	<p>I just wanted to get this story out. It's things like this that make me fear 'us vs them' and black and white thinking.</p>