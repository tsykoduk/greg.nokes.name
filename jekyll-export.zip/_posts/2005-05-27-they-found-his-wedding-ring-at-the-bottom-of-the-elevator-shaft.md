---
id: 482
title: They found his wedding ring at the bottom of the elevator shaft
date: 2005-05-27T14:20:22+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/they-found-his-wedding-ring-at-the-bottom-of-the-elevator-shaft
permalink: /2005/05/27/they-found-his-wedding-ring-at-the-bottom-of-the-elevator-shaft/
categories:
  - Fun!
---
<p>Jesster had a <a href="http://poorrolemodel.blogspot.com/2005/05/theres-good-story-in-there.html">'thing'</a> on her site this morning. This is the result. Cliched. I know. :)</p>


	<hr />


		<p>Dan was fidgeting in the chair as he waited for the conference room to clear up. He had the pastries that he usually brought to the IT meetings sitting next to him. He drew a mouthful of coffee.</p>


		<p>As the 9 am meeting let out, he saw Jesster walking away with some of her people. He got up, straightened his shirt, grabbed the box of goodies and went into the room. Booting the laptop, he logged in and got his presentation ready.</p>


		<p>As soon as all of the members of the meeting arrived, the doors shut and he began.</p>


		<p>'So, in closing, we really need to move to Reiser4 for our data volumesâ€ and he sat down.</p>


		<p>Over the next half hour, the meeting droned on. It was a normal corporate knife fight over new technology implementation. He really tried to remain involved, however he simply could not.</p>


		<p>His eyes snapped open, and he looked around. Still in the meeting, and no one was looking at him. He could not believe that he had fallen asleep.</p>


		<p>'Dan, what do you think about using the Nuclear Option on the Chinese book trade?â€</p>


		<p>He focused on the questioner, a suit from the office in New York. 'Um, I guess I do not understand the question?â€</p>


		<p>'It's simple , do we deploy our tactical nuclear weapons on the border with Chile to stop the Chinese book boot leggers?â€</p>


		<p>'I am sorry, but I really have no idea what you are talking aboutâ€</p>


		<p>'What the hell? Did you just sleep through the last four hours of meeting?â€</p>


		<p>'Well, um..â€ The suit pulled out a handgun and fired it. Dan looked down at his chest, blood staining his shirt. 'Oh.. Oh.. Godâ€</p>


		<p>His eyes snapped open. His hand moved to his chest</p>


		<p><em>Thank god, it's dry. It must have just been a dream</em></p>


		<p>He scanned the room. Nothing. No one even noticed that he had been asleep. Their discussion was centered on standards for the data center. No weapons of mass destruction. Sighing with relief, he grabbed his paper coffee cup. He gasped with pain as the paper disintegrated spilling a glowing golden liquid on his hand.</p>


		<p>Screaming in pain, Dan jumped up, watching in horror as his hand started to melt away.</p>


		<p>His eyes snapped open. The conversation droned on about file system standards. Panic began to well in his hind brain as the reality of what might be happening to him sunk in.</p>


		<p>The floor shook under his feet. He looked out the window, and saw a 747 fly past.</p>


		<p>'But we're on the third floor!â€</p>


		<p>His eyes snapped open.</p>


		<p>His eyes snapped open.</p>


		<p>His eyes snapped open.</p>


		<p>The Police officer spoke into the phone, 'That's correct Captain. The only thing left was the wedding ring at the bottom of the elevator shaft.â€</p>