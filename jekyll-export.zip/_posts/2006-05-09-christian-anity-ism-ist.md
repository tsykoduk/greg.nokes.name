---
id: 1376
title: Christian -anity -ism -ist?
date: 2006-05-09T16:06:22+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/christian-anity-ism-ist
permalink: /2006/05/09/christian-anity-ism-ist/
categories:
  - Philosophy! and Politics!
---
<blockquote>Are you a Christian who doesn't feel represented by the religious right? I know the feeling. When the discourse about faith is dominated by political fundamentalists and social conservatives, many others begin to feel as if their religion has been taken away from them.

	<p>The number of Christians misrepresented by the Christian right is many. There are evangelical Protestants who believe strongly that Christianity should not get too close to the corrupting allure of government power. There are lay Catholics who, while personally devout, are socially liberal on issues like contraception, gay rights, women's equality and a multi-faith society. There are very orthodox believers who nonetheless respect the freedom and conscience of others as part of their core understanding of what being a Christian is. They have no problem living next to an atheist or a gay couple or a single mother or people whose views on the meaning of life are utterly alien to them-and respecting their neighbors' choices. That doesn't threaten their faith. Sometimes the contrast helps them understand their own faith better.</blockquote></p>


	<p><a href="http://www.time.com/time/magazine/printout/0,8816,1191826,00.html">Andrew Sullivan</a> has showed why he gets paid to write and I do not. Read the article, I found it fascinating.</p>