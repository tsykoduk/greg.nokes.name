---
id: 62
title: 'Justus for All: Necromancy in Washington'
date: 2005-01-08T17:04:21+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/justus-for-all-necromancy-in-washington
permalink: /2005/01/08/justus-for-all-necromancy-in-washington/
categories:
  - Philosophy! and Politics!
---
<p><a href="http://davejustus.blogspot.com/2005/01/necromancy-in-washington.html">Read This</a>. Just go and read it.<br /><br />Personally I am on my way to Sportsman's Were-house to grab a pump-action 12 gague. In all the movies, the guys with the shotguns last the longest.</p>