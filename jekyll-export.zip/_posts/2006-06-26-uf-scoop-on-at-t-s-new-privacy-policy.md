---
id: 1430
title: 'UF scoop on AT&amp;T&#039;s new privacy policy'
date: 2006-06-26T17:35:18+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/uf-scoop-on-at-t-s-new-privacy-policy
permalink: /2006/06/26/uf-scoop-on-at-t-s-new-privacy-policy/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p><a href="http://ars.userfriendly.org/cartoons/?id=20060625"><img src="http://www.userfriendly.org/cartoons/archives/06jun/uf009225.gif" width="500" /></a></p>