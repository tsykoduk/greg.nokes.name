---
id: 694
title: 'My &#039;Humor Index&#039;'
date: 2005-07-27T20:02:37+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/my-humor-index
permalink: /2005/07/27/my-humor-index/
categories:
  - Fun!
---
<p><table align="center" cellpadding="20"> <tbody><tr><td align="center"> <font size="5"><b>the Wit</b></font><br /> <center><font size="1">(56% dark, 39% spontaneous, 33% vulgar)</font></center> </td></tr><tr><td> <center>your humor style:<br /><b><span class="caps">CLEAN</span></b> | <b><span class="caps">COMPLEX</span></b> | <b><span class="caps">DARK</span></b></center>
	<br /><br />
	You like things edgy, subtle, and smart. I guess that means you're probably an intellectual, but don't take that  to mean you're pretentious. You realize 'dumb' can be witty-<del>after all isn't that the Simpsons' philosophy?</del>-but  rudeness for its own sake, 'gross-out' humor and most other things found in a fraternity leave you totally flat. <br /><br />I  guess you just have a more cerebral approach than most. You have the perfect mindset for a joke writer or staff  writer. Your sense of humor takes the most effort to appreciate, but it's also the best, in my opinion.</td></tr></tbody></table></p>


		<p>Take it <a href="http://www.okcupid.com/tests/take?testid=17565214125862764376">here</a></p>


		<p>Hat tip - <a href="http://integralpractice.blogharbor.com/blog">Integral Practice</a> and others...</p>