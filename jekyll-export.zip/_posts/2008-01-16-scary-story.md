---
id: 3102
title: Scary Story
date: 2008-01-16T04:39:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/scary-story
permalink: /2008/01/16/scary-story/
categories:
  - Philosophy! and Politics!
---
<blockquote>"I have opponents in this race who do not want to change the Constitution," Huckabee told a Michigan audience on Monday. "But I believe it's a lot easier to change the Constitution than it would be to change the word of the living god. And that's what we need to do -  to amend the Constitution so it's in God's standards rather than try to change God's standards so it lines up with some contemporary view."</blockquote>
—<a href="http://rawstory.com/news/2007/Huckabee_Amend_Constitution_to_meet_Gods_0115.html">Mike Huckabee</a>