---
id: 17
title: Windows viruses under Linux
date: 2005-01-26T20:50:07+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/windows-viruses-under-linux
permalink: /2005/01/26/windows-viruses-under-linux/
categories:
  - Computers! and Code!
  - Fun!
---
<p>Some folks (who have waaaay to much time on their hands) are testing windows viruses running on Linux under <a href="http://www.winehq.com/">Wine</a>. No, really - <a href="http://os.newsforge.com/article.pl?sid=05/01/25/1430222&#38;from=rss">check it out</a>!</p>