---
id: 64
title: Something Fishy in Seattle
date: 2005-01-07T10:22:25+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/something-fishy-in-seattle
permalink: /2005/01/07/something-fishy-in-seattle/
categories:
  - Philosophy! and Politics!
---
<p>Besides the great food at the pier..<br /><br />"<i>Miscast provisional votes could be one reason the number of ballots counted in King County outnumbered the list of voters who voted by 3,539.</i>" - <a href=http://seattletimes.nwsource.com/html/politics/2002141050_recount05m.html>Seattle Times</a><br /><br />Hmm...<br /><br />Thanks again <a href=http://emilyscraziness.blogspot.com/2005/01/politics-shmolitics.html>Emily!</a><br /><br />-Still Sicko</p>