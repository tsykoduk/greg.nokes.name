---
id: 686
title: White puffyness
date: 2005-07-26T09:30:17+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/white-puffyness
permalink: /2005/07/26/white-puffyness/
categories:
  - Philosophy! and Politics!
  - Science!
---
<p>Took this photo in Yakima - saw the clouds and just fell in love with them. Clouds remind me of flying.<div style="float: right; margin-left: 10px; margin-bottom: 10px;"><a href="http://www.flickr.com/photos/tsykoduk/27247165/" title="photo sharing"><img src="http://photos22.flickr.com/27247165_633f0c97ea_m.jpg" alt="" style="border: solid 2px #000000;" /></a></div></p>


		<p>Speaking of flying, watched the <a href="http://www.space.com/missionlaunches/050726_sts114_launchsuccess.html">Shuttle</a> today. Really great that we are making it back into space. I hope that the crew makes it back home safely, with all their science and tasks done safely, and easily.</p>


		<p>I really loved the signs that <a href="http://www.google.com/search?q=Soichi+Noguchi&#38;sourceid=mozilla-search&#38;start=0&#38;start=0&#38;ie=utf-8&#38;oe=utf-8&#38;client=firefox&#38;rls=org.mozilla:en-US:unofficial">Soichi Noguchi</a> came up with - if you missed them they were a hoot!</p>


		<p>It's sad, but I think that the Columbia Disaster has brough more awareness back <span class="caps">NASA</span> and the manned missions. In the shuttle's heyday, they did not even broadcast the launches. Now, they certainly did broadcast, and give a good blow by blow.</p>


		<p>Speaking of which, did you see the 'fuel tank cam' shot when the shuttle seperated from the main tank? Wow.</p>