---
id: 167
title: New Iraq Exit Strategy Announced
date: 2005-03-09T11:11:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/new-iraq-exit-strategy-announced
permalink: /2005/03/09/new-iraq-exit-strategy-announced/
categories:
  - Fun!
  - Philosophy! and Politics!
---
<p>(Read the full <a href=http://www.theonion.com/news/index.php?issue=4110>article - With Pictures</a>!)<br /><br /><blockquote>Bush announces Iraq Exit Strategy: We'll go through Iran<br /><br /><span class="caps">WASHINGTON</span>, DC â€” Almost a year after the cessation of major combat and a month after the nation's first free democratic elections, President Bush unveiled the coalition forces' strategy for exiting Iraq.<br /><br />"I'm pleased to announce that the Department of Defense and I have formulated a plan for a speedy withdrawal of U.S. troops from Iraq," Bush announced Monday morning. "We'll just go through Iran."<br /><br />Bush said the U.S. Army, which deposed Iran's longtime enemy Saddam Hussein, should be welcomed with open arms by the Islamic-fundamentalist state.<br /><br />"And Iran's so nearby," Bush said. "It's only a hop, skip, and a jump to the east.<br /></blockquote><br /><br />I commend Mr. Bush's decision to announce his exit strategy from Iraq. We have needed such a strategy for quite some time, and I think that the troops in the field and the people at home will laud accolades on Mr. Bush for this announcement.<br />We have needed an efficient and quick exit strategy for quite some time, and this fits the bill. Also, I think that Iran will lend us much assistance, as they must be relived that their long time foe, Saddam is gone.</p>