---
id: 14
title: insanity strikes my head often
date: 2005-01-27T20:39:41+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/insanity-strikes-my-head-often
permalink: /2005/01/27/insanity-strikes-my-head-often/
categories:
  - Fun!
---
<p>So, the (tm jesster) other nite, I was just thinking how superduper&#8482; it would be to go to the (tm jesster) store and buy some cookies.<br /><br />So, I did.<br /><br />They were yummy.<br /><br />Yes, they were.<br /><br />Really yummy.<br /><br /></p>