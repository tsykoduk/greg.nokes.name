---
id: 422
title: bodhivision
date: 2005-05-16T16:09:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/bodhivision
permalink: /2005/05/16/bodhivision/
categories:
  - Philosophy! and Politics!
---
<blockquote> The birth of an abstract idea begins with an empty paper, or in this case, an empty screen. It is through the empty paper or screen that many possibilities are born. We hope that through this myriad representation of digital abstracts, we can help to open some hearts and minds. A life based on the teachings of emptiness opens up to many possibilities..</blockquote>

		<p><a href="http://www.bodhivision.net/">bodhivision</a></p>