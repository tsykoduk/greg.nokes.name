---
id: 410
title: Guess the Google
date: 2005-05-06T15:30:06+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/guess-the-google
permalink: /2005/05/06/guess-the-google/
categories:
  - Fun!
---
<p>Just found <a href="http://grant.robinson.name/projects/guess-the-google/">this</a> little addictive game. I warned you!</p>


		<p>The idea is that you are presented with 20 images, and you have to guess what term was googled to get them. It's timed.</p>


		<p>I only got 146 points, but I am slow on the uptake sometimes.</p>