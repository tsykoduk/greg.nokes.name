---
id: 470
title: Misguided Jurisprudence
date: 2005-05-26T12:40:36+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/misguided-jurisprudence
permalink: /2005/05/26/misguided-jurisprudence/
categories:
  - Philosophy! and Politics!
---
<blockquote><a href="http://www.indystar.com/apps/pbcs.dll/article?AID=/20050526/NEWS01/505260481">Court Orders: No Wicca for <span class="caps">YOU</span></a>!!

		<p>Judge: Parents can't teach pagan beliefs
	Father appeals order in divorce decree that prevents couple from exposing son to Wicca.</p>


		<p>By Kevin Corcoran</p>


		<p>An Indianapolis father is appealing a Marion County judge's unusual order that prohibits him and his ex-wife from exposing their child to "non-mainstream religious beliefs and rituals."</p>


		<p>The parents practice Wicca, a contemporary pagan religion that emphasizes a balance in nature and reverence for the earth.</p>


		<p>Cale J. Bradford, chief judge of the Marion Superior Court, kept the unusual provision in the couple's divorce decree last year over their fierce objections, court records show. The order does not define a mainstream religion.</p>


		<p>Bradford refused to remove the provision after the 9-year-old boy's outraged parents, Thomas E. Jones Jr. and his ex-wife, Tammie U. Bristol, protested last fall.</p>


		<p>Through a court spokeswoman, Bradford said Wednesday he could not discuss the pending legal dispute.</blockquote></p>


		<p>Wow.</p>


		<p>Want to talk about freedom of religion anyone?</p>


		<p>Some people have talked about an assualt on Christianity in the US over the last few years - pagans have been under assault since, well, since Christanity came about.</p>


		<p>It should be about tolerance. Some people just do not get that.</p>


		<p>(Hat Tip, <a href="http://blog.360.yahoo.com/blog-9GOTIkI5cqomq0cm3ycs?p=60&#38;n=28500">Hildulf</a>)</p>