---
id: 609
title: Comments and Email
date: 2005-06-30T09:36:58+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/comments-and-email
permalink: /2005/06/30/comments-and-email/
categories:
  - Computers! and Code!
---
<p>You can now be notified when some one else comments to a comment stream that you have commented on.</p>


		<p>Confused yet?</p>


		<p>Just check the little box under the comment feild and you will be one with the way of comment notification.</p>