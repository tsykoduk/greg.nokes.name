---
id: 10508
title: Now with Nginx-Passenger Goodness!
date: 2009-04-17T04:37:00+00:00
author: tsykoduk
layout: post
guid: 30/2009/04/17/now-with-nginx-passenger-goodness
permalink: /2009/04/17/now-with-nginx-passenger-goodness/
categories:
  - Computers! and Code!
tags:
  - linkedin
---
That's right, twice the geekyness for half the cost!