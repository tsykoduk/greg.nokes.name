---
id: 39
title: 'Yahoo! News &#8211; Army Prepares &#039;Robo-Soldier&#039; for Iraq'
date: 2005-01-23T10:00:53+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/yahoo-news-army-prepares-robo-soldier-for-iraq
permalink: /2005/01/23/yahoo-news-army-prepares-robo-soldier-for-iraq/
categories:
  - Science!
---
<p><a href="http://news.yahoo.com/news?tmpl=story&amp;u=/ap/20050122/ap_on_hi_te/gunslinging_robot">Army Prepares 'Robo-Soldier' for Iraq</a>: "<i>Made by a small Massachusetts company, the <span class="caps">SWORDS</span>, short for Special Weapons Observation Reconnaissance Detection Systems, will be the first armed robotic vehicles to see combat</i>"<br /><br />The story goes on to talk about how this machine was created using off the shelf gear for only $2 million and in six months. Fantastic results do not need fantastic budgets. It's nice to see folks who can think out of the box.<br /><br />Right now they are mounting an automatic rifle on the little buggers, but have expermented with rocket launchers, grenade lauchers, the <a href=http://www.metalstorm.com/04_the_technology.html>Metal Storm</a> launcher and a .50 cal.<br /><br /></p>