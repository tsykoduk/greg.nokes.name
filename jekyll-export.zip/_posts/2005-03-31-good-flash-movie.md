---
id: 121
title: Good Flash Movie
date: 2005-03-31T15:13:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/good-flash-movie
permalink: /2005/03/31/good-flash-movie/
categories:
  - Philosophy! and Politics!
---
<p>Check <a href=http://www.buddhanet.net/flash/rahula/rahula.html>This</a> out...<br /><br />It's simple lessons like this that we need to learn. Often when I am wrapped up in my life and my problems, I am like Leo - not wanting to help, not thinking before acting. By training myself to be mindful, I can learn to float above the feelings that are generated in daily life. I still experience them, I still feel them, but they no longer dictate my actions. I am not ruled by my gut, but rather by my reason. I react not out of momentary passion, but out of thoughtfulness.<br /><br />-Tsyko</p>