---
id: 780
title: Gaming Fun
date: 2005-08-23T20:35:24+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/gaming-fun
permalink: /2005/08/23/gaming-fun/
categories:
  - Fun!
---
<p>In case you were wondering:</p>


	<blockquote>250 things Mr. Welch can no longer do during an <span class="caps">RPG</span>

		<p>1. Cannot base characters off the Who's drummer Keith Moon.
	2. A one man band is not an appropriate bard instrument.
	3. There is no Gnomish god of heavy artillery.
	4. My 7th Sea character Boudreaux is not 'Southern' Montaigne.
	5. Not allowed to blow all my skill points on 1pt professional skills.
	6. Synchronized panicking is not a proper battle plan.
	7. Not allowed to use psychic powers to do the dishes.
	8. How to serve Dragons is not a cookbook.
	9. My monk's lips must be in sync.
	10. Just because my character and I can speak German, doesn't mean the GM can.</blockquote></p>


		<p>-<a href="http://piratelog.blogspot.com/2005/08/gaming-fun.html">Subversive Puppet Show: Gaming Fun</a></p>


		<p>There are a lot more on the site.</p>


		<p>I personally have done several of these. Guessing which is left to the reader...</p>