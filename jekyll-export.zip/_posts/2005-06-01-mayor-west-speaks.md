---
id: 497
title: Mayor West Speaks
date: 2005-06-01T15:32:47+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/mayor-west-speaks
permalink: /2005/06/01/mayor-west-speaks/
categories:
  - Philosophy! and Politics!
---
<p>Mayor West talks on The Today Show, and the Spokesman posts a <a href="http://www.spokesmanreview.com/jimwest/story.asp?ID=053105_transcript_today">transcript.</a> Good read.</p>


	<blockquote>Lauer: Do you expect them to rally around you? I mean, there are many calls for your resignation.

		<p>West: I've received letters and emails. My mail and my emails are running two to one in favor of me resigning. (sic) I have with me emails from people who said I didn't vote for you, but you're doing such a great job as Mayor ...</p>


		<p>Lauer: Wait, wait. You're saying two to one in favor of you not resigning?</p>


		<p>West: Not resigning. The mail that's coming to me, the emails that are coming to me are running in my favor not to resign. Stand your ground. They say if the allegations are true, you ought to go. Well, they're not true. But they say if they're not true, stand your ground, you shouldn't be run out for just simple allegations. Because if you can do that, they you can run anybody out of office.</blockquote></p>