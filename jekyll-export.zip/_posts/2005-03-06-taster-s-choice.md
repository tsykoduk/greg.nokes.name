---
id: 181
title: 'Taster&#039;s Choice'
date: 2005-03-06T14:49:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/taster-s-choice
permalink: /2005/03/06/taster-s-choice/
categories:
  - Fun!
---
<center><br /><a HREF="http://quiz.ravenblack.net/flavour.pl"><img BORDER=0 WIDTH=100 HEIGHT=100 SRC="http://quiz.ravenblack.net/flavour/10.png" ALT="What Flavour Are You? I taste like Beef." /></a></center> <br />I taste like <b>Beef</b>. <br />I taste like beef. I'm probably made of beef. You are what you eat, they say, and if the title didn't mean something else, I would be a beefeater. I think red meat is good for you. Puts hair on your chest. <a HREF="http://quiz.ravenblack.net/flavour.pl">What Flavour Are You?</a><br /><br />Hat tip <a href=http://emilyscraziness.blogspot.com/>Craziness