---
id: 10
title: Movies that Matter!
date: 2005-01-28T13:56:11+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/movies-that-matter
permalink: /2005/01/28/movies-that-matter/
categories:
  - Fun!
---
<p><a href="http://slashdot.org/article.pl?sid=05/01/28/1813245&#38;tid=97&#38;tid=214">Slashdot: News for nerds, stuff that matters</a>: "Doctor Monkey writes 'Initial reviews are up at Ain't It Cool News from a 'work-in-progress' screening of The Hitchhiker's Guide to the Galaxy in Pasadena, CA. Reaction seems mixed-to-positive, mostly due to some uneven performances. But it looks like the film is not a complete bastardization of Adams' work.'"<br /><br />Woot.<br /><br />This was a long time coming, and I have high hopes. Now all we need to do is resurrect <a href="http://www.blakes7.com">Blakes 7</a>, <a href="http://www.bbc.co.uk/cult/doctorwho/">Dr. Who</a>, and get the <a href="http://www.reddwarf.co.uk/">Red Dwarf movie</a> off the ground..<br /><br />Here's hoping for more great SciFi!</p>