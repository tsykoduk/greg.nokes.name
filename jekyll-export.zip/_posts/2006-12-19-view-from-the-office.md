---
id: 1720
title: View from the office
date: 2006-12-19T17:18:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/view-from-the-office
permalink: /2006/12/19/view-from-the-office/
categories:
  - Philosophy! and Politics!
---
<center><img src="http://greg.nokes.name/assets/2006/12/19/DSC00168.jpg" width="400" / style="border: 1px solid black;"></center>

	<p>I had to take a little trip yesterday, and I snapped this photo when we were where we were going.</p>