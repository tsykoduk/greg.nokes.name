---
id: 3044
title: American Pie
date: 2007-12-15T22:14:00+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/american-pie
permalink: /2007/12/15/american-pie/
categories:
  - Philosophy! and Politics!
---
<center><object width="425" height="355"><param name="movie" value="http://www.youtube.com/v/-3fDFSPSoyo&#38;rel=1"></param><param name="wmode" value="transparent"></param><embed src="http://www.youtube.com/v/-3fDFSPSoyo&#38;rel=1" type="application/x-shockwave-flash" wmode="transparent" width="425" height="355"></embed></object></center>