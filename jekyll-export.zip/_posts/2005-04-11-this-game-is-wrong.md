---
id: 255
title: This game is wrong
date: 2005-04-11T20:18:44+00:00
author: tsykoduk
layout: post
guid: 30/2008/12/27/this-game-is-wrong
permalink: /2005/04/11/this-game-is-wrong/
categories:
  - Fun!
---
<p>But I got 2037 feet. What <a href="http://www.addictinggames.com/kittencannon.html">can you get</a>?</p>